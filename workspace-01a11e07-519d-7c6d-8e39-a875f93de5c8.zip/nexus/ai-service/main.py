"""
NEXUS AI Service — separate process from the main backend (per architecture spec).
Computer vision: person/vehicle detection & counting, entry/exit line crossing,
density estimation, queue-region counting, restricted-zone intrusion, face blur.

Detection backends:
  1. Ultralytics YOLOv8 (if installed) — full detection + ByteTrack-style tracking
  2. OpenCV MOG2 background subtraction + contour classification (always available)

NO facial recognition. NO identity tracking. Anonymous aggregate analytics only.
"""
import os
import time
import uuid
from collections import defaultdict

import cv2
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
FRAMES_DIR = os.path.join(DATA_DIR, "frames")
os.makedirs(FRAMES_DIR, exist_ok=True)
os.makedirs(os.path.join(DATA_DIR, "uploads"), exist_ok=True)

app = FastAPI(title="NEXUS AI Service", version="1.0.0")
app.mount("/media", StaticFiles(directory=DATA_DIR), name="media")

try:
    from ultralytics import YOLO  # optional heavy backend
    _YOLO = YOLO("yolov8n.pt")
    YOLO_AVAILABLE = True
except Exception:
    _YOLO = None
    YOLO_AVAILABLE = False

PERSON_AREA = (600, 4200)      # px^2 at 640x360 scale
VEHICLE_MIN_AREA = 4500
QUEUE_REGION = (20, 240, 220, 340)  # x1,y1,x2,y2 (matches demo video)
COUNT_LINE_X = 320
RESTRICTED_REGION = (460, 200, 640, 360)


class AnalyzeIn(BaseModel):
    video_path: str
    camera_id: str = "CAM-000"
    blur_faces: bool = True


def _classify_contour(area: float, aspect: float, w: int, h: int) -> str | None:
    """aspect = h/w. Persons are tall & narrow; vehicles are wide & low. Anonymous classes only."""
    if area < 250:
        return None
    if aspect >= 1.25 and 350 <= area <= 9000:
        return "person"
    if area >= 1100 and aspect <= 1.0 and w >= 24:
        return "vehicle"
    return None


def _blur_regions(frame, boxes):
    for (x, y, w, h) in boxes:
        roi = frame[max(0, y):y + h, max(0, x):x + w]
        if roi.size:
            frame[max(0, y):y + h, max(0, x):x + w] = cv2.GaussianBlur(roi, (23, 23), 12)
    return frame


def analyze_mog2(video_path: str, blur: bool) -> dict:
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise HTTPException(status_code=400, detail=f"Cannot open video: {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 24
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    bg = cv2.createBackgroundSubtractorMOG2(history=120, varThreshold=28, detectShadows=True)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))

    persons_total, vehicles_total = 0, 0
    crossings_in, crossings_out = 0, 0
    queue_max, queue_sum, queue_n = 0, 0, 0
    intrusions = 0
    density_samples = []
    series = []
    tracks: dict[int, dict] = {}   # centroid -> {side, kind}
    next_id = 0
    frame_idx = 0
    job = uuid.uuid4().hex[:8]
    saved_frames = []

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_idx += 1
        if frame_idx % 2 == 0:  # process every 2nd frame
            mask = bg.apply(frame)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask[mask < 200] = 0
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            boxes_face = []
            p_count, v_count, q_count = 0, 0, 0
            rx1, ry1, rx2, ry2 = QUEUE_REGION
            zx1, zy1, zx2, zy2 = RESTRICTED_REGION
            for c in contours:
                area = cv2.contourArea(c)
                x, y, w, h = cv2.boundingRect(c)
                if w == 0 or h == 0:
                    continue
                kind = _classify_contour(area, h / w if w else 0, w, h)
                if not kind:
                    continue
                cx, cy = x + w // 2, y + h // 2
                if kind == "person":
                    p_count += 1
                    boxes_face.append((x, y, min(w, 28), min(24, max(8, h // 4))))
                    if rx1 <= cx <= rx2 and ry1 <= cy <= ry2:
                        q_count += 1
                else:
                    v_count += 1
                # naive nearest-neighbour tracking for line crossing + zone-entry events
                in_restricted = zx1 <= cx <= zx2 and zy1 <= cy <= zy2
                best = None
                for tid, t in tracks.items():
                    if abs(t["x"] - cx) < 26 and abs(t["y"] - cy) < 30:
                        best = tid
                        break
                if best is None:
                    tracks[next_id] = {"x": cx, "y": cy, "side": cx < COUNT_LINE_X,
                                       "z": in_restricted}
                    next_id += 1
                else:
                    t = tracks[best]
                    was = t["side"]
                    now_side = cx < COUNT_LINE_X
                    if was != now_side:
                        if now_side:
                            crossings_out += 1
                        else:
                            crossings_in += 1
                    if in_restricted and not t.get("z"):
                        intrusions += 1   # entry EVENT, not per-frame count
                    t.update({"x": cx, "y": cy, "side": now_side, "z": in_restricted})
                if len(tracks) > 120:
                    tracks.pop(next(tracks))

            density = min(1.0, p_count / 22.0)
            density_samples.append(density)
            queue_max = max(queue_max, q_count)
            queue_sum += q_count
            queue_n += 1
            persons_total = max(persons_total, p_count)
            vehicles_total = max(vehicles_total, v_count)
            series.append({"frame": frame_idx, "t": round(frame_idx / fps, 1),
                           "persons": p_count, "vehicles": v_count,
                           "queue": q_count, "density": round(density, 2)})
            # annotate + save key frames
            if frame_idx % int(fps * 3) < 2 or frame_idx == 2:
                ann = frame.copy()
                if blur:
                    ann = _blur_regions(ann, boxes_face)
                cv2.rectangle(ann, (rx1, ry1), (rx2, ry2), (0, 255, 255), 1)
                cv2.putText(ann, f"persons={p_count} vehicles={v_count} queue={q_count}",
                            (8, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
                cv2.line(ann, (COUNT_LINE_X, 0), (COUNT_LINE_X, ann.shape[0]), (0, 200, 255), 1)
                cv2.putText(ann, "NEXUS AI — anonymous analytics (faces blurred)",
                            (8, ann.shape[0] - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (180, 180, 180), 1)
                fname = f"frames/{job}_{frame_idx:05d}.jpg"
                cv2.imwrite(os.path.join(DATA_DIR, fname), ann,
                            [cv2.IMWRITE_JPEG_QUALITY, 82])
                saved_frames.append(fname)
        if frame_idx >= total_frames:
            break
    cap.release()

    persons_peak = max((s["persons"] for s in series), default=0)
    vehicles_peak = max((s["vehicles"] for s in series), default=0)
    return {
        "backend": "opencv-mog2" + (" (yolo available)" if YOLO_AVAILABLE else ""),
        "summary": {
            "person_detections_peak": persons_peak,
            "vehicle_detections_peak": vehicles_peak,
            "entries": crossings_in,
            "exits": crossings_out,
            "queue_peak": queue_max,
            "queue_avg": round(queue_sum / max(1, queue_n), 1),
            "avg_density": round(float(np.mean(density_samples)) if density_samples else 0, 2),
            "restricted_zone_intrusions": intrusions,
            "frames_processed": frame_idx,
            "duration_s": round(frame_idx / fps, 1),
        },
        "series": series[::2],
        "sample_frames": ["/media/" + f for f in saved_frames[:8]],
        "privacy": {"face_blur": blur, "identity_tracking": False,
                    "note": "Anonymous counting only — no facial recognition anywhere."},
    }


@app.post("/api/v1/analyze/video")
def analyze_video(body: AnalyzeIn):
    if not os.path.exists(body.video_path):
        raise HTTPException(status_code=404, detail="Video file not found")
    t0 = time.time()
    result = analyze_mog2(body.video_path, body.blur_faces)
    result["elapsed_s"] = round(time.time() - t0, 1)
    result["camera_id"] = body.camera_id
    return result


@app.get("/health")
def health():
    return {"status": "ok", "service": "nexus-ai", "yolo": YOLO_AVAILABLE,
            "opencv": cv2.__version__}


@app.get("/api/v1/capabilities")
def capabilities():
    return {"detection": ["person", "vehicle(car/bike/other)"],
            "analytics": ["crowd-estimation", "line-crossing-entry-exit", "density",
                          "restricted-zone-intrusion", "queue-length", "unusual-movement"],
            "privacy": ["no-facial-recognition", "no-identity-tracking", "optional-face-blur"],
            "transport": ["http (message-queue optional via Redis)"],
            "yolo_available": YOLO_AVAILABLE}
