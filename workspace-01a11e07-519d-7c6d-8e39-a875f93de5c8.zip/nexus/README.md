# NEXUS — AI Digital Twin for Campus Intelligence

> **Understand the present. Simulate the future. Prevent the unexpected.**

NEXUS is an AI-powered campus intelligence platform that maintains a continuously updated
**digital twin** of a college campus. It combines CCTV/video analytics, crowd & vehicle
movement, parking, food stalls, events, weather and resource data to answer three questions:

1. **What is happening now?** — live digital twin dashboard
2. **Is anything unusual happening?** — explainable anomaly detection
3. **What is likely to happen next?** — prediction + **What-If simulation** before acting

It is *not* an attendance or classroom-monitoring system. Anonymous, aggregate analytics only —
**no facial recognition, no individual tracking, anywhere in the codebase.**

---

## Architecture

```
                 ┌──────────────────────────────┐
   RTSP/upload/  │          AI SERVICE           │  OpenCV + (optional YOLO) + tracking
   demo video ──▶│  detection·counting·queues    │  anonymous analytics only
                 └──────────────┬───────────────┘  HTTP (Redis pub/sub optional)
                                │
 ┌──────────────┐   ┌───────────▼───────────────────────────────┐   ┌──────────────┐
 │   FRONTEND    │◀─▶│                BACKEND (FastAPI)           │◀─▶│  PostgreSQL  │
 │ React+TS+     │WS │ ┌───────────────────────────────────────┐ │   │  (+Redis)    │
 │ Tailwind+     │   │ │   SHARED SIMULATION / SCENARIO ENGINE  │ │   └──────────────┘
 │ Recharts+SVG  │   │ │  powers Demo Mode + What-If + Replay   │ │
 └──────────────┘   │ └───────────────────────────────────────┘ │
                     │ baseline AI: anomaly(z/IQR) · forecast     │
                     │ (seasonal+trend) · risk weights · alerts   │
                     │ LLM layer (env-configured) + TEMPLATE      │
                     │ FALLBACK so the demo never breaks          │
                     └────────────────────────────────────────────┘
```

One engine = consistent numbers everywhere. The live dashboard, the What-If simulator and
Event Replay all run the same tick model.

| Service    | Port | Purpose                                                        |
|------------|------|----------------------------------------------------------------|
| backend    | 8000 | API + WebSocket + risk/anomaly/prediction + demo engine        |
| ai-service | 8001 | Computer vision (separate process, per spec)                   |
| frontend   | 5173 | React command center (dev) / 8080 (nginx in compose)           |

---

## Quick start

### Option A — one command (Docker)

```bash
cp .env.example .env
docker compose up --build
# → UI on http://localhost:8080, API docs on http://localhost:8000/docs
```

### Option B — local dev (no Docker, SQLite)

```bash
python3 -m venv .venv && .venv/bin/pip install -r backend/requirements.txt
cd backend && ../.venv/bin/python seed.py          # users + 30d history + demo video + baselines
../.venv/bin/uvicorn app.main:app --port 8000      # backend
../.venv/bin/uvicorn main:app --app-dir ../ai-service --port 8001   # AI service
cd ../frontend && npm install && npm run dev       # UI on http://localhost:5173
```

### Demo accounts (clearly labeled demo-only; disabled when `ENV=production`)

| user            | password        | role           |
|-----------------|-----------------|----------------|
| `admin`         | `NexusAdmin@123`| SUPER ADMIN (from env vars, not hardcoded in code paths) |
| `campus_admin`  | `DemoCampus@123`| CAMPUS ADMIN   |
| `security_admin`| `DemoSecure@123`| SECURITY ADMIN |
| `event_admin`   | `DemoEvents@123`| EVENT ADMIN    |

The public **Campus Pulse** page needs no login: `/pulse`.

---

## The 20-step hackathon demo

Open the dashboard → side panel → **Director** tab → **▶ Auto-run remaining**.

1. Admin logs in · 2. Live digital twin · 3. Normal conditions · 4. Start TECHNOVA 2026 ·
5. Crowd rises · 6. AI flags abnormal growth · 7. Overcrowding predicted · 8. Parking demand rises ·
9. Parking-full prediction · 10. Traffic + stall rush, queue warning · 11. Risk score with reasons ·
12. AI recommendations · 13–18. What-If: *"What if the main gate is closed?"* → impacts →
alternative strategy → REALITY vs SIMULATED · 19–20. **Explain My Campus** report.

Demo Mode controls (no hardware needed): crowd surge, vehicle surge, parking shortage, event,
food-court rush, gate closure, weather change, resource anomaly, camera failure, reset.

---

## Feature map (what is built)

**P0 (flawless demo path)** — auth (JWT httpOnly + refresh, bcrypt, RBAC, rate limiting),
live SVG digital twin with heat/traffic/parking/stall/event layers + **+10/+20/+30 min predicted
overlay**, Demo Mode simulator with WebSocket push, crowd/parking/traffic/food-stall analytics,
explainable anomaly detection (rolling hour×day baselines, z-score/IQR), predictions with
confidence bands (seasonal baseline + linear trend), weighted risk engine with factor
explanations, smart alerts (dedupe/cooldown, ack/resolve lifecycle), ⭐ What-If simulator
(natural language + structured, 11 scenarios incl. evacuation, saved runs, A/B compare,
current-vs-simulated charts), AI assistant (LLM optional, template fallback guaranteed,
can trigger What-If simulations), Explain My Campus report (print/PDF export),
⭐ Demo Director (20-step sequence).

**P1** — computer vision on uploaded/demo video (person/vehicle detection, entry/exit line
crossing, queue-region counting, density, restricted-zone intrusion, face blur; YOLO upgrade
path), event intelligence (capacity-exceed detection + impact), mobility corridors & flow,
resource + environment intelligence, event replay with scrubber/playback/narrative, analytics
with CSV/PDF export + model-health + prediction accuracy, camera management, privacy settings.

**P2** — RTSP camera registration (credentials server-side only), evacuation simulation
(time, bottlenecks, assembly points), public Campus Pulse, stall-owner view, recommendation
feedback loop with before/after tracking, notification toasts + sound toggle.

**Not built (by design, section 32):** classroom monitoring, attendance, individual tracking,
facial recognition.

---

## Key APIs (OpenAPI at `/docs`)

`/api/v1/auth/*` · `/live/snapshot` · `/demo/inject|reset|director` · `/simulations/run|run-nl|history|compare`
· `/assistant/chat` · `/reports/daily` · `/events` · `/stalls|owner-view|rush-forecast` · `/cameras|analyze`
· `/analytics/timeseries|anomalies|model-health|prediction-accuracy` · `/replay/days|day`
· `/alerts` · `/recommendations` · `/settings/privacy|risk-weights|users|audit` · `/pulse` (public)
· WebSocket `/ws/live`.

## Tests

```bash
cd backend && ../.venv/bin/pytest tests -q
```

## Privacy model

Anonymous aggregates only · configurable retention + auto-purge job · face/plate blur toggles ·
no plate storage by default · individual-tracking flag hard-locked OFF · audit log for all admin
actions · RBAC enforced server-side · camera credentials never leave the server.
