import { create } from 'zustand'

export interface User { username: string; email: string; full_name: string; role: string; is_demo_account: boolean }

interface AppState {
  user: User | null
  setUser: (u: User | null) => void
  snap: any | null
  setSnap: (s: any) => void
  toasts: { id: number; kind: string; title: string; body: string }[]
  pushToast: (kind: string, title: string, body: string) => void
  dropToast: (id: number) => void
  soundOn: boolean
  toggleSound: () => void
  layer: string
  setLayer: (l: string) => void
  futureT: number   // 0 = now, 10/20/30 = predicted overlay
  setFutureT: (t: number) => void
  selectedZone: string | null
  selectZone: (k: string | null) => void
  wsConnected: boolean
  setWs: (b: boolean) => void
}

let toastId = 0
export const useApp = create<AppState>((set, get) => ({
  user: null,
  setUser: (u) => set({ user: u }),
  snap: null,
  setSnap: (s) => set({ snap: s }),
  toasts: [],
  pushToast: (kind, title, body) => {
    const id = ++toastId
    set({ toasts: [...get().toasts.slice(-4), { id, kind, title, body }] })
    setTimeout(() => get().dropToast(id), 8000)
    if (get().soundOn && (kind === 'critical' || kind === 'warning')) {
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
        const o = ctx.createOscillator(); const g = ctx.createGain()
        o.frequency.value = kind === 'critical' ? 660 : 440; o.type = 'sine'
        g.gain.setValueAtTime(0.08, ctx.currentTime)
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5)
        o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.5)
      } catch {}
    }
  },
  dropToast: (id) => set({ toasts: get().toasts.filter(t => t.id !== id) }),
  soundOn: true,
  toggleSound: () => set({ soundOn: !get().soundOn }),
  layer: 'crowd',
  setLayer: (l) => set({ layer: l }),
  futureT: 0,
  setFutureT: (t) => set({ futureT: t }),
  selectedZone: null,
  selectZone: (k) => set({ selectedZone: k }),
  wsConnected: false,
  setWs: (b) => set({ wsConnected: b }),
}))
