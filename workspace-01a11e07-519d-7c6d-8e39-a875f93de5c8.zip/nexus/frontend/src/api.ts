export async function api(path: string, opts: { method?: string; body?: any; raw?: boolean } = {}) {
  const res = await fetch(`/api/v1${path}`, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  })
  if (res.status === 401 && !path.startsWith('/auth/login')) {
    // try refresh once
    const r2 = await fetch('/api/v1/auth/refresh', { method: 'POST', credentials: 'include' })
    if (r2.ok) {
      const retry = await fetch(`/api/v1${path}`, {
        method: opts.method || 'GET',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      })
      if (retry.ok) return retry.json()
      window.location.href = '/login'
      throw new Error('unauthorized')
    }
    window.location.href = '/login'
    throw new Error('unauthorized')
  }
  if (!res.ok) {
    let detail = res.statusText
    try { const j = await res.json(); detail = j.detail || JSON.stringify(j) } catch {}
    throw new Error(detail)
  }
  if (opts.raw) return res
  return res.json()
}

export const fmt = (n: number | undefined | null, d = 0) =>
  n === undefined || n === null ? '—' : Number(n).toLocaleString('en-IN', { maximumFractionDigits: d })
