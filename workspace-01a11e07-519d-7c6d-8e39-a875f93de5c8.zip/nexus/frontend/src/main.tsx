import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation, Link, NavLink } from 'react-router-dom'
import { useApp } from './store'
import { api } from './api'
import { Badge, Btn } from './components/ui'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Predictions from './pages/Predictions'
import WhatIf from './pages/WhatIf'
import Stalls from './pages/Stalls'
import Events from './pages/Events'
import Analytics from './pages/Analytics'
import Replay from './pages/Replay'
import Cameras from './pages/Cameras'
import Report from './pages/Report'
import Settings from './pages/Settings'
import Pulse from './pages/Pulse'
import './index.css'

function useLive() {
  const setSnap = useApp(s => s.setSnap)
  const setWs = useApp(s => s.setWs)
  const pushToast = useApp(s => s.pushToast)
  React.useEffect(() => {
    let ws: WebSocket | null = null
    let timer: any
    let closed = false
    const connect = () => {
      const proto = location.protocol === 'https:' ? 'wss' : 'ws'
      ws = new WebSocket(`${proto}://${location.host}/ws/live`)
      ws.onopen = () => setWs(true)
      ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data)
          if (msg.type === 'snapshot') setSnap(msg)
          if (msg.type === 'alerts') msg.alerts?.forEach((a: any) =>
            pushToast(a.severity, `⚠ ${a.location}`, a.reason))
          if (msg.type === 'anomalies') msg.anomalies?.forEach((a: any) =>
            pushToast('warning', `🔍 Anomaly: ${a.metric}`, a.reason.slice(0, 140)))
        } catch {}
      }
      ws.onclose = () => { setWs(false); if (!closed) timer = setTimeout(connect, 2500) }
    }
    connect()
    return () => { closed = true; clearTimeout(timer); ws?.close() }
  }, [])
}

const NAV = [
  ['/', 'Digital Twin'], ['/predictions', 'Predictions'], ['/whatif', 'What-If Simulator'],
  ['/stalls', 'Food Court'], ['/events', 'Events'], ['/analytics', 'Analytics'],
  ['/replay', 'Replay'], ['/cameras', 'Cameras'], ['/report', 'Explain My Campus'], ['/settings', 'Settings'],
]

function Shell({ children }: any) {
  const { user, setUser, snap, wsConnected, soundOn, toggleSound, toasts, dropToast } = useApp()
  const nav = useNavigate()
  const loc = useLocation()
  useLive()
  React.useEffect(() => {
    api('/auth/me').then(setUser).catch(() => { setUser(null); nav('/login') })
  }, [])
  if (!user) return null
  const risk = snap?.risk
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-edge bg-panel/80 backdrop-blur px-4 py-2 flex items-center gap-4 sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <svg width="26" height="26" viewBox="0 0 32 32"><circle cx="16" cy="16" r="14" fill="#0d1424" stroke="#22d3ee" strokeWidth="2"/><circle cx="16" cy="16" r="5" fill="#22d3ee"/></svg>
          <div>
            <div className="font-black tracking-widest text-cyan-300 leading-4">NEXUS</div>
            <div className="text-[9px] text-slate-400 tracking-wider uppercase">AI Digital Twin · Campus Intelligence</div>
          </div>
        </div>
        <div className="hidden md:block text-[10px] text-slate-500 italic">Understand the present. Simulate the future. Prevent the unexpected.</div>
        <div className="flex-1" />
        <div className="hidden sm:flex items-center gap-3 text-xs">
          {snap && <span className="text-slate-400">SIM <span className="text-cyan-300 font-mono font-bold">{snap.sim_clock}</span></span>}
          <span className="flex items-center gap-1 text-slate-400">
            <span className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-emerald-400' : 'bg-red-400'}`} /> {wsConnected ? 'LIVE' : 'OFFLINE'}
          </span>
          {risk && <Badge tone={risk.level}>{risk.icon} RISK {risk.score}</Badge>}
          <button onClick={toggleSound} title="Alert sound" className="text-slate-400 hover:text-white">{soundOn ? '🔔' : '🔕'}</button>
          <Badge tone="open">{user.role}</Badge>
          <span className="text-slate-300">{user.username}</span>
          <Btn size="sm" variant="ghost" onClick={async () => { await api('/auth/logout', { method: 'POST' }); setUser(null); nav('/login') }}>Logout</Btn>
        </div>
      </header>
      <div className="flex flex-1">
        <nav className="w-44 shrink-0 border-r border-edge bg-panel/40 p-2 hidden md:flex flex-col gap-1">
          {NAV.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === '/'}
              className={({ isActive }) => `px-3 py-2 rounded-lg text-sm transition-colors ${isActive ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200 hover:bg-panel2 border border-transparent'}`}>
              {label}
            </NavLink>
          ))}
          <Link to="/pulse" className="mt-4 px-3 py-2 rounded-lg text-xs text-slate-500 hover:text-cyan-300">🌐 Public Campus Pulse →</Link>
        </nav>
        <main className="flex-1 p-4 min-w-0">{children}</main>
      </div>
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 w-80 max-w-[90vw]">
        {toasts.map(t => (
          <div key={t.id} className={`toast-in panel p-3 border-l-4 ${t.kind === 'critical' ? 'border-l-red-500' : t.kind === 'warning' ? 'border-l-amber-400' : 'border-l-cyan-400'}`}>
            <div className="flex justify-between gap-2">
              <div className="text-xs font-bold text-slate-200">{t.title}</div>
              <button className="text-slate-500 hover:text-white" onClick={() => dropToast(t.id)}>×</button>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">{t.body}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/pulse" element={<Pulse />} />
        <Route path="*" element={<Shell><Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/predictions" element={<Predictions />} />
          <Route path="/whatif" element={<WhatIf />} />
          <Route path="/stalls" element={<Stalls />} />
          <Route path="/events" element={<Events />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/replay" element={<Replay />} />
          <Route path="/cameras" element={<Cameras />} />
          <Route path="/report" element={<Report />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes></Shell>} />
      </Routes>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />)
