import React from 'react'
import clsx from 'clsx'

export function Card({ className = '', children, title, right }: any) {
  return (
    <div className={clsx('panel kpi-glow', className)}>
      {(title || right) && (
        <div className="flex items-center justify-between px-4 pt-3 pb-1">
          <div className="text-[11px] font-semibold tracking-widest uppercase text-slate-400">{title}</div>
          {right}
        </div>
      )}
      {children}
    </div>
  )
}

const badgeColors: Record<string, string> = {
  LOW: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  LIGHT: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  NORMAL: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  MEDIUM: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  MODERATE: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  HIGH: 'bg-orange-500/15 text-orange-300 border-orange-500/30',
  ELEVATED: 'bg-orange-500/15 text-orange-300 border-orange-500/30',
  CRITICAL: 'bg-red-500/15 text-red-300 border-red-500/30',
  info: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
  warning: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  critical: 'bg-red-500/15 text-red-300 border-red-500/30',
  open: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
  accepted: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  dismissed: 'bg-slate-500/15 text-slate-300 border-slate-500/30',
  new: 'bg-red-500/15 text-red-300 border-red-500/30',
  acknowledged: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  resolved: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  online: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  offline: 'bg-red-500/15 text-red-300 border-red-500/30',
  live: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  ended: 'bg-slate-500/15 text-slate-400 border-slate-500/30',
  scheduled: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
}
export function Badge({ children, tone, className = '' }: any) {
  return <span className={clsx('inline-flex items-center px-2 py-0.5 rounded-md border text-[10px] font-bold tracking-wide uppercase',
    badgeColors[tone || String(children)] || 'bg-slate-500/15 text-slate-300 border-slate-500/30', className)}>{children}</span>
}

export function Btn({ className = '', variant = 'default', size = 'md', ...props }: any) {
  const v = {
    default: 'bg-neon-cyan/10 text-cyan-300 border border-cyan-500/30 hover:bg-neon-cyan/20',
    primary: 'bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400',
    ghost: 'bg-transparent text-slate-300 border border-edge hover:bg-panel2',
    danger: 'bg-red-500/10 text-red-300 border border-red-500/30 hover:bg-red-500/20',
    ok: 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20',
  }[variant]
  const s = { sm: 'px-2 py-1 text-xs', md: 'px-3 py-1.5 text-sm', lg: 'px-5 py-2.5 text-base' }[size]
  return <button className={clsx('rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed', v, s, className)} {...props} />
}

export function Input(props: any) {
  return <input {...props} className={clsx('bg-panel2 border border-edge rounded-lg px-3 py-1.5 text-sm w-full outline-none focus:border-cyan-500/50', props.className)} />
}
export function Select(props: any) {
  return <select {...props} className={clsx('bg-panel2 border border-edge rounded-lg px-3 py-1.5 text-sm outline-none focus:border-cyan-500/50', props.className)} />
}
export function Textarea(props: any) {
  return <textarea {...props} className={clsx('bg-panel2 border border-edge rounded-lg px-3 py-1.5 text-sm w-full outline-none focus:border-cyan-500/50', props.className)} />
}

export function Stat({ label, value, sub, tone = 'cyan' }: any) {
  const c = { cyan: 'text-cyan-300', green: 'text-emerald-300', amber: 'text-amber-300', red: 'text-red-300', violet: 'text-violet-300', slate: 'text-slate-200' }[tone]
  return (
    <div className="panel-light p-3 min-w-0">
      <div className="text-[10px] uppercase tracking-widest text-slate-500 truncate">{label}</div>
      <div className={clsx('text-xl font-bold tabular-nums truncate', c)}>{value}</div>
      {sub && <div className="text-[11px] text-slate-400 truncate">{sub}</div>}
    </div>
  )
}

export function Spinner() {
  return <div className="inline-block w-4 h-4 border-2 border-cyan-500/30 border-t-cyan-400 rounded-full animate-spin" />
}

export function Modal({ open, onClose, title, children, wide }: any) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
      <div className={clsx('panel w-full max-h-[85vh] overflow-auto scroll-thin', wide ? 'max-w-4xl' : 'max-w-lg')} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-3 border-b border-edge">
          <div className="font-bold text-slate-100">{title}</div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xl leading-none">×</button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  )
}

export function ProgressBar({ value, tone }: { value: number; tone?: string }) {
  const color = tone || (value > 90 ? 'bg-red-500' : value > 70 ? 'bg-orange-400' : value > 45 ? 'bg-amber-400' : 'bg-emerald-400')
  return (
    <div className="h-1.5 bg-slate-700/40 rounded-full overflow-hidden">
      <div className={clsx('h-full rounded-full transition-all', color)} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  )
}
