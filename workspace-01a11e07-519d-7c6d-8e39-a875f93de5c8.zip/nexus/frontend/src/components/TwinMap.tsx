import React from 'react'
import { useApp } from '../store'

const BUILDINGS = [
  { key: 'b_admin', name: 'Admin Block', x: 70, y: 55, w: 105, h: 80 },
  { key: 'b_library', name: 'Library', x: 200, y: 180, w: 115, h: 90 },
  { key: 'b_acad_a', name: 'Academic A', x: 175, y: 340, w: 125, h: 92 },
  { key: 'b_acad_b', name: 'Academic B', x: 340, y: 425, w: 125, h: 92 },
  { key: 'b_auditorium', name: 'Auditorium', x: 425, y: 215, w: 155, h: 100 },
  { key: 'b_foodcourt', name: 'Food Court', x: 635, y: 385, w: 150, h: 85 },
  { key: 'b_research', name: 'Research Labs ⚠', x: 850, y: 45, w: 105, h: 72 },
  { key: 'sports_field', name: 'Sports Arena', x: 775, y: 120, w: 155, h: 115 },
  { key: 'lake_green', name: 'Green & Lake', x: 855, y: 425, w: 105, h: 95 },
  { key: 'plaza_ground', name: 'Plaza', x: 430, y: 340, w: 90, h: 80 },
]

const levelColor = (lvl: string) =>
  lvl === 'CRITICAL' ? '#f87171' : lvl === 'HIGH' ? '#fb923c' : lvl === 'MEDIUM' || lvl === 'MODERATE' ? '#fbbf24' : '#34d399'
const congColor = (c: number) => c > 0.85 ? '#f87171' : c > 0.5 ? '#fbbf24' : '#34d399'

export default function TwinMap({ height = 560 }: { height?: number }) {
  const { snap, layer, futureT, selectedZone, selectZone } = useApp()
  if (!snap) return <div className="h-64 flex items-center justify-center text-slate-500">Connecting to digital twin…</div>
  const fut = futureT > 0 ? snap.future?.[`+${futureT}`] : null
  const zoneCrowd = (k: string, now: number) => fut ? (fut.zones?.[k] ?? now) : now

  return (
    <svg viewBox="0 0 1000 640" style={{ height }} className="w-full select-none" role="img" aria-label="Campus digital twin map">
      <defs>
        <radialGradient id="heat">
          <stop offset="0%" stopColor="#f87171" stopOpacity="0.55" />
          <stop offset="55%" stopColor="#fb923c" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#fbbf24" stopOpacity="0" />
        </radialGradient>
        <pattern id="grid" width="34" height="34" patternUnits="userSpaceOnUse">
          <path d="M 34 0 L 0 0 0 34" fill="none" stroke="#101a30" strokeWidth="1" />
        </pattern>
      </defs>
      <rect width="1000" height="640" fill="#070d1a" />
      <rect width="1000" height="640" fill="url(#grid)" />

      {/* roads */}
      {(layer === 'all' || layer === 'traffic' || layer === 'crowd') && snap.roads?.map((r: any) => (
        <g key={r.key}>
          <polyline points={r.path.map((p: number[]) => p.join(',')).join(' ')} fill="none"
            stroke="#1c2942" strokeWidth={14} strokeLinecap="round" />
          <polyline points={r.path.map((p: number[]) => p.join(',')).join(' ')} fill="none"
            stroke={congColor(r.congestion)} strokeWidth={3} strokeDasharray="10 14"
            className="flow-anim" opacity={0.9} style={{ animationDuration: `${Math.max(0.35, 1.8 - r.congestion)}s` }} />
          {layer === 'traffic' && (
            <text x={(r.path[0][0] + r.path[1][0]) / 2} y={(r.path[0][1] + r.path[1][1]) / 2 - 10}
              fontSize="10" fill={congColor(r.congestion)} textAnchor="middle" fontFamily="monospace">
              {r.name} · {r.volume.toFixed(0)}/min · {(r.congestion * 100).toFixed(0)}%
            </text>
          )}
        </g>
      ))}

      {/* buildings */}
      {BUILDINGS.map(b => {
        const zk = { b_admin: 'admin_block', b_library: 'library', b_acad_a: 'acad_a', b_acad_b: 'acad_b', b_auditorium: 'auditorium', b_foodcourt: 'food_court', b_research: 'research', sports_field: 'sports', lake_green: 'lake', plaza_ground: 'plaza' }[b.key as string] || ''
        const z = snap.zones?.find((zz: any) => zz.key === zk)
        const sel = selectedZone === zk
        return (
          <g key={b.key} className="cursor-pointer" onClick={() => selectZone(sel ? null : zk)}>
            <rect x={b.x} y={b.y} width={b.w} height={b.h} rx={7}
              fill={b.key === 'b_research' ? 'rgba(139,92,246,.10)' : 'rgba(30,45,80,.35)'}
              stroke={sel ? '#22d3ee' : z ? levelColor(z.level) + '66' : '#26344f'} strokeWidth={sel ? 2.5 : 1.2} />
            <text x={b.x + 7} y={b.y + 15} fontSize="10.5" fill="#93a5c4" fontWeight="600">{b.name}</text>
            {z && (
              <text x={b.x + 7} y={b.y + 30} fontSize="11" fontFamily="monospace" fill={levelColor(z.level)}>
                {zoneCrowd(z.key, z.crowd)}{fut ? ` (${z.crowd}→)` : ''} · {Math.round(z.density * 100)}%
              </text>
            )}
          </g>
        )
      })}

      {/* crowd heat blobs */}
      {(layer === 'crowd' || layer === 'all') && snap.zones?.map((z: any) => {
        const crowd = zoneCrowd(z.key, z.crowd)
        const r = Math.min(95, 14 + crowd / 14)
        return crowd > 25 ? <circle key={'h' + z.key} cx={z.cx} cy={z.cy} r={r} fill="url(#heat)" opacity={Math.min(1, crowd / (z.capacity * 0.8))} pointerEvents="none" /> : null
      })}

      {/* zone markers */}
      {snap.zones?.map((z: any) => (
        <g key={z.key} className="cursor-pointer" onClick={() => selectZone(z.key === selectedZone ? null : z.key)}>
          <circle cx={z.cx} cy={z.cy} r={6} fill={levelColor(z.level)} opacity={0.95} />
          {(z.level === 'HIGH' || z.level === 'CRITICAL') && (
            <circle cx={z.cx} cy={z.cy} r={9} fill="none" stroke={levelColor(z.level)} strokeWidth={2} className="pulse-ring" />
          )}
        </g>
      ))}

      {/* gates */}
      {snap.gates?.map((g: any) => (
        <g key={g.key} className="cursor-pointer" onClick={() => selectZone(g.key)}>
          <rect x={g.cx - 16} y={g.cy - 16} width={32} height={32} rx={6}
            fill={g.open ? 'rgba(34,211,238,.12)' : 'rgba(248,113,113,.25)'}
            stroke={g.open ? levelColor(g.level === 'LIGHT' ? 'LOW' : g.level) : '#f87171'} strokeWidth={2} />
          <text x={g.cx} y={g.cy + 4} fontSize="12" textAnchor="middle" fill={g.open ? '#a5f3fc' : '#fca5a5'} fontWeight="700">
            {g.open ? g.name.slice(5, 6) : '✕'}
          </text>
          <text x={g.cx} y={g.cy + (g.cy < 40 ? 34 : -24)} fontSize="9.5" textAnchor="middle" fill="#7d8db0" fontFamily="monospace">
            {g.open ? `↓${g.in_per_min}/min ↑${g.out_per_min}/min` : 'CLOSED'}
          </text>
        </g>
      ))}

      {/* parking */}
      {snap.parking?.map((p: any) => {
        const showVal = fut ? fut.parking?.[p.key] : p.occ_pct
        const col = p.closed ? '#f87171' : showVal > 90 ? '#f87171' : showVal > 70 ? '#fbbf24' : '#34d399'
        return (
          <g key={p.key} className="cursor-pointer" onClick={() => selectZone(p.key)}>
            <rect x={p.cx - 26} y={p.cy - 16} width={52} height={32} rx={5}
              fill={p.closed ? 'rgba(248,113,113,.18)' : 'rgba(52,211,153,.08)'} stroke={col} strokeWidth={1.6} />
            <text x={p.cx} y={p.cy - 2} fontSize="12" textAnchor="middle" fill={col} fontWeight="800">P</text>
            <text x={p.cx} y={p.cy + 11} fontSize="9" textAnchor="middle" fill="#cbd5e1" fontFamily="monospace">
              {p.closed ? 'CLOSED' : `${Math.min(999, showVal)}%`}
            </text>
            {!p.closed && p.minutes_to_full !== null && p.minutes_to_full <= 20 && (
              <text x={p.cx} y={p.cy + 26} fontSize="8.5" textAnchor="middle" fill="#fca5a5" fontFamily="monospace">full ~{p.minutes_to_full}m</text>
            )}
          </g>
        )
      })}

      {/* food stalls */}
      {(layer === 'all' || layer === 'food' || layer === 'crowd') && snap.stalls?.map((s: any) => (
        <g key={s.key} className="cursor-pointer" onClick={() => selectZone(s.key)}>
          <circle cx={s.cx} cy={s.cy} r={5.5} fill={s.closed ? '#64748b' : levelColor(s.level)} stroke="#0d1424" strokeWidth={1.5} />
          {layer === 'food' && (
            <text x={s.cx} y={s.cy - 9} fontSize="8.5" textAnchor="middle" fill="#fcd34d" fontFamily="monospace">
              {s.closed ? 'closed' : `${s.wait_min.toFixed(0)}m`}
            </text>
          )}
        </g>
      ))}

      {/* events */}
      {snap.events?.map((ev: any) => {
        const z = snap.zones?.find((zz: any) => zz.key === ev.venue_key)
        if (!z) return null
        return (
          <g key={ev.id}>
            <rect x={z.cx - 44} y={z.cy - 34} width={88} height={15} rx={4} fill="rgba(139,92,246,.25)" stroke="#8b5cf6" strokeWidth={1} />
            <text x={z.cx} y={z.cy - 23} fontSize="8.5" textAnchor="middle" fill="#ddd6fe" fontWeight="700">🎪 {ev.name.slice(0, 16)}</text>
          </g>
        )
      })}

      {/* alerts markers for restricted zone */}
      {snap.restricted_intrusions > 0 && (
        <text x={902} y={140} fontSize="10" textAnchor="middle" fill="#f87171" fontWeight="700">⚠ {snap.restricted_intrusions} intrusion(s)</text>
      )}

      {/* weather badge */}
      <g>
        <rect x={12} y={594} width={230} height={34} rx={8} fill="rgba(13,20,36,.85)" stroke="#1d2a45" />
        <text x={24} y={615} fontSize="11" fill="#93a5c4" fontFamily="monospace">
          {snap.weather.condition === 'heavy_rain' ? '⛈' : snap.weather.condition === 'rain' ? '🌧' : snap.weather.condition === 'cloudy' ? '☁' : '☀'} {snap.weather.temp_c?.toFixed(0)}°C · rain {(snap.weather.rain_prob * 100).toFixed(0)}% · AQI {snap.weather.aqi} · pop {snap.population?.toLocaleString()}
        </text>
      </g>
      {fut && (
        <g>
          <rect x={760} y={594} width={228} height={34} rx={8} fill="rgba(139,92,246,.15)" stroke="#8b5cf6" />
          <text x={774} y={615} fontSize="11" fill="#ddd6fe" fontFamily="monospace">🔮 PREDICTED OVERLAY · +{futureT} min</text>
        </g>
      )}
    </svg>
  )
}
