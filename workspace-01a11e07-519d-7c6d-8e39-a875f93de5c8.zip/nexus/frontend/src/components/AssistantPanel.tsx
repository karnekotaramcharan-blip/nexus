import React from 'react'
import { api } from '../api'
import { Btn, Spinner } from './ui'

export default function AssistantPanel({ compact = false }: { compact?: boolean }) {
  const [msgs, setMsgs] = React.useState<{ role: string; text: string }[]>([
    { role: 'ai', text: 'I am the NEXUS decision assistant. I answer only from live campus data — ask me anything, or ask a "what if" question and I will run a simulation.' }])
  const [input, setInput] = React.useState('')
  const [busy, setBusy] = React.useState(false)
  const [sugs, setSugs] = React.useState<string[]>([])
  const endRef = React.useRef<HTMLDivElement>(null)
  React.useEffect(() => { api('/assistant/suggestions').then(d => setSugs(d.suggestions.slice(0, 6))).catch(() => {}) }, [])
  React.useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs])

  const send = async (text?: string) => {
    const q = (text ?? input).trim()
    if (!q || busy) return
    setInput('')
    setMsgs(m => [...m, { role: 'user', text: q }])
    setBusy(true)
    try {
      const r = await api('/assistant/chat', { method: 'POST', body: { message: q } })
      setMsgs(m => [...m, { role: 'ai', text: r.answer }])
      if (r.simulation) setMsgs(m => [...m, { role: 'sys', text: `Simulation #${r.simulation.simulation_id ?? '—'} executed — open the What-If Simulator for full charts.` }])
    } catch (e: any) {
      setMsgs(m => [...m, { role: 'ai', text: 'Sorry — ' + e.message }])
    } finally { setBusy(false) }
  }

  return (
    <div className="flex flex-col h-full">
      <div className={`flex-1 overflow-y-auto scroll-thin space-y-2 p-3 ${compact ? 'text-xs' : 'text-sm'}`}>
        {msgs.map((m, i) => (
          <div key={i} className={m.role === 'user' ? 'text-right' : ''}>
            <span className={`inline-block px-3 py-2 rounded-xl max-w-[92%] whitespace-pre-wrap ${
              m.role === 'user' ? 'bg-cyan-500/15 border border-cyan-500/30 text-cyan-100'
              : m.role === 'sys' ? 'bg-violet-500/10 border border-violet-500/30 text-violet-200 text-[11px]'
              : 'bg-panel2 border border-edge text-slate-200'}`}>{m.text}</span>
          </div>
        ))}
        {busy && <div className="text-slate-500 text-xs flex items-center gap-2"><Spinner /> thinking…</div>}
        <div ref={endRef} />
      </div>
      <div className="p-2 border-t border-edge">
        <div className="flex flex-wrap gap-1 mb-2">
          {sugs.slice(0, 4).map(s => (
            <button key={s} onClick={() => send(s)} className="text-[10px] px-2 py-0.5 rounded-full border border-edge text-slate-400 hover:text-cyan-300 hover:border-cyan-500/40">{s}</button>
          ))}
        </div>
        <div className="flex gap-2">
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()}
            placeholder="Ask NEXUS… e.g. What if the main gate is closed?"
            className="flex-1 bg-panel2 border border-edge rounded-lg px-3 py-1.5 text-sm outline-none focus:border-cyan-500/50" />
          <Btn variant="primary" size="sm" onClick={() => send()} disabled={busy}>Send</Btn>
        </div>
      </div>
    </div>
  )
}
