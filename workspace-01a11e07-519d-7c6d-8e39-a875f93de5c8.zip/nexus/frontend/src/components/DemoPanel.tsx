import React from 'react'
import { api } from '../api'
import { Btn, Badge } from './ui'
import { useApp } from '../store'
import { useNavigate } from 'react-router-dom'

export function DemoControls() {
  const [controls, setControls] = React.useState<any[]>([])
  const [msg, setMsg] = React.useState('')
  const pushToast = useApp(s => s.pushToast)
  React.useEffect(() => { api('/demo/controls').then(d => setControls(d.controls)).catch(() => {}) }, [])
  const inject = async (c: any) => {
    await api('/demo/inject', { method: 'POST', body: { kind: c.kind, params: c.params } })
    setMsg(`Injected: ${c.label}`)
    pushToast('info', 'Demo control', c.label)
  }
  const reset = async () => { await api('/demo/reset', { method: 'POST' }); setMsg('Simulation reset to calm baseline.') }
  return (
    <div className="p-3 space-y-2">
      <div className="text-[10px] uppercase tracking-widest text-slate-500">Simulation injections (no hardware needed)</div>
      <div className="flex flex-wrap gap-1.5">
        {controls.map(c => (
          <button key={c.kind} onClick={() => inject(c)}
            className="text-[11px] px-2 py-1 rounded-md border border-edge bg-panel2 text-slate-300 hover:border-cyan-500/50 hover:text-cyan-300">
            {c.label}
          </button>
        ))}
      </div>
      <div className="flex items-center gap-2">
        <Btn size="sm" variant="danger" onClick={reset}>⟲ Reset Simulation</Btn>
        <span className="text-[11px] text-slate-500">{msg}</span>
      </div>
    </div>
  )
}

export function DemoDirector() {
  const [state, setState] = React.useState<any>(null)
  const [running, setRunning] = React.useState(false)
  const [result, setResult] = React.useState<string>('')
  const nav = useNavigate()
  const load = () => api('/demo/director').then(setState).catch(() => {})
  React.useEffect(() => { load() }, [])

  const runStep = async (id: number, navigate = true) => {
    setRunning(true)
    try {
      const r = await api(`/demo/director/run/${id}`, { method: 'POST' })
      const step = r.step
      if (navigate && step?.page) nav(step.page)
      setResult(`Step ${id} ✓ — ${Object.keys(r.evidence || {}).length ? 'evidence attached' : 'done'}`)
      await load()
      return r
    } finally { setRunning(false) }
  }

  const autoRun = async () => {
    if (!state) return
    const pending = state.steps.filter((s: any) => !state.completed.includes(s.id))
    for (const s of pending) {
      await runStep(s.id)
      await new Promise(res => setTimeout(res, s.id >= 13 ? 600 : 1600))
    }
  }

  if (!state) return null
  const pct = Math.round((state.completed.length / state.steps.length) * 100)
  return (
    <div className="p-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="text-[10px] uppercase tracking-widest text-slate-500">Demo Director — 20-step sequence</div>
        <div className="flex gap-2">
          <Btn size="sm" variant="primary" onClick={autoRun} disabled={running}>▶ Auto-run remaining</Btn>
          <Btn size="sm" variant="ghost" onClick={() => api('/demo/director/reset', { method: 'POST' }).then(load)}>Reset</Btn>
        </div>
      </div>
      <div className="h-1.5 bg-slate-700/40 rounded-full"><div className="h-full bg-cyan-400 rounded-full transition-all" style={{ width: `${pct}%` }} /></div>
      <div className="max-h-64 overflow-y-auto scroll-thin space-y-1">
        {state.steps.map((s: any) => {
          const done = state.completed.includes(s.id)
          const isNext = !done && (state.step < s.id) && state.steps.filter((x: any) => !state.completed.includes(x.id))[0]?.id === s.id
          return (
            <div key={s.id} className={`flex items-center gap-2 rounded-lg px-2 py-1.5 border ${isNext ? 'border-cyan-500/50 bg-cyan-500/10' : 'border-transparent'}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${done ? 'bg-emerald-500 text-slate-900' : isNext ? 'bg-cyan-400 text-slate-900' : 'bg-slate-700 text-slate-400'}`}>
                {done ? '✓' : s.id}
              </span>
              <div className="flex-1 min-w-0">
                <div className={`text-xs truncate ${done ? 'text-slate-500 line-through' : 'text-slate-200'}`}>{s.title}</div>
                {isNext && <div className="text-[10px] text-cyan-300/80 truncate">{s.hint}</div>}
              </div>
              {!done && <Btn size="sm" variant="ghost" onClick={() => runStep(s.id)} disabled={running}>Run</Btn>}
            </div>
          )
        })}
      </div>
      <div className="text-[10px] text-slate-500">{result} {state.log?.length > 0 && `· last: ${state.log[state.log.length - 1].msg}`}</div>
    </div>
  )
}
