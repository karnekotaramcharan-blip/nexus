import React from 'react'
import { useApp } from '../store'
import { api } from '../api'
import TwinMap from '../components/TwinMap'
import AssistantPanel from '../components/AssistantPanel'
import { DemoControls, DemoDirector } from '../components/DemoPanel'
import { Card, Badge, Stat, Btn, ProgressBar } from '../components/ui'

const LAYERS = [['crowd', '👥 Crowd'], ['traffic', '🚗 Traffic'], ['food', '🍜 Food stalls'], ['all', '🗺 All layers']]

export default function Dashboard() {
  const snap = useApp(s => s.snap)
  const { layer, setLayer, futureT, setFutureT, selectedZone, selectZone } = useApp()
  const [tab, setTab] = React.useState<'alerts' | 'reco' | 'ai' | 'demo' | 'director'>('alerts')
  const [alerts, setAlerts] = React.useState<any[]>([])
  const refreshAlerts = React.useCallback(() => api('/alerts?limit=30').then(setAlerts).catch(() => {}), [])
  React.useEffect(() => { refreshAlerts(); const t = setInterval(refreshAlerts, 8000); return () => clearInterval(t) }, [refreshAlerts])

  if (!snap) return <div className="text-slate-500 p-10">Booting digital twin…</div>
  const r = snap.risk
  const parkTot = snap.parking.reduce((a: number, p: any) => a + p.occupied, 0)
  const parkCap = snap.parking.reduce((a: number, p: any) => a + p.capacity, 0)
  const offline = snap.cameras.filter((c: any) => c.status === 'offline').length
  const sel = selectedZone && (snap.zones.find((z: any) => z.key === selectedZone) || snap.parking.find((p: any) => p.key === selectedZone) || snap.gates.find((g: any) => g.key === selectedZone) || snap.stalls.find((s: any) => s.key === selectedZone))

  return (
    <div className="space-y-3">
      {/* KPI row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-2">
        <Stat label="Campus Status" value={r.level} tone={r.level === 'CRITICAL' ? 'red' : r.level === 'ELEVATED' ? 'amber' : r.level === 'MODERATE' ? 'amber' : 'green'} sub={r.icon + ' risk engine'} />
        <Stat label="AI Engine" value={snap.ai_engine.status.toUpperCase()} tone="cyan" sub="anomaly+forecast" />
        <Stat label="Cameras" value={`${snap.cameras.length - offline}/${snap.cameras.length}`} tone={offline ? 'red' : 'green'} sub={offline ? `${offline} offline` : 'all online'} />
        <Stat label="Active Events" value={snap.events.length} tone="violet" sub={snap.events[0]?.name?.slice(0, 18) || 'none'} />
        <Stat label="Current Crowd" value={snap.population.toLocaleString()} tone="cyan" sub={`${snap.vehicles_on_campus} vehicles`} />
        <Stat label="Parking" value={`${Math.round(parkTot / parkCap * 100)}%`} tone={parkTot / parkCap > 0.9 ? 'red' : 'slate'} sub={`${parkCap - parkTot} free`} />
        <Stat label="Traffic" value={avgCong(snap) > 0.7 ? 'HIGH' : avgCong(snap) > 0.4 ? 'MODERATE' : 'LIGHT'} tone={avgCong(snap) > 0.7 ? 'red' : avgCong(snap) > 0.4 ? 'amber' : 'green'} sub={`idx ${avgCong(snap).toFixed(2)}`} />
        <Stat label="Food Court" value={snap.best_stall ? `~${snap.best_stall.wait_min.toFixed(0)}m` : '—'} tone="amber" sub={snap.best_stall ? `best: ${snap.best_stall.name}` : ''} />
        <Stat label="Risk Score" value={r.score} tone={r.score > 75 ? 'red' : r.score > 55 ? 'amber' : 'green'} sub={`${r.factors?.[0]?.label || ''} +${r.factors?.[0]?.contribution || 0}`} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-3">
        {/* map + controls */}
        <Card className="xl:col-span-3" title="Live Digital Twin"
          right={<div className="flex items-center gap-2 flex-wrap justify-end">
            {LAYERS.map(([k, label]) => (
              <button key={k} onClick={() => setLayer(k)} className={`text-[11px] px-2 py-1 rounded-md border ${layer === k ? 'border-cyan-500/60 text-cyan-300 bg-cyan-500/10' : 'border-edge text-slate-400 hover:text-slate-200'}`}>{label}</button>
            ))}
          </div>}>
          <TwinMap height={540} />
          <div className="px-4 pb-3 flex items-center gap-3 flex-wrap">
            <span className="text-[10px] uppercase tracking-widest text-slate-500">Predicted-future overlay</span>
            {[0, 10, 20, 30].map(t => (
              <button key={t} onClick={() => setFutureT(t)}
                className={`text-[11px] px-2.5 py-1 rounded-md border font-mono ${futureT === t ? 'border-violet-500/60 text-violet-300 bg-violet-500/10' : 'border-edge text-slate-400 hover:text-slate-200'}`}>
                {t === 0 ? 'NOW' : `+${t}m`}
              </button>
            ))}
            <span className="text-[10px] text-slate-500">Click any zone, gate, parking or stall for details</span>
          </div>
          {sel && <ZoneDetail sel={sel} snap={snap} close={() => selectZone(null)} />}
        </Card>

        {/* side panel */}
        <div className="space-y-3">
          <Card title={`Risk Engine — ${r.score}/100 ${r.level}`}>
            <div className="px-4 pb-3">
              <div className="flex items-center gap-3">
                <div className="relative w-20 h-20 shrink-0">
                  <svg viewBox="0 0 80 80" className="w-20 h-20 -rotate-90">
                    <circle cx="40" cy="40" r="34" fill="none" stroke="#1d2a45" strokeWidth="9" />
                    <circle cx="40" cy="40" r="34" fill="none" strokeWidth="9" strokeLinecap="round"
                      stroke={r.score > 75 ? '#f87171' : r.score > 55 ? '#fb923c' : r.score > 30 ? '#fbbf24' : '#34d399'}
                      strokeDasharray={`${r.score * 2.136} 213.6`} />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="text-xl font-black">{r.score}</div>
                    <div className="text-[8px] text-slate-400">/100</div>
                  </div>
                </div>
                <div className="flex-1 space-y-1 min-w-0">
                  {r.factors?.slice(0, 4).map((f: any) => (
                    <div key={f.key} className="flex items-center gap-2 text-[11px]">
                      <span className="w-16 text-slate-400 truncate">{f.label}</span>
                      <div className="flex-1"><ProgressBar value={f.contribution / 0.3} /></div>
                      <span className="w-8 text-right font-mono text-slate-300">+{f.contribution.toFixed(0)}</span>
                    </div>
                  ))}
                </div>
              </div>
              {r.factors?.[0]?.reasons?.map((x: string, i: number) => (
                <div key={i} className="text-[10px] text-slate-500 mt-1">• {x}</div>
              ))}
            </div>
          </Card>

          <Card className="min-h-[380px] flex flex-col" title="" >
            <div className="flex border-b border-edge text-xs">
              {(['alerts', 'reco', 'ai', 'demo', 'director'] as const).map(t => (
                <button key={t} onClick={() => setTab(t)}
                  className={`px-3 py-2 uppercase tracking-wider text-[10px] font-bold ${tab === t ? 'text-cyan-300 border-b-2 border-cyan-400' : 'text-slate-500 hover:text-slate-300'}`}>
                  {t === 'reco' ? 'Actions' : t === 'ai' ? 'AI Assistant' : t === 'demo' ? 'Demo Mode' : t === 'director' ? 'Director' : `Alerts (${alerts.filter(a => a.status === 'new').length})`}
                </button>
              ))}
            </div>
            {tab === 'alerts' && (
              <div className="overflow-y-auto scroll-thin max-h-[430px] divide-y divide-edge/60">
                {alerts.length === 0 && <div className="p-4 text-xs text-slate-500">No alerts yet — campus normal.</div>}
                {alerts.map(a => (
                  <div key={a.id} className="p-2.5">
                    <div className="flex items-center gap-2">
                      <Badge tone={a.severity}>{a.severity}</Badge>
                      <span className="text-xs font-bold text-slate-200 truncate">{a.location}</span>
                      <Badge tone={a.status}>{a.status}</Badge>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1">{a.reason}</div>
                    <div className="text-[10px] text-violet-300/80 mt-0.5">🔮 {a.prediction}</div>
                    <div className="text-[10px] text-emerald-300/80">✓ {a.action}</div>
                    {a.status === 'new' && (
                      <div className="flex gap-1.5 mt-1.5">
                        <Btn size="sm" onClick={() => api(`/alerts/${a.id}`, { method: 'PATCH', body: { status: 'acknowledged' } }).then(() => api('/alerts?limit=30').then(setAlerts))}>Ack</Btn>
                        <Btn size="sm" variant="ok" onClick={() => api(`/alerts/${a.id}`, { method: 'PATCH', body: { status: 'resolved' } }).then(() => api('/alerts?limit=30').then(setAlerts))}>Resolve</Btn>
                        <Btn size="sm" variant="ghost" onClick={() => api(`/alerts/${a.id}`, { method: 'PATCH', body: { status: 'dismissed' } }).then(() => api('/alerts?limit=30').then(setAlerts))}>Dismiss</Btn>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
            {tab === 'reco' && (
              <div className="overflow-y-auto scroll-thin max-h-[430px] divide-y divide-edge/60">
                {snap.recommendations?.length === 0 && <div className="p-4 text-xs text-slate-500">No recommendations — operations healthy.</div>}
                {snap.recommendations?.map((rec: any) => (
                  <RecoRow key={rec.id} rec={rec} />
                ))}
              </div>
            )}
            {tab === 'ai' && <div className="h-[430px]"><AssistantPanel compact /></div>}
            {tab === 'demo' && <DemoControls />}
            {tab === 'director' && <DemoDirector />}
          </Card>
        </div>
      </div>
    </div>
  )
}

function avgCong(snap: any) {
  const rs = snap.roads || []
  return rs.length ? rs.reduce((a: number, r: any) => a + r.congestion, 0) / rs.length : 0
}

function RecoRow({ rec }: any) {
  const [done, setDone] = React.useState('')
  return (
    <div className="p-2.5">
      <div className="text-xs font-bold text-slate-200">{rec.title}</div>
      <div className="text-[11px] text-slate-400 mt-0.5">{rec.detail}</div>
      <div className="text-[10px] text-slate-500 mt-0.5">source: {rec.source} · expected risk reduction ≈ {rec.expected_risk_reduction} pts</div>
      {!done && (
        <div className="flex gap-1.5 mt-1.5">
          <Btn size="sm" variant="ok" onClick={async () => { await api(`/recommendations/${rec.id}/feedback`, { method: 'POST', body: { feedback: 'accepted' } }); setDone('accepted') }}>Accept</Btn>
          <Btn size="sm" variant="ghost" onClick={async () => { await api(`/recommendations/${rec.id}/feedback`, { method: 'POST', body: { feedback: 'dismissed' } }); setDone('dismissed') }}>Dismiss</Btn>
        </div>
      )}
      {done && <div className="text-[10px] text-emerald-300 mt-1">✓ Marked {done} — outcome will be tracked against live metrics.</div>}
    </div>
  )
}

function ZoneDetail({ sel, snap, close }: any) {
  const isZone = sel.crowd !== undefined
  const isParking = sel.occupied !== undefined
  const isGate = sel.in_per_min !== undefined
  const isStall = sel.queue !== undefined
  return (
    <div className="mx-4 mb-3 panel-light p-3 flex items-start gap-4 flex-wrap text-xs">
      <div className="font-bold text-cyan-300">{sel.name} <button className="text-slate-500 ml-2" onClick={close}>✕</button></div>
      {isZone && <><span>Crowd <b className="text-slate-100">{sel.crowd}</b> / {sel.capacity}</span><span>Density <b>{Math.round(sel.density * 100)}%</b></span><Badge tone={sel.level}>{sel.level}</Badge></>}
      {isParking && <><span>Occupied <b className="text-slate-100">{sel.occupied}</b> / {sel.capacity}</span><span>{sel.occ_pct}%</span>{sel.minutes_to_full != null && <span className="text-amber-300">full in ~{sel.minutes_to_full} min</span>}</>}
      {isGate && <><span>In <b className="text-emerald-300">{sel.in_per_min}/min</b></span><span>Out <b className="text-amber-300">{sel.out_per_min}/min</b></span><Badge tone={sel.open ? sel.level : 'critical'}>{sel.open ? sel.level : 'CLOSED'}</Badge></>}
      {isStall && <><span>Queue <b className="text-slate-100">{sel.queue}</b></span><span>Wait <b>~{sel.wait_min} min</b></span><Badge tone={sel.closed ? 'offline' : sel.level}>{sel.closed ? 'CLOSED' : sel.level}</Badge>
        <span className="text-slate-400">forecast wait: {sel.forecast_wait?.map((w: number, i: number) => `+${[10, 20, 30][i]}m≈${w}`).join(' · ')}</span></>}
    </div>
  )
}
