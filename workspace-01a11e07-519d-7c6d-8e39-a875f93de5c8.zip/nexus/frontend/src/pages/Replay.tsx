import React from 'react'
import { api } from '../api'
import { Card, Btn, Select } from '../components/ui'

export default function Replay() {
  const [days, setDays] = React.useState<string[]>([])
  const [day, setDay] = React.useState('')
  const [data, setData] = React.useState<any>(null)
  const [idx, setIdx] = React.useState(0)
  const [playing, setPlaying] = React.useState(false)
  const [speed, setSpeed] = React.useState(1)

  React.useEffect(() => { api('/replay/days').then(d => { setDays(d.days); if (d.days[1]) setDay(d.days[1]) }) }, [])
  React.useEffect(() => { if (day) api(`/replay/day?day=${day}`).then(d => { setData(d); setIdx(0) }) }, [day])
  React.useEffect(() => {
    if (!playing || !data) return
    const t = setInterval(() => setIdx(i => {
      if (i >= data.frames.length - 1) { setPlaying(false); return i }
      return i + 1
    }), 900 / speed)
    return () => clearInterval(t)
  }, [playing, speed, data])

  if (!data) return <div className="text-slate-500">Loading replay…</div>
  const f = data.frames[Math.min(idx, data.frames.length - 1)]
  const maxPop = Math.max(...data.frames.map((x: any) => x.population), 1)

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-lg font-bold">⏪ Campus Event Replay</h1>
        <div className="flex gap-2 items-center">
          <Select value={day} onChange={(e: any) => setDay(e.target.value)}>
            {days.map(d => <option key={d} value={d}>{d === new Date().toISOString().slice(0, 10) ? 'Today' : d}</option>)}
          </Select>
          <Btn variant="ghost" size="sm" onClick={() => setSpeed(s => s === 1 ? 2 : s === 2 ? 4 : 1)}>⏩ {speed}×</Btn>
          <Btn variant={playing ? 'danger' : 'primary'} size="sm" onClick={() => setPlaying(p => !p)}>{playing ? '⏸ Pause' : '▶ Play'}</Btn>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-3">
        <Card title={`Twin state at ${f?.t}`} className="lg:col-span-2 p-3 pt-1">
          <svg viewBox="0 0 1000 640" className="w-full" style={{ maxHeight: 480 }}>
            <rect width="1000" height="640" fill="#070d1a" rx="12" />
            {Object.entries(f?.zones || {}).map(([k, v]: any) => {
              const pos: Record<string, [number, number]> = {
                admin_block: [120, 95], library: [255, 225], acad_a: [235, 385], acad_b: [400, 470],
                auditorium: [500, 265], plaza: [470, 380], sports: [850, 175], food_court: [700, 430],
                lake: [905, 470], research: [900, 80],
              }
              const [x, y] = pos[k] || [500, 320]
              const r = Math.min(80, 8 + v / 18)
              return <g key={k}>
                <circle cx={x} cy={y} r={r} fill="#f87171" opacity={Math.min(0.6, v / 900)} />
                <circle cx={x} cy={y} r={5} fill={v > 700 ? '#f87171' : v > 350 ? '#fbbf24' : '#34d399'} />
                <text x={x} y={y + r + 14} fontSize="11" textAnchor="middle" fill="#93a5c4" fontFamily="monospace">{k} · {v}</text>
              </g>
            })}
            <text x={20} y={34} fontSize="20" fill="#22d3ee" fontFamily="monospace">{f?.t} — pop {f?.population?.toLocaleString()} · parking {f?.parking?.toFixed(0)}% · congestion {f?.congestion?.toFixed(2)}</text>
            <rect x={20} y={600} width={960 * ((f?.population || 0) / maxPop)} height={10} fill="#22d3ee" rx={5} opacity={0.7} />
            <text x={20} y={590} fontSize="11" fill="#475569">population timeline</text>
          </svg>
          <div className="px-2 pb-2">
            <input type="range" min={0} max={data.frames.length - 1} value={idx} onChange={e => setIdx(+e.target.value)} className="w-full accent-cyan-400" />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>{data.frames[0]?.t}</span><span className="text-cyan-300">{f?.t}</span><span>{data.frames[data.frames.length - 1]?.t}</span>
            </div>
          </div>
        </Card>
        <Card title="Auto-generated narrative" className="p-3 pt-1">
          <div className="space-y-1.5 max-h-[420px] overflow-auto scroll-thin">
            {data.narrative.map((n: any, i: number) => {
              const active = n.t <= f?.t
              return (
                <div key={i} className={`flex gap-2 text-xs rounded-lg px-2 py-1.5 border ${active ? 'border-cyan-500/30 bg-cyan-500/5 text-slate-200' : 'border-transparent text-slate-500'}`}>
                  <span className="font-mono text-cyan-400 shrink-0">{n.t}</span>
                  <span>{n.text}</span>
                </div>
              )
            })}
            {data.narrative.length === 0 && <div className="text-xs text-slate-500">A calm day — nothing significant detected.</div>}
            <div className="panel-light p-2 text-[11px] text-violet-300 mt-2">🔗 {data.cause_chain}</div>
          </div>
        </Card>
      </div>
    </div>
  )
}
