import React from 'react'
import { api } from '../api'
import { Card, Badge, Btn, Input, Modal, Spinner } from '../components/ui'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

export default function Cameras() {
  const [cams, setCams] = React.useState<any[]>([])
  const [result, setResult] = React.useState<any>(null)
  const [busy, setBusy] = React.useState(false)
  const [showAdd, setShowAdd] = React.useState(false)
  const [form, setForm] = React.useState({ name: '', zone_key: '', source_type: 'demo', fps: 24 })
  const fileRef = React.useRef<HTMLInputElement>(null)

  const load = () => api('/cameras').then(setCams).catch(() => {})
  React.useEffect(() => { load(); const t = setInterval(load, 10000); return () => clearInterval(t) }, [])

  const analyze = async (camId: string, useDemo: boolean) => {
    setBusy(true); setResult(null)
    try {
      let r
      if (useDemo) {
        r = await api(`/cameras/${camId}/analyze?use_demo=true`, { method: 'POST' })
      } else {
        const f = fileRef.current?.files?.[0]
        if (!f) { setBusy(false); return }
        const fd = new FormData()
        fd.append('file', f)
        const res = await fetch(`/api/v1/cameras/${camId}/analyze`, { method: 'POST', credentials: 'include', body: fd })
        r = await res.json()
      }
      setResult(r)
      load()
    } catch (e: any) { setResult({ error: e.message }) } finally { setBusy(false) }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold">📹 Camera Management <span className="text-xs text-slate-500 font-normal">— credentials stay encrypted server-side, never sent to the UI</span></h1>
        <Btn variant="primary" onClick={() => setShowAdd(true)}>+ Add camera</Btn>
      </div>

      <Card title="Camera fleet" className="p-3 pt-1 overflow-x-auto scroll-thin">
        <table className="w-full text-xs">
          <thead><tr className="text-slate-500 text-left border-b border-edge">
            <th className="py-1.5">Camera</th><th>Location</th><th>Status</th><th>AI</th><th>FPS</th><th>Last update</th><th>Actions</th></tr></thead>
          <tbody>
            {cams.map(c => (
              <tr key={c.cam_id} className="border-b border-edge/40">
                <td className="py-2 font-mono font-bold text-cyan-300">{c.cam_id}</td>
                <td>{c.name} <span className="text-slate-500">({c.zone_key})</span></td>
                <td><Badge tone={c.status}>{c.status}</Badge></td>
                <td><Badge tone={c.ai_status === 'active' ? 'online' : 'offline'}>{c.ai_status}</Badge></td>
                <td className="font-mono">{c.fps}</td>
                <td className="font-mono text-slate-400">{c.last_update ? new Date(c.last_update).toLocaleTimeString() : '—'}</td>
                <td className="space-x-1 whitespace-nowrap">
                  <Btn size="sm" variant="ghost" onClick={() => api(`/cameras/${c.cam_id}/toggle`, { method: 'POST' }).then(load)}>{c.status === 'online' ? 'Disable' : 'Enable'}</Btn>
                  <Btn size="sm" onClick={() => analyze(c.cam_id, true)} disabled={busy}>▶ Analyze demo video</Btn>
                  <Btn size="sm" variant="ghost" onClick={() => { (window as any).__cam = c.cam_id; fileRef.current?.click() }} disabled={busy}>⬆ Upload</Btn>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <input ref={fileRef} type="file" accept="video/*" className="hidden"
          onChange={async (e) => { const cam = (window as any).__cam; if (cam) await analyze(cam, false); e.target.value = '' }} />
      </Card>

      {busy && <Card className="p-4 text-sm text-slate-400 flex items-center gap-2"><Spinner /> AI service analyzing video (person/vehicle detection, line crossing, queue region, face blur)…</Card>}

      {result && !result.error && (
        <div className="grid lg:grid-cols-3 gap-3">
          <Card title={`CV analysis — ${result.camera_id} (${result.backend})`} className="p-4">
            <div className="grid grid-cols-2 gap-2 text-center text-sm">
              {[
                ['Persons (peak)', result.summary.person_detections_peak],
                ['Vehicles (peak)', result.summary.vehicle_detections_peak],
                ['Entries', result.summary.entries], ['Exits', result.summary.exits],
                ['Queue peak', result.summary.queue_peak], ['Queue avg', result.summary.queue_avg],
                ['Avg density', result.summary.avg_density], ['Restricted intrusions', result.summary.restricted_zone_intrusions],
              ].map(([l, v]: any) => (
                <div key={l} className="panel-light p-2"><div className="text-[9px] uppercase text-slate-500">{l}</div><div className="font-mono font-bold text-cyan-300">{v}</div></div>
              ))}
            </div>
            <div className="text-[10px] text-emerald-300/80 mt-2">🔒 {result.privacy.note} Face blur: {result.privacy.face_blur ? 'ON' : 'off'} · identity tracking: never.</div>
          </Card>
          <Card title="Detections over time" className="p-3 pt-1">
            <div className="h-52">
              <ResponsiveContainer>
                <LineChart data={result.series?.filter((_: any, i: number) => i % 2 === 0)}>
                  <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
                  <XAxis dataKey="t" stroke="#475569" fontSize={9} /><YAxis stroke="#475569" fontSize={10} />
                  <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} />
                  <Line dataKey="persons" stroke="#22d3ee" dot={false} strokeWidth={1.8} />
                  <Line dataKey="vehicles" stroke="#8b5cf6" dot={false} strokeWidth={1.6} />
                  <Line dataKey="queue" stroke="#fbbf24" dot={false} strokeWidth={1.4} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <Card title="Annotated frames (faces blurred)" className="p-3 pt-1">
            <div className="grid grid-cols-2 gap-2">
              {result.sample_frames?.slice(0, 4).map((f: string) => (
                <img key={f} src={f} className="rounded-lg border border-edge w-full" alt="annotated frame" />
              ))}
            </div>
          </Card>
        </div>
      )}
      {result?.error && <div className="panel-light p-3 text-xs text-red-300">{result.error}</div>}

      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add camera">
        <div className="space-y-2">
          <Input placeholder="Name (e.g. Library Entrance)" value={form.name} onChange={(e: any) => setForm({ ...form, name: e.target.value })} />
          <Input placeholder="Zone key (e.g. library)" value={form.zone_key} onChange={(e: any) => setForm({ ...form, zone_key: e.target.value })} />
          <div className="flex gap-2">
            <select className="bg-panel2 border border-edge rounded-lg px-3 py-1.5 text-sm flex-1" value={form.source_type} onChange={(e: any) => setForm({ ...form, source_type: e.target.value })}>
              <option value="demo">Demo (simulated)</option><option value="rtsp">RTSP live feed</option><option value="upload">Uploaded video</option>
            </select>
            <Input type="number" className="w-24" value={form.fps} onChange={(e: any) => setForm({ ...form, fps: +e.target.value })} />
          </div>
          <div className="text-[10px] text-slate-500">RTSP credentials are configured server-side (env secrets) and never exposed to the frontend.</div>
          <Btn variant="primary" className="w-full" onClick={async () => { await api('/cameras', { method: 'POST', body: form }); setShowAdd(false); load() }}>Add</Btn>
        </div>
      </Modal>
    </div>
  )
}
