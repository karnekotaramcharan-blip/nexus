import React from 'react'
import { api } from '../api'
import { Card, Btn, Input, Select, Badge, Spinner } from '../components/ui'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, BarChart, Bar } from 'recharts'

const SCENARIOS: Record<string, { label: string; params: Record<string, any> }> = {
  gate_closed: { label: 'Close a main gate', params: { gate: 'gate1' } },
  event_crowd_increase: { label: 'Event attracts more people (×1.8)', params: { multiplier: 1.8 } },
  parking_closed: { label: 'Parking zone unavailable', params: { zone: 'park_a' } },
  extra_vehicles: { label: '30% more vehicles', params: { multiplier: 1.3 } },
  heavy_rain: { label: 'Heavy rain during event', params: {} },
  stall_closed: { label: 'Food stall shut down', params: { stall: 'snack_corner' } },
  food_court_closed: { label: 'Food court closed', params: {} },
  event_extended: { label: 'Event extended by 2 hours', params: {} },
  lunch_shifted: { label: 'Lunch break extended/shifted', params: {} },
  crowd_surge: { label: 'Sudden crowd surge (+1,200)', params: { total: 1200 } },
  evacuation: { label: 'Emergency evacuation', params: { zone: 'auditorium' } },
}

export default function WhatIf() {
  const [nl, setNl] = React.useState('')
  const [scenario, setScenario] = React.useState('gate_closed')
  const [params, setParams] = React.useState<any>(SCENARIOS.gate_closed.params)
  const [result, setResult] = React.useState<any>(null)
  const [compare, setCompare] = React.useState<any>(null)
  const [busy, setBusy] = React.useState(false)
  const [history, setHistory] = React.useState<any[]>([])
  const [timeIdx, setTimeIdx] = React.useState(30)
  const [err, setErr] = React.useState('')

  const loadHistory = () => api('/simulations/history').then(setHistory).catch(() => {})
  React.useEffect(() => { loadHistory() }, [result?.ran_at])

  const runNL = async () => {
    if (!nl.trim()) return
    setBusy(true); setErr('')
    try {
      const r = await api('/simulations/run-nl', { method: 'POST', body: { query: nl } })
      if (!r.matched) setErr(r.message)
      else { setResult(r); setCompare(null) }
    } catch (e: any) { setErr(e.message) } finally { setBusy(false) }
  }
  const runForm = async () => {
    setBusy(true); setErr('')
    try {
      const r = await api('/simulations/run', { method: 'POST', body: { scenario, params, save: true } })
      setResult(r); setCompare(null)
    } catch (e: any) { setErr(e.message) } finally { setBusy(false) }
  }
  const loadCompare = async (id: number) => {
    const r = await api(`/simulations/${id}`)
    setCompare(r)
  }

  const onScenario = (s: string) => { setScenario(s); setParams(SCENARIOS[s].params) }

  return (
    <div className="space-y-3">
      <h1 className="text-lg font-bold">⭐ What-If Simulator <span className="text-xs text-slate-500 font-normal">— same engine as the live twin, so numbers stay consistent</span></h1>

      <div className="grid lg:grid-cols-3 gap-3">
        <Card title="Ask in natural language" className="p-4 pt-2 lg:col-span-2">
          <div className="flex gap-2">
            <Input value={nl} onChange={(e: any) => setNl(e.target.value)} onKeyDown={(e: any) => e.key === 'Enter' && runNL()}
              placeholder='e.g. "What happens if the main gate is closed?" · "30% more vehicles" · "heavy rain"' />
            <Btn variant="primary" onClick={runNL} disabled={busy}>{busy ? <Spinner /> : 'Simulate'}</Btn>
          </div>
        </Card>
        <Card title="Structured scenario" className="p-4 pt-2">
          <div className="space-y-2">
            <Select value={scenario} onChange={(e: any) => onScenario(e.target.value)} className="w-full">
              {Object.entries(SCENARIOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </Select>
            {scenario === 'gate_closed' && <Select value={params.gate} onChange={(e: any) => setParams({ gate: e.target.value })} className="w-full">
              <option value="gate1">Gate 1 — Main Gate</option><option value="gate2">Gate 2 — North</option><option value="gate3">Gate 3 — East</option></Select>}
            {scenario === 'parking_closed' && <Select value={params.zone} onChange={(e: any) => setParams({ zone: e.target.value })} className="w-full">
              <option value="park_a">Zone A</option><option value="park_b">Zone B</option><option value="park_c">Zone C</option><option value="park_d">Zone D</option></Select>}
            {scenario === 'stall_closed' && <Select value={params.stall} onChange={(e: any) => setParams({ stall: e.target.value })} className="w-full">
              {['main_canteen', 'snack_corner', 'juice_bar', 'coffee_kiosk', 'south_indian', 'chinese', 'bakery', 'ice_cream'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</Select>}
            {scenario === 'extra_vehicles' && <div className="flex items-center gap-2 text-xs text-slate-400">Multiplier
              <Input type="number" step="0.1" min="1" value={params.multiplier} onChange={(e: any) => setParams({ multiplier: +e.target.value })} className="w-20" /></div>}
            {scenario === 'event_crowd_increase' && <div className="flex items-center gap-2 text-xs text-slate-400">Crowd ×
              <Input type="number" step="0.2" min="1" value={params.multiplier} onChange={(e: any) => setParams({ multiplier: +e.target.value })} className="w-20" /></div>}
            <Btn variant="primary" className="w-full" onClick={runForm} disabled={busy}>Run Simulation (60 min horizon)</Btn>
          </div>
        </Card>
      </div>
      {err && <div className="text-xs text-amber-300 panel-light p-3">{err}</div>}

      {result && (
        <>
          <div className="grid md:grid-cols-4 gap-2">
            <Card className="p-3"><div className="text-[10px] uppercase text-slate-500">Scenario</div><div className="font-bold text-slate-100 text-sm">{result.scenario_label}</div><div className="text-[10px] text-slate-500">{result.message}</div></Card>
            <Card className="p-3"><div className="text-[10px] uppercase text-slate-500">Risk: Reality → Simulated</div>
              <div className="font-mono font-bold"><span className="text-slate-200">{result.risk_current}</span> <span className="text-cyan-400">→</span> <span className={result.risk_simulated > result.risk_current ? 'text-red-400' : 'text-emerald-400'}>{result.risk_simulated}</span></div></Card>
            <Card className="p-3"><div className="text-[10px] uppercase text-slate-500">Population</div>
              <div className="font-mono text-sm">{result.impacts.population.now.toLocaleString()} → <b className="text-cyan-300">{result.impacts.population.simulated.toLocaleString()}</b></div></Card>
            <Card className="p-3"><div className="text-[10px] uppercase text-slate-500">Food queues total</div>
              <div className="font-mono text-sm">{result.impacts.food_court_total_queue.now} → <b className="text-amber-300">{result.impacts.food_court_total_queue.simulated}</b></div></Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-3">
            <Card title="CURRENT REALITY vs SIMULATED FUTURE (60 min)" className="lg:col-span-2 p-3 pt-1">
              <input type="range" min={0} max={(result.simulated_series?.length || 1) - 1} value={Math.min(timeIdx, (result.simulated_series?.length || 1) - 1)}
                onChange={e => setTimeIdx(+e.target.value)} className="w-full accent-cyan-400" />
              <div className="h-60">
                <ResponsiveContainer>
                  <LineChart data={chartData(result)}>
                    <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
                    <XAxis dataKey="t" stroke="#475569" fontSize={10} />
                    <YAxis stroke="#475569" fontSize={10} />
                    <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Line dataKey="base_pop" name="Population (reality path)" stroke="#64748b" dot={false} strokeWidth={1.6} />
                    <Line dataKey="sim_pop" name="Population (simulated)" stroke="#22d3ee" dot={false} strokeWidth={2.2} />
                    <Line dataKey="sim_park" name="Parking % (simulated)" stroke="#fbbf24" dot={false} strokeWidth={1.6} />
                    <Line dataKey="sim_cong" name="Gate congestion ×100 (simulated)" stroke="#f87171" dot={false} strokeWidth={1.4} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              {result.simulated_series?.[timeIdx] && (
                <div className="text-[11px] font-mono text-slate-400 px-1">
                  t={result.simulated_series[timeIdx].t} · pop {result.simulated_series[timeIdx].population} · parking {result.simulated_series[timeIdx].parking_occ}% · gate-cong {result.simulated_series[timeIdx].max_gate_congestion} · max stall wait {result.simulated_series[timeIdx].max_stall_wait}m
                </div>
              )}
            </Card>
            <Card title="Impact summary" className="p-3 pt-1 text-xs space-y-2 overflow-auto max-h-[340px] scroll-thin">
              <div><b className="text-slate-300">Gates:</b>{Object.entries(result.impacts.gates).map(([k, g]: any) => (
                <div key={k} className="flex justify-between font-mono"><span>{k} {!g.open && <Badge tone="critical">closed</Badge>}</span><span>{g.now} → <b className={g.sim > g.now ? 'text-red-400' : 'text-emerald-400'}>{g.sim}</b></span></div>))}
              </div>
              <div><b className="text-slate-300">Parking:</b>{Object.entries(result.impacts.parking).map(([k, p]: any) => (
                <div key={k} className="flex justify-between font-mono"><span>{k} {p.closed && <Badge tone="critical">closed</Badge>}</span><span>{p.now_occ_pct}% → <b className={p.sim_occ_pct > p.now_occ_pct ? 'text-amber-300' : 'text-emerald-400'}>{p.sim_occ_pct}%</b></span></div>))}
              </div>
              <div><b className="text-slate-300">Stalls:</b>{Object.entries(result.impacts.stalls).map(([k, s]: any) => (
                <div key={k} className="flex justify-between font-mono"><span>{k.replace('_', ' ')} {s.closed && <Badge tone="critical">closed</Badge>}</span><span>{s.now_wait.toFixed(0)}m → <b className={s.sim_wait > s.now_wait ? 'text-amber-300' : 'text-emerald-400'}>{s.sim_wait.toFixed(0)}m</b></span></div>))}
              </div>
              {result.evacuation && (
                <div className="panel-light p-2"><b className="text-red-300">🚨 Evacuation estimate:</b>
                  <div>{result.evacuation.population} people via {result.evacuation.open_gates} open gates ≈ <b>{result.evacuation.est_evac_minutes} min</b></div>
                  <div>Bottlenecks: {result.evacuation.bottlenecks.join(', ')} · Assembly: {result.evacuation.assembly.join('; ')}</div>
                  <div className="text-slate-500 text-[10px]">{result.evacuation.note}</div></div>
              )}
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-3">
            <Card title="Recommended strategy (ranked by expected risk reduction)" className="p-3 pt-1">
              {result.recommendations?.map((rec: any, i: number) => (
                <div key={i} className="py-1.5 border-b border-edge/40 last:border-0">
                  <div className="text-sm text-slate-200">{i + 1}. {rec.title} <span className="text-[10px] text-emerald-400 font-mono">−{rec.risk_reduction} risk</span></div>
                  <div className="text-[11px] text-slate-500">{rec.why}</div>
                </div>
              ))}
            </Card>
            <Card title="Strategy comparison (saved simulations)" className="p-3 pt-1">
              <div className="text-[11px] text-slate-500 mb-2">Pick a saved simulation to compare side-by-side with the current one:</div>
              <div className="space-y-1 max-h-40 overflow-auto scroll-thin">
                {history.slice(0, 10).map(h => (
                  <div key={h.id} className="flex items-center gap-2 text-xs">
                    <span className="flex-1 truncate text-slate-300">#{h.id} {h.name}</span>
                    <span className="font-mono text-slate-500">{h.risk_current}→{h.risk_simulated}</span>
                    <Btn size="sm" variant="ghost" onClick={() => loadCompare(h.id)}>Compare</Btn>
                  </div>
                ))}
              </div>
              {compare && (
                <div className="mt-2 panel-light p-2 h-44">
                  <div className="text-[10px] uppercase text-slate-500 mb-1">A: {result.scenario_label} · B: {compare.name}</div>
                  <ResponsiveContainer>
                    <BarChart data={[
                      { name: 'Risk (now)', A: result.risk_current, B: compare.risk_current },
                      { name: 'Risk (simulated)', A: result.risk_simulated, B: compare.risk_simulated },
                      { name: 'Peak pop/100', A: Math.max(...result.simulated_series.map((x: any) => x.population)) / 100, B: Math.max(...(compare.simulated_series || []).map((x: any) => x.population)) / 100 },
                    ]}>
                      <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
                      <XAxis dataKey="name" stroke="#475569" fontSize={10} />
                      <YAxis stroke="#475569" fontSize={10} />
                      <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                      <Bar dataKey="A" fill="#22d3ee" /><Bar dataKey="B" fill="#8b5cf6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>
          </div>
        </>
      )}
    </div>
  )
}

function chartData(result: any) {
  const b = result.baseline_series || []
  const s = result.simulated_series || []
  return s.map((p: any, i: number) => ({
    t: p.t,
    base_pop: b[i]?.population,
    sim_pop: p.population,
    sim_park: p.parking_occ,
    sim_cong: +(p.max_gate_congestion * 100).toFixed(0),
  }))
}
