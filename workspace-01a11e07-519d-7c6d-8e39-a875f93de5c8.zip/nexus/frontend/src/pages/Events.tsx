import React from 'react'
import { api } from '../api'
import { Card, Badge, Btn, Input, Select, Modal } from '../components/ui'

export default function Events() {
  const [events, setEvents] = React.useState<any[]>([])
  const [showNew, setShowNew] = React.useState(false)
  const [form, setForm] = React.useState({ name: '', venue_key: 'auditorium', expected_attendance: 800, duration_min: 180, description: '' })
  const load = () => api('/events').then(setEvents).catch(() => {})
  React.useEffect(() => { load(); const t = setInterval(load, 10000); return () => clearInterval(t) }, [])

  const create = async () => {
    await api('/events', { method: 'POST', body: form })
    setShowNew(false); load()
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold">🎪 Event Intelligence</h1>
        <Btn variant="primary" onClick={() => setShowNew(true)}>+ New Event</Btn>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        {events.map(ev => (
          <Card key={ev.id} className="p-4">
            <div className="flex items-center justify-between">
              <div className="font-bold text-slate-100">{ev.name}</div>
              <div className="flex gap-1.5"><Badge tone={ev.status === 'live' ? 'live' : ev.status}>{ev.status}</Badge><Badge tone={ev.risk}>{ev.risk} RISK</Badge></div>
            </div>
            <div className="text-[11px] text-slate-500">{ev.venue_key} · {new Date(ev.start_ts).toLocaleString()} → {new Date(ev.end_ts).toLocaleTimeString()}</div>
            <div className="grid grid-cols-4 gap-2 mt-3 text-center text-xs">
              <div><div className="text-[9px] uppercase text-slate-500">Expected</div><div className="font-mono font-bold">{ev.expected_attendance}</div></div>
              <div><div className="text-[9px] uppercase text-slate-500">Current</div><div className="font-mono font-bold text-cyan-300">{ev.current}</div></div>
              <div><div className="text-[9px] uppercase text-slate-500">Pred. peak</div><div className={`font-mono font-bold ${ev.predicted_peak > ev.capacity ? 'text-red-300' : 'text-slate-200'}`}>{ev.predicted_peak}</div></div>
              <div><div className="text-[9px] uppercase text-slate-500">Capacity</div><div className="font-mono font-bold">{ev.capacity}</div></div>
            </div>
            <div className="mt-2"><div className="flex justify-between text-[10px] text-slate-500"><span>occupancy {ev.occupancy_pct}%</span>{ev.predicted_peak > ev.capacity && <span className="text-red-300">⚠ predicted peak exceeds capacity</span>}</div>
              <div className="h-1.5 bg-slate-700/40 rounded-full mt-1"><div className="h-full bg-cyan-400 rounded-full" style={{ width: `${Math.min(100, ev.occupancy_pct)}%` }} /></div>
            </div>
            <div className="mt-3 text-[11px] text-slate-400 grid grid-cols-2 gap-1">
              <span>🅿 {ev.impact.parking}</span><span>🚗 {ev.impact.traffic}</span>
              <span>🍜 {ev.impact.stalls}</span><span>⚡ {ev.impact.resources}</span>
            </div>
            {ev.status !== 'ended' && <Btn size="sm" variant="danger" className="mt-3" onClick={async () => { await api(`/events/${ev.id}`, { method: 'DELETE' }); load() }}>End event</Btn>}
          </Card>
        ))}
        {events.length === 0 && <div className="text-slate-500 text-sm">No events yet — create one or use Demo Mode → "Start event".</div>}
      </div>

      <Modal open={showNew} onClose={() => setShowNew(false)} title="Create event">
        <div className="space-y-2">
          <Input placeholder="Event name" value={form.name} onChange={(e: any) => setForm({ ...form, name: e.target.value })} />
          <div className="flex gap-2">
            <Select value={form.venue_key} onChange={(e: any) => setForm({ ...form, venue_key: e.target.value })}>
              <option value="auditorium">Auditorium</option><option value="sports">Sports Arena</option>
              <option value="plaza">Central Plaza</option><option value="food_court">Food Court</option>
            </Select>
            <Input type="number" value={form.expected_attendance} onChange={(e: any) => setForm({ ...form, expected_attendance: +e.target.value })} placeholder="expected attendance" />
            <Input type="number" value={form.duration_min} onChange={(e: any) => setForm({ ...form, duration_min: +e.target.value })} placeholder="duration min" />
          </div>
          <Input placeholder="description" value={form.description} onChange={(e: any) => setForm({ ...form, description: e.target.value })} />
          <Btn variant="primary" className="w-full" onClick={create}>Create & start now (in simulation)</Btn>
        </div>
      </Modal>
    </div>
  )
}
