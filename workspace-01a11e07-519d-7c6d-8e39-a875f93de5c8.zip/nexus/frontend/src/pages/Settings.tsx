import React from 'react'
import { api } from '../api'
import { Card, Badge, Btn, Input } from '../components/ui'

export default function Settings() {
  const [privacy, setPrivacy] = React.useState<any>(null)
  const [notice, setNotice] = React.useState('')
  const [weights, setWeights] = React.useState<any>(null)
  const [users, setUsers] = React.useState<any[]>([])
  const [audit, setAudit] = React.useState<any[]>([])
  const [msg, setMsg] = React.useState('')
  const me = React.useRef<any>(null)

  const load = () => {
    api('/auth/me').then(u => { me.current = u })
    api('/settings/privacy').then(setPrivacy).catch(() => {})
    api('/settings/privacy/notice').then(d => setNotice(d.notice)).catch(() => {})
    api('/settings/risk-weights').then(setWeights).catch(() => {})
    api('/settings/users').then(setUsers).catch(() => {})
    api('/settings/audit?limit=30').then(setAudit).catch(() => {})
  }
  React.useEffect(() => { load() }, [])

  const savePrivacy = async () => { await api('/settings/privacy', { method: 'PUT', body: privacy }); setMsg('Privacy settings saved.') }
  const saveWeights = async () => {
    try { await api('/settings/risk-weights', { method: 'PUT', body: weights }); setMsg('Risk weights updated.') }
    catch (e: any) { setMsg('Error: ' + e.message) }
  }

  return (
    <div className="space-y-3">
      <h1 className="text-lg font-bold">⚙ Settings — Privacy, Risk Weights, Users & Audit</h1>
      {msg && <div className="text-xs text-emerald-300 panel-light p-2 inline-block">{msg}</div>}

      <div className="grid lg:grid-cols-2 gap-3">
        <Card title="Privacy-first controls" className="p-4 pt-2 space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span>Data retention (days, auto-purge)</span>
            <Input type="number" className="w-24" value={privacy?.retention_days || 30}
              onChange={(e: any) => setPrivacy({ ...privacy, retention_days: +e.target.value })} />
          </div>
          {[['face_blur', 'Blur faces in displayed/exported frames'],
            ['plate_blur', 'Blur number plates in displayed frames'],
            ['plate_storage', 'Store number plates (off by default)'],
            ['auto_purge', 'Automatic purge job']].map(([k, label]: any) => (
            <label key={k} className="flex items-center justify-between text-sm cursor-pointer">
              <span>{label}</span>
              <input type="checkbox" checked={privacy?.[k] ?? false} onChange={e => setPrivacy({ ...privacy, [k]: e.target.checked })}
                className="accent-cyan-400 w-4 h-4" />
            </label>
          ))}
          <div className="flex items-center justify-between text-sm opacity-60">
            <span>Individual tracking <Badge tone="critical">FORBIDDEN</Badge></span>
            <input type="checkbox" checked={false} disabled className="w-4 h-4" />
          </div>
          <div className="flex gap-2">
            <Btn variant="primary" onClick={savePrivacy}>Save privacy settings</Btn>
            <Btn variant="danger" onClick={async () => { const r = await api('/settings/purge', { method: 'POST' }); setMsg(`Purged ${r.purged_rows} rows older than retention window.`) }}>Purge now</Btn>
          </div>
          <div className="text-[11px] text-slate-500 border-t border-edge pt-2">{notice}</div>
        </Card>

        <Card title="Risk engine weights (must sum to 1.0)" className="p-4 pt-2 space-y-2">
          {weights && Object.entries(weights).map(([k, v]: any) => (
            <div key={k} className="flex items-center gap-2 text-sm">
              <span className="w-24 capitalize text-slate-400">{k}</span>
              <input type="range" min={0} max={0.5} step={0.01} value={v} className="flex-1 accent-cyan-400"
                onChange={e => setWeights({ ...weights, [k]: +e.target.value })} />
              <span className="font-mono w-12 text-right">{v.toFixed(2)}</span>
            </div>
          ))}
          <div className="text-xs text-slate-500">Σ = {weights ? (Object.values(weights) as number[]).reduce((a, b) => a + b, 0).toFixed(2) : '—'}</div>
          <Btn variant="primary" onClick={saveWeights} disabled={!weights}>Save weights</Btn>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-3">
        <Card title="Users & roles (SUPER ADMIN)" className="p-4 pt-2">
          <table className="w-full text-xs">
            <thead><tr className="text-slate-500 text-left"><th className="py-1">User</th><th>Role</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="border-t border-edge/40">
                  <td className="py-1.5">{u.username}{u.is_demo_account && <span className="text-slate-600"> (demo)</span>}</td>
                  <td><Badge tone="open">{u.role}</Badge></td>
                  <td>{u.is_active ? '✅' : '🚫'}</td>
                  <td><Btn size="sm" variant="ghost" onClick={async () => { await api(`/settings/users/${u.id}/toggle`, { method: 'POST' }); load() }}>{u.is_active ? 'Disable' : 'Enable'}</Btn></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
        <Card title="Audit log (admin actions)" className="p-4 pt-2 max-h-96 overflow-auto scroll-thin">
          {audit.map(a => (
            <div key={a.id} className="flex gap-2 text-[11px] py-1 border-b border-edge/30">
              <span className="font-mono text-slate-500 shrink-0">{new Date(a.ts).toLocaleTimeString()}</span>
              <span className="text-cyan-300 shrink-0 w-24 truncate">{a.actor}</span>
              <span className="text-slate-400 shrink-0 w-28 truncate">{a.action}</span>
              <span className="text-slate-500 truncate">{a.detail}</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  )
}
