import React from 'react'
import { api } from '../api'
import { Link } from 'react-router-dom'

export default function Pulse() {
  const [d, setD] = React.useState<any>(null)
  const load = () => api('/pulse').then(setD).catch(() => {})
  React.useEffect(() => { load(); const t = setInterval(load, 8000); return () => clearInterval(t) }, [])
  if (!d) return <div className="min-h-screen flex items-center justify-center text-slate-500">Loading Campus Pulse…</div>
  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,#0d1a33_0%,#070b14_60%)] p-4 max-w-xl mx-auto space-y-3">
      <div className="text-center pt-4">
        <div className="text-2xl font-black tracking-[0.25em] text-cyan-300">CAMPUS PULSE</div>
        <div className="text-[11px] text-slate-500">Anonymous live info for students & visitors · {d.sim_clock}</div>
        <div className="text-[10px] text-slate-600 mt-1">Campus status: {d.campus_status} · {d.weather.condition}, {Math.round(d.weather.temp_c)}°C</div>
      </div>

      <div className="panel p-4">
        <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-2">🍜 Food stall wait times</div>
        {d.best_stall && <div className="text-xs text-emerald-300 mb-2">✅ Shortest wait right now: <b>{d.best_stall.name}</b> (~{Math.round(d.best_stall.wait_min)} min)</div>}
        <div className="space-y-1.5">
          {d.stalls.map((s: any) => (
            <div key={s.name} className="flex items-center gap-2 text-sm">
              <span className="flex-1">{s.name} {s.closed && <span className="text-slate-600 text-xs">(closed)</span>}</span>
              <div className="w-24 h-1.5 bg-slate-700/50 rounded-full"><div className={`h-full rounded-full ${s.wait_min > 10 ? 'bg-red-400' : s.wait_min > 5 ? 'bg-amber-400' : 'bg-emerald-400'}`} style={{ width: `${Math.min(100, s.wait_min * 7)}%` }} /></div>
              <span className="font-mono w-14 text-right text-slate-300">~{Math.round(s.wait_min)} min</span>
            </div>
          ))}
        </div>
      </div>

      <div className="panel p-4">
        <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-2">🅿 Parking availability</div>
        <div className="grid grid-cols-2 gap-2">
          {d.parking.map((p: any) => (
            <div key={p.name} className="panel-light p-3 text-center">
              <div className="text-xs text-slate-400">{p.name.replace('Parking ', '')}</div>
              <div className={`text-xl font-black font-mono ${p.available < 15 ? 'text-red-400' : 'text-emerald-300'}`}>{p.available}</div>
              <div className="text-[10px] text-slate-500">spots free · {p.occ_pct}% full</div>
            </div>
          ))}
        </div>
      </div>

      <div className="panel p-4">
        <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-2">🚪 Gate traffic</div>
        {d.gates.map((g: any) => (
          <div key={g.name} className="flex justify-between text-sm py-1">
            <span>{g.name}</span>
            <span className={g.open ? (g.level === 'HIGH' || g.level === 'CRITICAL' ? 'text-red-300' : g.level === 'MODERATE' ? 'text-amber-300' : 'text-emerald-300') : 'text-red-400'}>
              {g.open ? g.level : 'CLOSED'}
            </span>
          </div>
        ))}
      </div>

      <div className="panel p-4">
        <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-2">🎪 Events</div>
        {d.events.length === 0 && <div className="text-sm text-slate-500">No events right now.</div>}
        {d.events.map((e: any, i: number) => (
          <div key={i} className="text-sm py-1 flex justify-between"><span>{e.name}</span><span className="text-slate-500 text-xs">{e.venue_key}</span></div>
        ))}
      </div>
      <div className="text-center text-[10px] text-slate-600 pb-6">Anonymous, aggregate data only · no individual tracking · <Link to="/login" className="text-cyan-500/70">staff login →</Link></div>
    </div>
  )
}
