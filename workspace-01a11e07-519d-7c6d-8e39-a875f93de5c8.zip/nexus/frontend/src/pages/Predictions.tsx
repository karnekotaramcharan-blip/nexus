import React from 'react'
import { api, fmt } from '../api'
import { Card, Badge } from '../components/ui'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

export default function Predictions() {
  const [data, setData] = React.useState<any>(null)
  const snap = React.useMemo(() => null, [])
  const load = () => api('/predictions').then(setData).catch(() => {})
  React.useEffect(() => { load(); const t = setInterval(load, 15000); return () => clearInterval(t) }, [])
  if (!data) return <div className="text-slate-500">Loading predictions…</div>

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold">Prediction Dashboard <span className="text-xs text-slate-500 font-normal">CURRENT → PREDICTED → RECOMMENDED ACTION</span></h1>
        <div className="text-[11px] text-slate-500">model: {data.model} · horizons: {data.horizons.join('/')} min</div>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        {data.cards.map((c: any) => (
          <Card key={c.id} className="p-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-bold text-slate-200">{c.label}</div>
              <Badge tone={c.severity === 'high' ? 'critical' : c.severity === 'medium' ? 'warning' : 'LOW'}>{c.severity}</Badge>
            </div>
            <div className="flex items-center gap-3 mt-3 text-sm">
              <div className="panel-light px-3 py-2 flex-1 text-center">
                <div className="text-[9px] uppercase text-slate-500">Current</div>
                <div className="font-mono font-bold text-slate-100">{c.current}</div>
              </div>
              <div className="text-cyan-400 text-xl">→</div>
              <div className="panel-light px-3 py-2 flex-1 text-center border-cyan-500/30">
                <div className="text-[9px] uppercase text-cyan-500">Predicted</div>
                <div className="font-mono font-bold text-cyan-300">{c.predicted}</div>
              </div>
            </div>
            <div className="mt-3 text-[11px] text-emerald-300/90">✓ {c.action}</div>
            <div className="mt-2 h-24">
              <ForecastChart detail={c.detail} />
            </div>
            <div className="text-[10px] text-slate-500 mt-1">confidence {Math.round(c.detail.confidence * 100)}% · band [{c.detail.band_low}–{c.detail.band_high}] · model: {c.detail.model}</div>
          </Card>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        <Card title="Parking occupancy forecasts (30 min)" className="p-4 pt-2">
          <div className="h-56">
            <ResponsiveContainer>
              <AreaChart data={parkSeries(data)}>
                <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
                <XAxis dataKey="t" stroke="#475569" fontSize={10} />
                <YAxis stroke="#475569" fontSize={10} domain={[0, 100]} />
                <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} />
                {['park_a', 'park_b', 'park_c', 'park_d'].map((k, i) => (
                  <Area key={k} dataKey={k} stroke={['#22d3ee', '#8b5cf6', '#fbbf24', '#34d399'][i]} fill={['#22d3ee', '#8b5cf6', '#fbbf24', '#34d399'][i]} fillOpacity={0.08} strokeWidth={1.6} />
                ))}
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card title="Model accuracy (backtest on history)" className="p-4 pt-2">
          <table className="w-full text-xs">
            <thead><tr className="text-slate-500 text-left"><th className="py-1">Metric family</th><th>MAPE</th><th>MAE</th></tr></thead>
            <tbody>
              {Object.entries(data.accuracy).map(([k, v]: any) => (
                <tr key={k} className="border-t border-edge/50">
                  <td className="py-1.5 capitalize">{k}</td><td className="font-mono">{v.mape}%</td><td className="font-mono">{v.mae}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="text-[10px] text-slate-500 mt-3">Explainable by design: seasonal hour-of-day baseline blended with a linear trend; confidence bands from residual spread. Optional upgrades: Prophet/ARIMA, gradient boosting.</div>
        </Card>
      </div>
    </div>
  )
}

function parkSeries(data: any) {
  const horizons = [0, 10, 20, 30]
  const rows = horizons.map(h => ({ t: h === 0 ? 'now' : `+${h}m` }))
  for (const p of data.parking_predictions) {
    const zone = p.target.split(':')[1]
    rows[0][zone] = rows[0][zone] ?? p.current
    const idx = horizons.indexOf(p.horizon_min)
    if (idx > 0) rows[idx][zone] = p.predicted
  }
  return rows
}

function ForecastChart({ detail }: any) {
  const data = [
    { t: 'now', v: detail.current, lo: detail.current, hi: detail.current },
    { t: `+${detail.horizon_min}m`, v: detail.predicted, lo: detail.band_low, hi: detail.band_high },
  ]
  return (
    <ResponsiveContainer>
      <AreaChart data={data}>
        <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
        <XAxis dataKey="t" stroke="#475569" fontSize={10} />
        <YAxis stroke="#475569" fontSize={10} domain={['auto', 'auto']} />
        <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} />
        <Area dataKey="hi" stroke="none" fill="#22d3ee" fillOpacity={0.12} />
        <Area dataKey="v" stroke="#22d3ee" fill="#22d3ee" fillOpacity={0.2} strokeWidth={2} />
        <Area dataKey="lo" stroke="none" fill="#070b14" fillOpacity={1} />
      </AreaChart>
    </ResponsiveContainer>
  )
}
