import React from 'react'
import { api } from '../api'
import { Card, Badge, ProgressBar } from '../components/ui'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

export default function Stalls() {
  const [data, setData] = React.useState<any>(null)
  const [owner, setOwner] = React.useState<any[]>([])
  const [rush, setRush] = React.useState<any>(null)
  const load = () => {
    api('/stalls').then(setData).catch(() => {})
    api('/stalls/owner-view').then(setOwner).catch(() => {})
    api('/stalls/rush-forecast').then(setRush).catch(() => {})
  }
  React.useEffect(() => { load(); const t = setInterval(load, 8000); return () => clearInterval(t) }, [])
  if (!data) return <div className="text-slate-500">Loading food court…</div>

  const stallName = (k: string) => data.stalls.find((s: any) => s.key === k)?.name || k

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-lg font-bold">🍜 Food Stalls & Canteen Intelligence</h1>
        <div className="flex gap-2 text-xs">
          {data.best_stall && <span className="panel-light px-3 py-1.5">✅ Best right now: <b className="text-emerald-300">{data.best_stall.name}</b> (~{data.best_stall.wait_min.toFixed(0)} min)</span>}
          {data.worst_stall && <span className="panel-light px-3 py-1.5">⚠ Longest: <b className="text-red-300">{data.worst_stall.name}</b> (~{data.worst_stall.wait_min.toFixed(0)} min)</span>}
          <span className="panel-light px-3 py-1.5">Seating occupancy: <b>{data.seating_occupancy}%</b></span>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {data.stalls.map((s: any) => (
          <Card key={s.key} className={`p-4 ${s.closed ? 'opacity-50' : ''}`}>
            <div className="flex items-center justify-between">
              <div className="font-bold text-slate-100 text-sm">{s.name}</div>
              <Badge tone={s.closed ? 'offline' : s.level}>{s.closed ? 'CLOSED' : s.level}</Badge>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-3 text-center">
              <div><div className="text-[9px] uppercase text-slate-500">Queue</div><div className="font-mono font-bold text-slate-100">{s.queue}</div></div>
              <div><div className="text-[9px] uppercase text-slate-500">Wait</div><div className={`font-mono font-bold ${s.wait_min > 10 ? 'text-red-300' : s.wait_min > 5 ? 'text-amber-300' : 'text-emerald-300'}`}>~{s.wait_min.toFixed(0)}m</div></div>
              <div><div className="text-[9px] uppercase text-slate-500">Trend</div><div className="text-xs font-bold text-slate-300">{s.trend === 'rising' ? '↗' : s.trend === 'falling' ? '↘' : '→'} {s.trend}</div></div>
            </div>
            <div className="mt-3">
              <div className="text-[9px] uppercase text-slate-500 mb-1">Wait forecast (10/20/30 min)</div>
              <div className="flex gap-1 font-mono text-[11px]">
                {s.forecast_wait?.map((w: number, i: number) => (
                  <span key={i} className={`px-1.5 py-0.5 rounded ${w > 10 ? 'bg-red-500/15 text-red-300' : w > 5 ? 'bg-amber-500/15 text-amber-300' : 'bg-emerald-500/15 text-emerald-300'}`}>
                    +{[10, 20, 30][i]}m {w.toFixed(0)}m
                  </span>
                ))}
              </div>
            </div>
            {s.closed === false && s.queue > 20 && data.best_stall?.key !== s.key && (
              <div className="mt-2 text-[10px] text-violet-300">💡 Load-balance: redirect guests to {data.best_stall?.name}</div>
            )}
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-3">
        <Card title="Queue length by stall (live)" className="p-3 pt-1 lg:col-span-2">
          <div className="h-56">
            <ResponsiveContainer>
              <BarChart data={data.stalls.map((s: any) => ({ name: s.name.split(' ')[0], queue: s.queue, wait: s.wait_min }))}>
                <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
                <XAxis dataKey="name" stroke="#475569" fontSize={10} />
                <YAxis stroke="#475569" fontSize={10} />
                <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} />
                <Bar dataKey="queue" fill="#22d3ee" radius={[4, 4, 0, 0]} />
                <Bar dataKey="wait" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card title="Learned rush-hour profile (30d history)" className="p-3 pt-1">
          <div className="h-40">
            <ResponsiveContainer>
              <BarChart data={Object.entries(rush?.queue_by_hour || {}).map(([h, v]: any) => ({ h: `${h}h`, q: v }))}>
                <XAxis dataKey="h" stroke="#475569" fontSize={9} interval={3} />
                <YAxis hide />
                <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} />
                <Bar dataKey="q" fill="#fbbf24" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">{rush?.note}</div>
          <div className="text-[11px] text-emerald-300/80 mt-1">{rush?.staffing_hint}</div>
        </Card>
      </div>

      <Card title="Stall owner / manager view — staffing & stock" className="p-3 pt-1">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-2">
          {owner.map((o: any) => (
            <div key={o.stall} className="panel-light p-3">
              <div className="flex justify-between items-center">
                <div className="text-sm font-bold">{o.stall}</div>
                <Badge tone={o.staffing === 'OK' ? 'LOW' : o.staffing === 'PREPARE' ? 'warning' : 'critical'}>{o.staffing}</Badge>
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Queue now {o.current_queue} → forecast {o.forecast_queue_30.toFixed(0)} in 30 min ({Math.round(o.confidence * 100)}% conf.)</div>
              <div className="text-[11px] text-slate-500">Stock-up window: {o.stock_up_window}</div>
              {o.overcrowding_alert && <div className="text-[11px] text-red-300 mt-1">🚨 Overcrowding alert — add staff & open second counter</div>}
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
