import React from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api'
import { useApp } from '../store'
import { Btn, Input } from '../components/ui'

export default function Login() {
  const nav = useNavigate()
  const setUser = useApp(s => s.setUser)
  const [u, setU] = React.useState('admin')
  const [p, setP] = React.useState('NexusAdmin@123')
  const [err, setErr] = React.useState('')
  const [busy, setBusy] = React.useState(false)

  const login = async () => {
    setBusy(true); setErr('')
    try {
      const r = await api('/auth/login', { method: 'POST', body: { username: u, password: p } })
      setUser(r.user)
      nav('/')
    } catch (e: any) { setErr(e.message) } finally { setBusy(false) }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[radial-gradient(ellipse_at_top,#0d1a33_0%,#070b14_60%)] p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <svg width="54" height="54" viewBox="0 0 32 32" className="mx-auto mb-3"><circle cx="16" cy="16" r="14" fill="#0d1424" stroke="#22d3ee" strokeWidth="2"/><circle cx="16" cy="16" r="5" fill="#22d3ee"/><circle cx="16" cy="16" r="9" fill="none" stroke="#22d3ee" strokeWidth="0.6" opacity="0.5"/></svg>
          <h1 className="text-3xl font-black tracking-[0.3em] text-cyan-300">NEXUS</h1>
          <div className="text-xs text-slate-400 tracking-widest uppercase mt-1">AI Digital Twin for Campus Intelligence</div>
          <div className="text-[11px] text-slate-500 italic mt-2">Understand the present. Simulate the future. Prevent the unexpected.</div>
        </div>
        <div className="panel p-6 space-y-3 kpi-glow">
          <div className="text-xs uppercase tracking-widest text-slate-500">Command Center Access</div>
          <Input value={u} onChange={(e: any) => setU(e.target.value)} placeholder="username" autoFocus />
          <Input type="password" value={p} onChange={(e: any) => setP(e.target.value)} placeholder="password" onKeyDown={(e: any) => e.key === 'Enter' && login()} />
          {err && <div className="text-xs text-red-400">{err}</div>}
          <Btn variant="primary" className="w-full" size="lg" onClick={login} disabled={busy}>{busy ? 'Authenticating…' : 'Enter Command Center'}</Btn>
          <div className="text-[10px] text-slate-500 border-t border-edge pt-3 space-y-1">
            <div className="font-bold text-slate-400">Demo accounts (demo-only; disabled in production):</div>
            <div>🔑 admin / NexusAdmin@123 — SUPER ADMIN</div>
            <div>campus_admin / DemoCampus@123 · security_admin / DemoSecure@123 · events_admin / DemoEvents@123</div>
            <div className="text-slate-600">JWT httpOnly cookies · bcrypt hashing · RBAC enforced server-side</div>
          </div>
        </div>
      </div>
    </div>
  )
}
