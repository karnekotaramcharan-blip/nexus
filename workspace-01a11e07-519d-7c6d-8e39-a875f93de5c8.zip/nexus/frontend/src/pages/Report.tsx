import React from 'react'
import { api } from '../api'
import { Card, Btn, Badge, Spinner } from '../components/ui'

export default function Report() {
  const [rep, setRep] = React.useState<any>(null)
  const [busy, setBusy] = React.useState(false)

  const generate = async () => {
    setBusy(true)
    try { setRep(await api('/reports/daily', { method: 'POST' })) } finally { setBusy(false) }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-lg font-bold">📄 Explain My Campus — Daily Intelligence Report</h1>
        <div className="flex gap-2">
          <Btn variant="primary" onClick={generate} disabled={busy}>{busy ? <><Spinner /> Generating…</> : '✨ Generate Report'}</Btn>
          {rep && <Btn variant="ghost" onClick={() => window.print()}>⬇ Export PDF (print)</Btn>}
        </div>
      </div>

      {!rep && !busy && (
        <Card className="p-8 text-center text-slate-500 text-sm">
          One click aggregates today's peaks, anomalies, events, parking, food court and resources into a natural-language executive report.
          <div className="text-xs mt-2 text-slate-600">{`LLM polish is used when configured; otherwise a deterministic template guarantees the report.`}</div>
        </Card>
      )}

      {rep && (
        <div id="report-print" className="max-w-3xl mx-auto space-y-3">
          <Card className="p-6">
            <div className="flex items-center justify-between border-b border-edge pb-3">
              <div>
                <div className="text-xl font-black tracking-widest text-cyan-300">NEXUS</div>
                <div className="text-[10px] uppercase tracking-widest text-slate-500">AI Campus Intelligence Report · {rep.date}</div>
              </div>
              <div className="text-right text-[10px] text-slate-500">
                <div>generated {new Date(rep.generated_at).toLocaleString()}</div>
                <div>by {rep.author} · {rep.llm_used ? 'LLM-enhanced' : 'template engine'}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
              {[
                ['Peak population', rep.facts.population_peak?.toLocaleString()],
                ['Busiest zone', rep.facts.busiest_zone],
                ['Parking peak', rep.facts.park_peak + '%'],
                ['Peak risk', rep.facts.risk_peak + '/100'],
                ['Anomalies', rep.facts.n_anomalies],
                ['Critical anomalies', rep.facts.n_critical_anomalies],
                ['Alerts raised', rep.facts.n_alerts],
                ['Weather', rep.facts.weather],
              ].map(([l, v]: any) => (
                <div key={l} className="panel-light p-2.5"><div className="text-[9px] uppercase text-slate-500">{l}</div><div className="font-bold text-slate-100 text-sm">{v}</div></div>
              ))}
            </div>
          </Card>
          {rep.sections.map((s: any) => (
            <Card key={s.title} className="p-5">
              <div className="text-sm font-bold text-cyan-300 mb-1.5">{s.title}</div>
              <div className="text-sm text-slate-300 leading-relaxed">{s.body}</div>
            </Card>
          ))}
          <div className="text-center text-[10px] text-slate-600 pb-4">NEXUS · Anonymous aggregate analytics only · No facial recognition · No individual tracking</div>
        </div>
      )}
    </div>
  )
}
