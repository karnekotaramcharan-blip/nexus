import React from 'react'
import { api } from '../api'
import { Card, Badge, Btn, Select } from '../components/ui'
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts'

export default function Analytics() {
  const [range, setRange] = React.useState('today')
  const [pop, setPop] = React.useState<any[]>([])
  const [mobility, setMobility] = React.useState<any[]>([])
  const [resources, setResources] = React.useState<any[]>([])
  const [anoms, setAnoms] = React.useState<any[]>([])
  const [health, setHealth] = React.useState<any>(null)
  const [accuracy, setAccuracy] = React.useState<any>(null)

  const load = React.useCallback(() => {
    api(`/analytics/timeseries?metric=population&range=${range}`).then(d => setPop(d.points)).catch(() => {})
    api(`/analytics/timeseries?metric=mobility&range=${range}`).then(d => setMobility(d.points)).catch(() => {})
    api(`/analytics/timeseries?metric=resources&range=${range}`).then(d => setResources(d.points)).catch(() => {})
    api('/analytics/anomalies?limit=40').then(setAnoms).catch(() => {})
    api('/analytics/model-health').then(setHealth).catch(() => {})
    api('/analytics/prediction-accuracy').then(setAccuracy).catch(() => {})
  }, [range])
  React.useEffect(() => { load() }, [load])

  const exportCSV = () => {
    const rows = [['ts', 'population', 'parking_pct', 'congestion', 'food_load', 'risk'],
      ...pop.map(p => [p.ts, p.population, p.parking, p.congestion, p.food_load, p.risk])]
    const csv = rows.map(r => r.join(',')).join('\n')
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
    a.download = `nexus-analytics-${range}.csv`
    a.click()
  }

  const ts = (s: string) => new Date(s).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  const roadAgg = React.useMemo(() => {
    const m: Record<string, { v: number; n: number }> = {}
    mobility.forEach(p => { const r = (m[p.road] ||= { v: 0, n: 0 }); r.v += p.congestion; r.n++ })
    return Object.entries(m).map(([road, x]) => ({ road: road.replace('_', ' '), congestion: +(x.v / x.n).toFixed(2), volume: x.n }))
  }, [mobility])
  const flowPairs: [string, string, number][] = [
    ['Main Gate', 'Main Road', 42], ['Main Road', 'Central Spine', 34], ['Central Spine', 'Auditorium', 18],
    ['Central Spine', 'Food Court', 22], ['North Gate', 'North Avenue', 26], ['North Avenue', 'Plaza', 12],
    ['East Gate', 'Ring Road', 16], ['Ring Road', 'Parking D', 9], ['Food Court', 'Sports Arena', 6],
  ]

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-lg font-bold">📊 Analytics</h1>
        <div className="flex gap-2 items-center">
          <Select value={range} onChange={(e: any) => setRange(e.target.value)}>
            <option value="today">Today</option><option value="yesterday">Yesterday</option>
            <option value="7d">7 Days</option><option value="30d">30 Days</option>
          </Select>
          <Btn onClick={exportCSV}>⬇ Export CSV</Btn>
          <Btn variant="ghost" onClick={() => window.print()}>🖨 PDF (print)</Btn>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-3">
        <Card title={`Campus population, parking & risk (${range})`} className="p-3 pt-1">
          <div className="h-56">
            <ResponsiveContainer>
              <AreaChart data={pop}>
                <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
                <XAxis dataKey="ts" stroke="#475569" fontSize={9} tickFormatter={ts} minTickGap={40} />
                <YAxis stroke="#475569" fontSize={10} />
                <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} labelFormatter={ts as any} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Area dataKey="population" stroke="#22d3ee" fill="#22d3ee" fillOpacity={0.1} strokeWidth={1.8} />
                <Area dataKey="parking" stroke="#fbbf24" fill="#fbbf24" fillOpacity={0.06} strokeWidth={1.4} />
                <Area dataKey="risk" stroke="#f87171" fill="#f87171" fillOpacity={0.06} strokeWidth={1.4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card title="Mobility — average road congestion & campus flow" className="p-3 pt-1">
          <div className="grid grid-cols-2 gap-2">
            <div className="h-56">
              <ResponsiveContainer>
                <BarChart data={roadAgg} layout="vertical">
                  <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
                  <XAxis type="number" stroke="#475569" fontSize={10} domain={[0, 1.2]} />
                  <YAxis type="category" dataKey="road" stroke="#475569" fontSize={9} width={80} />
                  <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} />
                  <Bar dataKey="congestion" fill="#fb923c" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="text-[11px] space-y-1 overflow-auto scroll-thin">
              <div className="text-[10px] uppercase text-slate-500">Top movement corridors (volume share)</div>
              {flowPairs.map(([a, b, v], i) => (
                <div key={i} className="flex items-center gap-1 text-slate-300">
                  <span className="w-24 truncate">{a}</span><span className="text-cyan-400">→</span><span className="w-24 truncate">{b}</span>
                  <div className="flex-1 h-1 bg-slate-700/40 rounded"><div className="h-full bg-cyan-500/60 rounded" style={{ width: `${v * 2}%` }} /></div>
                  <span className="font-mono text-slate-500 w-7 text-right">{v}%</span>
                </div>
              ))}
              <div className="text-slate-600 text-[10px] pt-1">Gate → road → destination flow from anonymous movement analytics.</div>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-3">
        <Card title="Resource consumption" className="p-3 pt-1 lg:col-span-2">
          <div className="h-48">
            <ResponsiveContainer>
              <LineChart data={resources.filter((_, i) => i % 2 === 0)}>
                <CartesianGrid stroke="#16223c" strokeDasharray="3 3" />
                <XAxis dataKey="ts" stroke="#475569" fontSize={9} tickFormatter={ts} minTickGap={40} />
                <YAxis stroke="#475569" fontSize={10} />
                <Tooltip contentStyle={{ background: '#0d1424', border: '1px solid #1d2a45', fontSize: 11 }} labelFormatter={ts as any} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line dataKey="value" stroke="#8b5cf6" dot={false} strokeWidth={1.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card title="Model health" className="p-3 pt-1 text-xs space-y-2">
          <div className="panel-light p-2">🧠 Anomaly model: <b>{health?.anomaly_model?.name}</b><div className="text-slate-500">trained: {health?.anomaly_model?.last_trained} · {health?.anomaly_model?.data_points?.toLocaleString()} points</div></div>
          <div className="panel-light p-2">📈 Forecast model: <b>{health?.forecast_model?.name}</b>
            <div className="text-slate-500">accuracy: crowd MAPE {health?.forecast_model?.accuracy_by_kind?.crowd?.mape}% · parking {health?.forecast_model?.accuracy_by_kind?.parking?.mape}%</div></div>
          <div className="panel-light p-2">🎯 Live prediction check: <b>{accuracy?.evaluated}</b> matured predictions · MAPE {accuracy?.mape}% · MAE {accuracy?.mae}</div>
          <div className="text-slate-600 text-[10px]">{health?.notes}</div>
        </Card>
      </div>

      <Card title="Anomaly history (explainable — observed vs learned baseline)" className="p-3 pt-1">
        <div className="overflow-x-auto scroll-thin">
          <table className="w-full text-xs">
            <thead><tr className="text-slate-500 text-left border-b border-edge">
              <th className="py-1.5 pr-2">Time</th><th className="pr-2">Metric</th><th className="pr-2">Observed</th><th className="pr-2">Expected range</th><th className="pr-2">Deviation</th><th className="pr-2">Conf.</th><th>Reason</th></tr></thead>
            <tbody>
              {anoms.map(a => (
                <tr key={a.id} className="border-b border-edge/40">
                  <td className="py-1.5 pr-2 font-mono whitespace-nowrap">{new Date(a.ts).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                  <td className="pr-2 whitespace-nowrap">{a.metric}</td>
                  <td className="pr-2 font-mono">{Math.round(a.observed)}</td>
                  <td className="pr-2 font-mono text-slate-400">{Math.round(a.expected_low)}–{Math.round(a.expected_high)}</td>
                  <td className={`pr-2 font-mono font-bold ${a.deviation > 0 ? 'text-red-300' : 'text-sky-300'}`}>{a.deviation > 0 ? '+' : ''}{a.deviation}σ</td>
                  <td className="pr-2 font-mono">{Math.round(a.confidence * 100)}%</td>
                  <td className="text-slate-400 max-w-md">{a.reason}</td>
                </tr>
              ))}
              {anoms.length === 0 && <tr><td colSpan={7} className="py-3 text-slate-500">No anomalies recorded yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
