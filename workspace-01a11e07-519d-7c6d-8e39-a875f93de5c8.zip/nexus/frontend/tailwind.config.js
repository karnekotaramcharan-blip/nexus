/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#070b14',
        panel: '#0d1424',
        panel2: '#111b31',
        edge: '#1d2a45',
        neon: { cyan: '#22d3ee', blue: '#3b82f6', violet: '#8b5cf6', green: '#34d399', amber: '#fbbf24', red: '#f87171' },
      },
      fontFamily: { mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'] },
      boxShadow: { glow: '0 0 24px rgba(34,211,238,.15)' },
    },
  },
  plugins: [],
}
