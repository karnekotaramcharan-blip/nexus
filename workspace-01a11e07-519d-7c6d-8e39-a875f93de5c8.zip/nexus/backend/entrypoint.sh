#!/bin/sh
# Seed history on first start, then serve.
python seed.py --days "${SEED_DAYS:-30}" || echo "seed skipped (already populated or DB not ready)"
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
