import asyncio
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import settings
from .db import Base, engine
from . import models  # noqa: F401  (register models)
from .routers import (auth, demo, whatif, assistant, reports, alerts, events,
                      stalls, replay, cameras, analytics, settings as settings_router,
                      pulse, campus)
from . import ws as ws_module
from .services import runtime, baselines
from .services.purge import run_purge
from .db import SessionLocal

MEDIA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         "..", "ai-service", "data")


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    # ensure seed exists
    from .db import SessionLocal as SL
    db = SL()
    try:
        n = db.query(models.User).count()
    finally:
        db.close()
    if n == 0:
        print("Empty DB — running inline bootstrap seed (run seed.py for full 30d history)")
        import subprocess, sys
        subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "seed.py"), "--days", "14"], check=False)
    baselines.build_baselines()
    runtime.reset_all(start_hour=8, start_minute=50)
    loop_task = asyncio.create_task(runtime.live_loop())
    purge_task = asyncio.create_task(purge_scheduler())
    yield
    loop_task.cancel()
    purge_task.cancel()


async def purge_scheduler():
    while True:
        await asyncio.sleep(15 * 60)  # every 15 real minutes
        db = SessionLocal()
        try:
            run_purge(db)
        finally:
            db.close()


app = FastAPI(title="NEXUS — AI Digital Twin for Campus Intelligence",
              description="Understand the present. Simulate the future. Prevent the unexpected.",
              version="1.0.0", lifespan=lifespan)

origins = settings.CORS_ORIGINS.split(",") if settings.CORS_ORIGINS != "*" else ["*"]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

app.include_router(auth.router)
app.include_router(demo.router)
app.include_router(whatif.router)
app.include_router(assistant.router)
app.include_router(reports.router)
app.include_router(alerts.router)
app.include_router(alerts.router2)
app.include_router(events.router)
app.include_router(stalls.router)
app.include_router(replay.router)
app.include_router(cameras.router)
app.include_router(analytics.router)
app.include_router(settings_router.router)
app.include_router(pulse.router)
app.include_router(campus.router)
app.include_router(ws_module.router)

app.mount("/media", StaticFiles(directory=os.path.abspath(MEDIA_DIR)), name="media")


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "service": "nexus-backend",
            "ai_engine": "online", "demo_mode": True}
