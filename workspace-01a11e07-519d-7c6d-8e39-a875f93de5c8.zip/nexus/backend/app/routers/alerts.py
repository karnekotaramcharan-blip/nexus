from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db
from ..models import Alert, Recommendation
from ..security import require_roles, audit

router = APIRouter(prefix="/api/v1/alerts", tags=["alerts"])


@router.get("")
def list_alerts(status: str = "", limit: int = 40, user=Depends(require_roles()), db=Depends(get_db)):
    q = db.query(Alert)
    if status:
        q = q.filter(Alert.status == status)
    rows = q.order_by(Alert.id.desc()).limit(limit).all()
    return [{"id": r.id, "kind": r.kind, "severity": r.severity, "location": r.location,
             "reason": r.reason, "prediction": r.prediction, "action": r.action,
             "status": r.status, "assignee": r.assignee, "notes": r.notes,
             "ts": r.ts.isoformat()} for r in rows]


class AlertUpdate(BaseModel):
    status: str | None = None
    assignee: str | None = None
    notes: str | None = None


@router.patch("/{alert_id}")
def update_alert(alert_id: int, body: AlertUpdate, user=Depends(require_roles()), db=Depends(get_db)):
    r = db.get(Alert, alert_id)
    if not r:
        raise HTTPException(status_code=404, detail="Alert not found")
    if body.status:
        if body.status not in ("new", "acknowledged", "resolved", "dismissed"):
            raise HTTPException(status_code=400, detail="Invalid status")
        r.status = body.status
    if body.assignee is not None:
        r.assignee = body.assignee
    if body.notes is not None:
        r.notes = body.notes
    db.commit()
    audit(user.username, "alert_update", f"alert {alert_id} -> {body.status}")
    return {"ok": True}


# ------------------------------------------------- recommendations feedback
router2 = APIRouter(prefix="/api/v1/recommendations", tags=["recommendations"])


class RecoFeedback(BaseModel):
    feedback: str  # accepted | dismissed


@router2.get("")
def list_reco(user=Depends(require_roles()), db=Depends(get_db)):
    rows = db.query(Recommendation).order_by(Recommendation.id.desc()).limit(30).all()
    return [{"id": r.id, "title": r.title, "detail": r.detail, "source": r.source,
             "priority": r.priority, "expected_risk_reduction": r.expected_risk_reduction,
             "status": r.status, "feedback_by": r.feedback_by, "ts": r.ts.isoformat(),
             "baseline_metric": r.baseline_metric, "outcome_metric": r.outcome_metric} for r in rows]


@router2.post("/{reco_id}/feedback")
def reco_feedback(reco_id: int, body: RecoFeedback, user=Depends(require_roles()), db=Depends(get_db)):
    r = db.get(Recommendation, reco_id)
    if not r:
        raise HTTPException(status_code=404, detail="Not found")
    from ..services import runtime, risk
    r.status = "accepted" if body.feedback == "accepted" else "dismissed"
    r.feedback_by = user.username
    snap_risk = risk.compute(runtime.get_engine(), [])["score"]
    r.baseline_metric = {"risk": snap_risk,
                         "population": runtime.get_engine().state["population"],
                         "ts": runtime.get_engine().sim_time.isoformat()}
    db.commit()
    audit(user.username, "reco_feedback", f"{reco_id} {body.feedback}")
    return {"ok": True}
