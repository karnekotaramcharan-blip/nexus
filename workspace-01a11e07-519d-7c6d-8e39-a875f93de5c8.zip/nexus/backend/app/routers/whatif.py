import json

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db
from ..models import Simulation
from ..security import require_roles, audit
from ..services import scenarios, runtime

router = APIRouter(prefix="/api/v1/simulations", tags=["what-if"])


class RunIn(BaseModel):
    scenario: str
    params: dict = {}
    horizon_min: int = 60
    name: str = ""
    save: bool = True


@router.post("/run")
def run_sim(body: RunIn, user=Depends(require_roles()), db=Depends(get_db)):
    if body.scenario not in scenarios.SCENARIOS:
        raise HTTPException(status_code=400, detail=f"Unknown scenario. Valid: {list(scenarios.SCENARIOS)}")
    result = scenarios.run(runtime.get_engine(), body.scenario, body.params, body.horizon_min)
    sim_id = None
    if body.save:
        row = Simulation(name=body.name or result["scenario_label"], scenario=body.scenario,
                         params=body.params, result=result,
                         risk_current=result["risk_current"], risk_simulated=result["risk_simulated"],
                         author=user.username)
        db.add(row)
        db.commit()
        sim_id = row.id
    audit(user.username, "whatif_run", f"{body.scenario} {body.params}")
    return {"simulation_id": sim_id, **result}


class NLIn(BaseModel):
    query: str


@router.post("/run-nl")
def run_nl(body: NLIn, user=Depends(require_roles()), db=Depends(get_db)):
    """Natural-language What-If: reuses the assistant's scenario parser."""
    from ..services.assistant import _detect_whatif
    det = _detect_whatif(body.query)
    if not det:
        return {"matched": False,
                "message": "I could not map that to a scenario. Try: 'close the main gate', "
                           "'heavy rain', 'event attracts 2,000 people', '30% more vehicles', "
                           "'parking zone A unavailable', 'close Snack Corner', 'evacuate the auditorium'."}
    scenario, params = det
    result = scenarios.run(runtime.get_engine(), scenario, params)
    row = Simulation(name=f"NL: {body.query[:80]}", scenario=scenario, params=params, result=result,
                     risk_current=result["risk_current"], risk_simulated=result["risk_simulated"],
                     author=user.username)
    db.add(row)
    db.commit()
    audit(user.username, "whatif_nl", body.query)
    return {"matched": True, "simulation_id": row.id, **result}


@router.get("/history")
def history(user=Depends(require_roles()), db=Depends(get_db)):
    rows = db.query(Simulation).order_by(Simulation.id.desc()).limit(30).all()
    return [{
        "id": r.id, "name": r.name, "scenario": r.scenario, "params": r.params,
        "risk_current": r.risk_current, "risk_simulated": r.risk_simulated,
        "author": r.author, "created_at": r.created_at.isoformat(),
    } for r in rows]


@router.get("/{sim_id}")
def get_sim(sim_id: int, user=Depends(require_roles()), db=Depends(get_db)):
    r = db.get(Simulation, sim_id)
    if not r:
        raise HTTPException(status_code=404, detail="Simulation not found")
    return {"id": r.id, "name": r.name, "scenario": r.scenario, "params": r.params,
            "author": r.author, "created_at": r.created_at.isoformat(), **r.result}


@router.get("/compare/{a_id}/{b_id}")
def compare(a_id: int, b_id: int, user=Depends(require_roles()), db=Depends(get_db)):
    a, b = db.get(Simulation, a_id), db.get(Simulation, b_id)
    if not a or not b:
        raise HTTPException(status_code=404, detail="Simulation not found")
    return {"a": {"id": a.id, "name": a.name, **a.result},
            "b": {"id": b.id, "name": b.name, **b.result}}
