import os
import uuid
from datetime import datetime

import httpx
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from pydantic import BaseModel

from ..config import settings
from ..db import get_db
from ..models import Camera, CameraEvent
from ..security import require_roles, audit
from ..services import runtime

router = APIRouter(prefix="/api/v1/cameras", tags=["cameras"])
_NEXUS_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
UPLOAD_DIR = os.path.join(_NEXUS_ROOT, "ai-service", "data", "uploads")


@router.get("")
def list_cameras(user=Depends(require_roles()), db=Depends(get_db)):
    snap = runtime.get_engine().state["cameras"]
    rows = db.query(Camera).order_by(Camera.cam_id).all()
    return [{"cam_id": r.cam_id, "name": r.name, "zone_key": r.zone_key,
             "source_type": r.source_type,
             "status": snap.get(r.cam_id, {}).get("status", r.status),
             "ai_status": snap.get(r.cam_id, {}).get("ai_status", r.ai_status),
             "fps": r.fps, "last_update": r.last_update.isoformat()} for r in rows]


class CameraIn(BaseModel):
    name: str
    zone_key: str = ""
    source_type: str = "demo"
    fps: int = 24


@router.post("")
def add_camera(body: CameraIn, user=Depends(require_roles("SECURITY_ADMIN", "CAMPUS_ADMIN")),
               db=Depends(get_db)):
    n = db.query(Camera).count() + 1
    cam_id = f"CAM-{n:03d}"
    if db.query(Camera).filter(Camera.cam_id == cam_id).first():
        cam_id = f"CAM-{uuid.uuid4().hex[:4].upper()}"
    # NOTE: RTSP credentials, if any, stay server-side (env/secrets) and are never serialized.
    c = Camera(cam_id=cam_id, name=body.name, zone_key=body.zone_key,
               source_type=body.source_type, fps=body.fps)
    db.add(c)
    db.commit()
    audit(user.username, "camera_add", cam_id)
    return {"cam_id": cam_id}


@router.patch("/{cam_id}")
def update_camera(cam_id: str, body: CameraIn, user=Depends(require_roles("SECURITY_ADMIN", "CAMPUS_ADMIN")),
                  db=Depends(get_db)):
    c = db.query(Camera).filter(Camera.cam_id == cam_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Camera not found")
    c.name, c.zone_key, c.source_type, c.fps = body.name, body.zone_key, body.source_type, body.fps
    db.commit()
    audit(user.username, "camera_update", cam_id)
    return {"ok": True}


@router.post("/{cam_id}/toggle")
def toggle_camera(cam_id: str, user=Depends(require_roles("SECURITY_ADMIN")), db=Depends(get_db)):
    c = db.query(Camera).filter(Camera.cam_id == cam_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Camera not found")
    e = runtime.get_engine()
    cur = e.state["cameras"].setdefault(cam_id, {"status": "online", "ai_status": "active"})
    cur["status"] = "offline" if cur["status"] == "online" else "online"
    db.add(CameraEvent(camera_id=c.id, kind=cur["status"], payload={}, ts=e.sim_time))
    db.commit()
    audit(user.username, "camera_toggle", f"{cam_id} -> {cur['status']}")
    return {"cam_id": cam_id, "status": cur["status"]}


JOBS: dict[str, dict] = {}


@router.post("/{cam_id}/analyze")
async def analyze_video(cam_id: str, file: UploadFile | None = File(default=None),
                        use_demo: bool = Query(default=False),
                        user=Depends(require_roles()), db=Depends(get_db)):
    """Send uploaded (or bundled demo) video to the separate AI service for CV analysis."""
    c = db.query(Camera).filter(Camera.cam_id == cam_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Camera not found")

    if use_demo:
        video_path = os.path.join(os.path.dirname(UPLOAD_DIR), "demo_campus.mp4")
        video_path = os.path.abspath(video_path)
        if not os.path.exists(video_path):
            raise HTTPException(status_code=404, detail="Demo video not generated yet — run seed script")
    else:
        if not file:
            raise HTTPException(status_code=400, detail="Provide a video file or use_demo=true")
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        ext = os.path.splitext(file.filename or "video.mp4")[1] or ".mp4"
        video_path = os.path.join(UPLOAD_DIR, f"{cam_id}_{uuid.uuid4().hex[:8]}{ext}")
        with open(video_path, "wb") as f:
            f.write(await file.read())

    async with httpx.AsyncClient(timeout=120) as client:
        try:
            r = await client.post(f"{settings.AI_SERVICE_URL}/api/v1/analyze/video",
                                  json={"video_path": video_path, "camera_id": cam_id,
                                        "blur_faces": True})
            r.raise_for_status()
            result = r.json()
        except httpx.HTTPError as ex:
            raise HTTPException(status_code=502, detail=f"AI service unavailable: {ex}")

    db.add(CameraEvent(camera_id=c.id, kind="upload_result",
                       payload={"summary": result.get("summary", {}), "path": video_path}))
    c.last_update = datetime.utcnow()
    db.commit()
    audit(user.username, "camera_analyze", cam_id)
    job_id = uuid.uuid4().hex[:10]
    JOBS[job_id] = {"status": "done", "camera_id": cam_id, **result}
    return {"job_id": job_id, **result}


@router.get("/jobs/{job_id}")
def job_status(job_id: str, user=Depends(require_roles())):
    if job_id not in JOBS:
        raise HTTPException(status_code=404, detail="Job not found")
    return JOBS[job_id]
