from fastapi import APIRouter, Depends

from ..db import get_db
from ..models import Building, Zone, ParkingZone, FoodStall
from ..security import require_roles, get_current_user
from ..services import runtime, predict as predict_svc, anomaly as anomaly_svc

router = APIRouter(prefix="/api/v1", tags=["campus"])


@router.get("/campus/map")
def map_data(db=Depends(get_db)):
    """Static topology for the digital twin (public-ish; contains no operational data)."""
    return {
        "buildings": [{"key": b.key, "name": b.name, "kind": b.kind,
                       "x": b.x, "y": b.y, "w": b.w, "h": b.h} for b in db.query(Building)],
        "zones": [{"key": z.key, "name": z.name, "kind": z.kind, "capacity": z.capacity,
                   "cx": z.cx, "cy": z.cy} for z in db.query(Zone)],
        "parking": [{"key": p.key, "name": p.name, "category": p.category, "capacity": p.capacity,
                     "cx": p.cx, "cy": p.cy} for p in db.query(ParkingZone)],
        "stalls": [{"key": s.key, "name": s.name, "cx": s.cx, "cy": s.cy}
                   for s in db.query(FoodStall)],
    }


@router.get("/live/snapshot")
def live_snapshot(user=Depends(require_roles())):
    return runtime.build_snapshot()


@router.get("/predictions")
def predictions(user=Depends(require_roles())):
    e = runtime.get_engine()
    return {
        "cards": predict_svc.top_predictions(e),
        "zone_predictions": predict_svc.zone_predictions(e)[:24],
        "parking_predictions": predict_svc.parking_predictions(e),
        "horizons": [10, 20, 30, 60],
        "model": predict_svc.MODEL_NAME,
        "accuracy": predict_svc.MODEL_ACCURACY,
    }


@router.get("/anomalies/active")
def anomalies_active(user=Depends(require_roles())):
    return anomaly_svc.active_anomalies()
