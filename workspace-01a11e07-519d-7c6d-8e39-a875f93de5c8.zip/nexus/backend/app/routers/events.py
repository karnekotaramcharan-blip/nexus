from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db
from ..models import Event
from ..security import require_roles, audit
from ..services import runtime

router = APIRouter(prefix="/api/v1/events", tags=["events"])


class EventIn(BaseModel):
    name: str
    venue_key: str = "auditorium"
    expected_attendance: int = 500
    duration_min: int = 180
    start_in_min: int = 0
    description: str = ""


@router.get("")
def list_events(user=Depends(require_roles()), db=Depends(get_db)):
    e = runtime.get_engine()
    live = {}
    for ev in e.state["events"]:
        live[ev["name"]] = ev
    rows = db.query(Event).order_by(Event.id.desc()).limit(40).all()
    out = []
    for r in rows:
        lv = live.get(r.name)
        cap = e.state["zones"].get(r.venue_key, {}).get("capacity", 1500)
        out.append({
            "id": r.id, "name": r.name, "venue_key": r.venue_key,
            "expected_attendance": r.expected_attendance,
            "current": lv["current"] if lv else 0,
            "occupancy_pct": round((lv["current"] / cap * 100) if lv else 0),
            "growth": "rising" if lv and lv["current"] < lv["expected"] * 0.85 else "steady",
            "capacity": cap,
            "predicted_peak": lv["peak_predicted"] if lv else int(r.expected_attendance * 1.15),
            "risk": "HIGH" if r.expected_attendance > cap else
                    ("MEDIUM" if lv and lv["current"] / cap > 0.6 else "LOW"),
            "status": "live" if lv else r.status,
            "start_ts": r.start_ts.isoformat(), "end_ts": r.end_ts.isoformat(),
            "description": r.description,
            "impact": _event_impact(e, r, lv),
        })
    return out


def _event_impact(engine, row, lv):
    return {
        "parking": f"+{int(row.expected_attendance/8)} vehicles projected",
        "traffic": "Gate inflow +20-35% during entry window",
        "stalls": f"Food court demand +{int(row.expected_attendance*0.004*60)}/h post-event",
        "resources": f"Electricity +{int(row.expected_attendance*0.05)} kW while live",
    }


@router.post("")
def create_event(body: EventIn, user=Depends(require_roles("EVENT_ADMIN", "CAMPUS_ADMIN")),
                 db=Depends(get_db)):
    e = runtime.get_engine()
    start = e.sim_time + timedelta(minutes=body.start_in_min)
    row = Event(name=body.name, venue_key=body.venue_key,
                expected_attendance=body.expected_attendance,
                start_ts=start, end_ts=start + timedelta(minutes=body.duration_min),
                status="scheduled", description=body.description)
    db.add(row)
    db.commit()
    if body.start_in_min <= 0:
        e.add_event(name=body.name, venue=body.venue_key,
                    expected=body.expected_attendance, duration_min=body.duration_min)
    audit(user.username, "event_create", f"{body.name} @ {body.venue_key}")
    return {"id": row.id, "ok": True}


@router.patch("/{event_id}")
def update_event(event_id: int, body: EventIn, user=Depends(require_roles("EVENT_ADMIN", "CAMPUS_ADMIN")),
                 db=Depends(get_db)):
    r = db.get(Event, event_id)
    if not r:
        raise HTTPException(status_code=404, detail="Event not found")
    r.name, r.venue_key = body.name, body.venue_key
    r.expected_attendance = body.expected_attendance
    r.description = body.description
    db.commit()
    e = runtime.get_engine()
    for ev in e.state["events"]:
        if ev["name"] == r.name or ev["name"] == body.name:
            ev["expected"] = body.expected_attendance
    audit(user.username, "event_update", f"event {event_id}")
    return {"ok": True}


@router.delete("/{event_id}")
def end_event(event_id: int, user=Depends(require_roles("EVENT_ADMIN", "CAMPUS_ADMIN")),
              db=Depends(get_db)):
    r = db.get(Event, event_id)
    if not r:
        raise HTTPException(status_code=404, detail="Event not found")
    r.status = "ended"
    db.commit()
    e = runtime.get_engine()
    e.state["events"] = [ev for ev in e.state["events"] if ev["name"] != r.name]
    audit(user.username, "event_end", f"event {event_id}")
    return {"ok": True}
