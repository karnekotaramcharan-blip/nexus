from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..db import get_db
from ..models import PrivacySettings, AuditLog, User, AppSettings
from ..security import require_roles, audit, hash_password
from ..services import risk as risk_svc

router = APIRouter(prefix="/api/v1/settings", tags=["settings"])


# ---------------------------------------------------------------- privacy
@router.get("/privacy")
def get_privacy(user=Depends(require_roles()), db=Depends(get_db)):
    p = db.query(PrivacySettings).first()
    return {"retention_days": p.retention_days, "face_blur": p.face_blur,
            "plate_blur": p.plate_blur, "plate_storage": p.plate_storage,
            "individual_tracking": p.individual_tracking, "auto_purge": p.auto_purge}


class PrivacyIn(BaseModel):
    retention_days: int | None = None
    face_blur: bool | None = None
    plate_blur: bool | None = None
    plate_storage: bool | None = None
    auto_purge: bool | None = None


@router.put("/privacy")
def put_privacy(body: PrivacyIn, user=Depends(require_roles("SUPER_ADMIN", "CAMPUS_ADMIN")),
                db=Depends(get_db)):
    p = db.query(PrivacySettings).first()
    for k, v in body.model_dump(exclude_none=True).items():
        setattr(p, k, v)
    p.individual_tracking = False  # hard guarantee
    p.updated_by = user.username
    db.commit()
    audit(user.username, "privacy_update", str(body.model_dump(exclude_none=True)))
    return {"ok": True}


@router.get("/privacy/notice")
def privacy_notice():
    return {"notice": (
        "NEXUS is privacy-first by design. It processes anonymous, aggregate analytics only: "
        "counting, density, movement patterns, vehicle classes, environment and resources. "
        "There is NO facial recognition, NO student identification, NO individual tracking and "
        "NO number-plate storage by default. Face/plate blurring can be enforced on all exported "
        "frames. Data retention is configurable with automatic purge. Camera credentials are "
        "stored encrypted server-side and never sent to clients.")}


# ---------------------------------------------------------------- risk weights
@router.get("/risk-weights")
def get_weights(user=Depends(require_roles())):
    return risk_svc.WEIGHTS


@router.put("/risk-weights")
def put_weights(weights: dict, user=Depends(require_roles("SUPER_ADMIN", "CAMPUS_ADMIN")),
                db=Depends(get_db)):
    total = sum(weights.values())
    if abs(total - 1.0) > 0.05:
        raise HTTPException(status_code=400, detail=f"Weights must sum to 1.0 (got {total:.2f})")
    risk_svc.WEIGHTS.clear()
    risk_svc.WEIGHTS.update(weights)
    row = db.query(AppSettings).filter(AppSettings.key == "risk_weights").first()
    if row:
        row.value = weights
    else:
        db.add(AppSettings(key="risk_weights", value=weights))
    db.commit()
    audit(user.username, "risk_weights_update", str(weights))
    return {"ok": True}


# ---------------------------------------------------------------- users (SUPER ADMIN)
@router.get("/users")
def list_users(user=Depends(require_roles("SUPER_ADMIN")), db=Depends(get_db)):
    rows = db.query(User).all()
    return [{"id": r.id, "username": r.username, "email": r.email, "role": r.role,
             "is_active": r.is_active, "is_demo_account": r.is_demo_account} for r in rows]


class UserIn(BaseModel):
    username: str
    email: str
    password: str
    full_name: str = ""
    role: str = "CAMPUS_ADMIN"


@router.post("/users")
def create_user(body: UserIn, user=Depends(require_roles("SUPER_ADMIN")), db=Depends(get_db)):
    if body.role not in ("SUPER_ADMIN", "CAMPUS_ADMIN", "SECURITY_ADMIN", "EVENT_ADMIN"):
        raise HTTPException(status_code=400, detail="Invalid role")
    if db.query(User).filter(User.username == body.username).first():
        raise HTTPException(status_code=409, detail="Username exists")
    db.add(User(username=body.username, email=body.email, password_hash=hash_password(body.password),
                full_name=body.full_name, role=body.role))
    db.commit()
    audit(user.username, "user_create", body.username)
    return {"ok": True}


@router.post("/users/{user_id}/toggle")
def toggle_user(user_id: int, user=Depends(require_roles("SUPER_ADMIN")), db=Depends(get_db)):
    r = db.get(User, user_id)
    if not r:
        raise HTTPException(status_code=404, detail="User not found")
    r.is_active = not r.is_active
    db.commit()
    audit(user.username, "user_toggle", f"{r.username} active={r.is_active}")
    return {"ok": True, "is_active": r.is_active}


# ---------------------------------------------------------------- audit log
@router.get("/audit")
def audit_log(limit: int = 100, user=Depends(require_roles()), db=Depends(get_db)):
    rows = db.query(AuditLog).order_by(AuditLog.id.desc()).limit(limit).all()
    return [{"id": r.id, "ts": r.ts.isoformat(), "actor": r.actor, "action": r.action,
             "detail": r.detail} for r in rows]


# ---------------------------------------------------------------- purge job
@router.post("/purge")
def purge_now(user=Depends(require_roles("SUPER_ADMIN")), db=Depends(get_db)):
    from ..services.purge import run_purge
    n = run_purge(db)
    audit(user.username, "manual_purge", f"{n} rows purged")
    return {"purged_rows": n}
