from fastapi import APIRouter, Depends
from pydantic import BaseModel

from ..security import require_roles, audit
from ..services import assistant, runtime

router = APIRouter(prefix="/api/v1/assistant", tags=["assistant"])


class ChatIn(BaseModel):
    message: str


@router.post("/chat")
async def chat(body: ChatIn, user=Depends(require_roles())):
    snapshot = runtime.build_snapshot()
    res = await assistant.answer(snapshot, body.message, user.username)
    audit(user.username, "assistant_chat", body.message[:200])
    return res


@router.get("/suggestions")
def suggestions(user=Depends(require_roles())):
    return {"suggestions": [
        "How is the campus right now?",
        "Where is the highest crowd concentration?",
        "Which parking zone will fill first?",
        "Which food stall has the shortest wait?",
        "Is any unusual activity happening?",
        "Why is the campus risk score high?",
        "What is today's biggest operational risk?",
        "What happens if the main gate is closed?",
        "What if heavy rain starts now?",
        "What events may create congestion?",
    ]}
