from fastapi import APIRouter, Depends

from ..security import require_roles, audit
from ..services import report as report_svc, runtime

router = APIRouter(prefix="/api/v1/reports", tags=["reports"])


@router.post("/daily")
async def daily(user=Depends(require_roles())):
    rep = await report_svc.generate_async(runtime.get_engine(), author=user.username)
    audit(user.username, "report_generate", "Explain My Campus daily report")
    return rep


@router.get("/list")
def list_reports(user=Depends(require_roles())):
    return report_svc.list_reports()
