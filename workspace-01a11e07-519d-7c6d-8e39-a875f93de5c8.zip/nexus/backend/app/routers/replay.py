from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func

from ..db import get_db
from ..security import require_roles
from ..models import CrowdRecord, TrafficRecord, StallQueueRecord, CampusMetric

router = APIRouter(prefix="/api/v1/replay", tags=["replay"])


@router.get("/days")
def days(user=Depends(require_roles()), db=Depends(get_db)):
    rows = db.query(func.date(CampusMetric.ts)).distinct().order_by(
        func.date(CampusMetric.ts).desc()).limit(35).all()
    return {"days": [r[0] for r in rows]}


@router.get("/day")
def day_data(day: str, user=Depends(require_roles()), db=Depends(get_db)):
    """Resampled 5-min frames for the replay scrubber + auto-generated narrative."""
    day_d = datetime.fromisoformat(day).date()

    def within(col):
        return func.date(col) == day

    pop = db.query(CampusMetric.ts, CampusMetric.population, CampusMetric.parking_occupancy,
                   CampusMetric.avg_congestion, CampusMetric.food_court_load).filter(
        within(CampusMetric.ts)).order_by(CampusMetric.ts).all()
    zones = db.query(CrowdRecord.ts, CrowdRecord.zone_key, CrowdRecord.count).filter(
        within(CrowdRecord.ts)).all()
    stalls = db.query(StallQueueRecord.ts, StallQueueRecord.stall_key, StallQueueRecord.queue).filter(
        within(StallQueueRecord.ts)).all()

    # group into 5-min frames
    def bucket(ts):
        return ts.replace(minute=(ts.minute // 5) * 5, second=0, microsecond=0)

    frames: dict[datetime, dict] = {}
    for ts, population, pocc, cong, food in pop:
        b = bucket(ts)
        frames.setdefault(b, {"t": b.strftime("%H:%M"), "population": 0, "parking": 0,
                              "congestion": 0, "food_load": 0, "zones": {}, "stalls": {}})
        f = frames[b]
        f["population"] = population or 0
        f["parking"] = pocc or 0
        f["congestion"] = cong or 0
        f["food_load"] = food or 0
    for ts, zk, count in zones:
        b = bucket(ts)
        if b in frames:
            frames[b]["zones"][zk] = count or 0
    for ts, sk, q in stalls:
        b = bucket(ts)
        if b in frames:
            frames[b]["stalls"][sk] = q or 0

    frame_list = [frames[k] for k in sorted(frames.keys())]

    # narrative: detect key moments
    narrative, prev = [], None
    for i, f in enumerate(frame_list):
        if prev:
            if f["population"] > prev["population"] * 1.18 and f["population"] > 800:
                narrative.append({"t": f["t"], "text": f"Crowd begins increasing sharply "
                                                       f"({prev['population']} → {f['population']})."})
            if f["parking"] >= 80 and prev["parking"] < 80:
                narrative.append({"t": f["t"], "text": f"Parking occupancy crosses 80% ({f['parking']:.0f}%)."})
            if f["congestion"] >= 0.8 and prev["congestion"] < 0.8:
                narrative.append({"t": f["t"], "text": f"Traffic congestion reaches HIGH ({f['congestion']:.2f})."})
            if f["food_load"] > prev["food_load"] * 1.5 and f["food_load"] > 60:
                narrative.append({"t": f["t"], "text": f"Food court rush: total queue {prev['food_load']} → "
                                                       f"{f['food_load']}."})
        prev = f
    cause = ("Likely cause chain: class-break/evening event inflow → gate surge → parking fill → "
             "food court rush." if narrative else "A calm day with no significant transitions.")
    return {"day": day, "frames": frame_list, "narrative": narrative[:14], "cause_chain": cause}
