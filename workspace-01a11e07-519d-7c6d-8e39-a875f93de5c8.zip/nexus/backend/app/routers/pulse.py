"""PUBLIC 'Campus Pulse' — anonymous, read-only, mobile-friendly. No auth, no ops data."""
from fastapi import APIRouter

from ..services import runtime

router = APIRouter(prefix="/api/v1/pulse", tags=["campus-pulse-public"])


@router.get("")
def pulse():
    s = runtime.build_snapshot()
    return {
        "sim_clock": s["sim_clock"],
        "stalls": [{"name": t["name"], "wait_min": t["wait_min"], "level": t["level"],
                    "closed": t["closed"]} for t in s["stalls"]],
        "best_stall": s["best_stall"],
        "parking": [{"name": p["name"], "available": max(0, p["capacity"] - p["occupied"]),
                     "occ_pct": p["occ_pct"]} for p in s["parking"]],
        "gates": [{"name": g["name"], "level": g["level"], "open": g["open"]} for g in s["gates"]],
        "events": [{"name": ev["name"], "venue_key": ev["venue_key"],
                    "start": ev["start"], "end": ev["end"]} for ev in s["events"]],
        "weather": s["weather"],
        "campus_status": s["risk"]["level"],  # coarse level only — no operational detail
    }
