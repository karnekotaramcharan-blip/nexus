from fastapi import APIRouter, Depends
from pydantic import BaseModel

from ..security import require_roles, audit
from ..services import runtime, director, scenarios

router = APIRouter(prefix="/api/v1/demo", tags=["demo-mode"])


class InjectIn(BaseModel):
    kind: str
    params: dict = {}


@router.post("/inject")
def inject(body: InjectIn, user=Depends(require_roles("CAMPUS_ADMIN", "SECURITY_ADMIN", "EVENT_ADMIN"))):
    e = runtime.get_engine()
    eff = e.inject(body.kind, **body.params)
    audit(user.username, "demo_inject", f"{body.kind} {body.params}")
    return {"ok": True, "effect": {k: str(v) for k, v in eff.items()}}


@router.post("/reset")
def reset(user=Depends(require_roles("CAMPUS_ADMIN", "SECURITY_ADMIN"))):
    runtime.reset_all()
    audit(user.username, "demo_reset", "")
    return {"ok": True}


@router.get("/controls")
def controls(user=Depends(require_roles())):
    return {"controls": [
        {"kind": "crowd_surge", "label": "Crowd surge (+950 over 10 min)", "params": {"total": 950, "ramp_min": 10, "duration_min": 45}},
        {"kind": "vehicle_surge", "label": "Vehicle surge (+45%)", "params": {"multiplier": 1.45, "duration_min": 60}},
        {"kind": "parking_shortage", "label": "Parking shortage", "params": {"duration_min": 40}},
        {"kind": "event", "label": "Start event (TECHNOVA 2026)", "params": {"name": "TECHNOVA 2026", "venue": "auditorium", "expected": 1200, "duration_min": 300}},
        {"kind": "food_rush", "label": "Food court rush", "params": {"multiplier": 1.7, "duration_min": 40}},
        {"kind": "gate_closed", "label": "Close Gate 1", "params": {"gate": "gate1", "duration_min": 60}},
        {"kind": "weather", "label": "Heavy rain", "params": {"condition": "heavy_rain", "rain_prob": 0.92, "duration_min": 60}},
        {"kind": "resource_anomaly", "label": "Resource anomaly (+35% power)", "params": {"duration_min": 45}},
        {"kind": "camera_failure", "label": "Camera failure (CAM-003)", "params": {"cam_id": "CAM-003", "duration_min": 30}},
    ]}


# --------------------------------------------------------------- director
@router.get("/director")
def director_state(user=Depends(require_roles())):
    return director.state()


@router.post("/director/run/{step_id}")
def director_run(step_id: int, user=Depends(require_roles())):
    res = director.run_step(step_id)
    audit(user.username, "director_step", f"step {step_id}")
    return res


@router.post("/director/reset")
def director_reset(user=Depends(require_roles())):
    runtime.reset_all()
    audit(user.username, "director_reset", "")
    return {"ok": True}


@router.get("/scenarios")
def list_scenarios(user=Depends(require_roles())):
    return scenarios.SCENARIOS
