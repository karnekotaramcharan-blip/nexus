from fastapi import APIRouter, Depends

from ..db import get_db
from ..models import StallQueueRecord, FoodStall
from ..security import require_roles, get_current_user
from ..services import runtime, predict
from sqlalchemy import func

router = APIRouter(prefix="/api/v1/stalls", tags=["food-stalls"])


@router.get("")
def stall_list(user=Depends(require_roles())):
    snap = runtime.build_snapshot()
    return {"stalls": snap["stalls"], "best_stall": snap["best_stall"],
            "worst_stall": snap["worst_stall"],
            "seating_occupancy": round(runtime.get_engine().state["food_court_seating_occ"] * 100)}


@router.get("/rush-forecast")
def rush_forecast(user=Depends(require_roles()), db=Depends(get_db)):
    """Learned rush-hour profile from history (class-break aligned, aggregate only)."""
    rows = db.query(func.strftime('%H', StallQueueRecord.ts).label("hh"),
                    func.sum(StallQueueRecord.queue)).group_by("hh").all()
    total_by_hour = {int(h): int(s or 0) for h, s in rows}
    peak = sorted(total_by_hour.items(), key=lambda kv: -kv[1])[:3]
    return {"queue_by_hour": total_by_hour,
            "predicted_peaks": [{"hour": h, "index": s} for h, s in peak],
            "note": "Aggregate, anonymous — derived from class-break schedule and history.",
            "staffing_hint": "Add 1 server per top stall during peak hours; pre-stock 11:45 and 16:15."}


@router.get("/owner-view")
def owner_view(user=Depends(require_roles())):
    """Stall-owner/manager dashboard: demand forecast + staffing windows."""
    e = runtime.get_engine()
    out = []
    for key, s in e.state["stalls"].items():
        f30 = predict.predict(f"queue:{key}", e.sim_time, float(s["queue"]), 30)
        from ..services.campus import zone_name
        out.append({
            "stall": zone_name(key),
            "current_queue": int(s["queue"]),
            "current_wait": s["wait_min"],
            "forecast_queue_30": f30["predicted"],
            "confidence": f30["confidence"],
            "staffing": "ADD 1 SERVER NOW" if f30["predicted"] > 18 else
                        ("PREPARE" if f30["predicted"] > 10 else "OK"),
            "stock_up_window": "next 20 min" if f30["predicted"] > 12 else "next 2 hours",
            "overcrowding_alert": f30["predicted"] > 25,
        })
    return out
