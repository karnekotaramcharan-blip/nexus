from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, EmailStr
import pydantic

from ..config import settings
from ..db import get_db
from ..models import User
from ..security import (verify_password, create_token, decode_token, get_current_user,
                        require_auth, rate_limit, audit)

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])

Email = EmailStr if hasattr(pydantic, "EmailStr") else str


class LoginIn(BaseModel):
    username: str
    password: str


class RefreshOut(BaseModel):
    access_token: str


@router.post("/login")
def login(body: LoginIn, request: Request, response: Response, db=Depends(get_db)):
    rate_limit(f"login:{request.client.host if request.client else 'x'}", max_calls=8, window=60)
    user = db.query(User).filter(
        (User.username == body.username) | (User.email == body.username)).first()
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account disabled")
    if settings.ENV == "production" and user.is_demo_account:
        raise HTTPException(status_code=403, detail="Demo accounts are disabled in production")
    access = create_token(user.username, user.role, "access")
    refresh = create_token(user.username, user.role, "refresh")
    response.set_cookie("nexus_access", access, httponly=True, samesite="lax",
                        max_age=settings.ACCESS_TOKEN_MINUTES * 60)
    response.set_cookie("nexus_refresh", refresh, httponly=True, samesite="lax",
                        max_age=settings.REFRESH_TOKEN_DAYS * 86400)
    audit(user.username, "login", f"role={user.role}")
    return {"access_token": access, "token_type": "bearer",
            "user": {"username": user.username, "email": user.email, "full_name": user.full_name,
                     "role": user.role, "is_demo_account": user.is_demo_account}}


@router.post("/refresh")
def refresh(request: Request, response: Response):
    token = request.cookies.get("nexus_refresh")
    if not token:
        raise HTTPException(status_code=401, detail="No refresh token")
    payload = decode_token(token, "refresh")
    access = create_token(payload["sub"], payload["role"], "access")
    response.set_cookie("nexus_access", access, httponly=True, samesite="lax",
                        max_age=settings.ACCESS_TOKEN_MINUTES * 60)
    return {"access_token": access}


@router.post("/logout")
def logout(response: Response, user=Depends(require_auth)):
    response.delete_cookie("nexus_access")
    response.delete_cookie("nexus_refresh")
    audit(user.username, "logout", "")
    return {"ok": True}


@router.get("/me")
def me(user=Depends(require_auth)):
    return {"username": user.username, "email": user.email, "full_name": user.full_name,
            "role": user.role, "is_demo_account": user.is_demo_account}
