"""
NEXUS shared simulation engine.
ONE engine powers Demo Mode (live ticks), the What-If Simulator (headless clones)
and Event Replay helpers — so numbers stay consistent everywhere.

Pure-Python, no DB access inside tick(): safe to clone & fast-forward.
"""
import copy
import math
import random
from datetime import datetime, timedelta

from .campus import ZONES, GATES, ROADS, PARKING, STALLS, CAMERAS, GATE_CAPACITY_PER_MIN, POPULABLE_ZONES

TICK = 1  # simulated minutes per tick


def sigmoid(x):
    return 1.0 / (1.0 + math.exp(-x))


def gauss(h, mu, sigma):
    return math.exp(-((h - mu) ** 2) / (2 * sigma * sigma))


def hour_of(dt):
    return dt.hour + dt.minute / 60.0


class Engine:
    def __init__(self, seed=42, sim_time: datetime | None = None):
        self.rng = random.Random(seed)
        now = sim_time or datetime.now().replace(second=0, microsecond=0)
        self.sim_time = now.replace(hour=8, minute=50)
        self.state = {}
        self.active_effects: list[dict] = []
        self.anomaly_flags: dict[str, dict] = {}
        self.reset_state()

    # ------------------------------------------------------------------ init
    def reset_state(self):
        st = self.sim_time
        self.state = {
            "sim_time": st,
            "zones": {k: {"crowd": 0, "capacity": cap, "kind": kind, "name": name}
                      for k, name, kind, cap, _, _ in ZONES},
            "gates": {k: {"open": True, "in_per_min": 0.0, "out_per_min": 0.0, "congestion": 0.0}
                      for k, _, _, _, _ in GATES},
            "roads": {k: {"volume": 0.0, "congestion": 0.0} for k, _, _, _ in ROADS},
            "parking": {k: {"occupied": 0, "capacity": cap, "closed": False, "overflow": 0}
                        for k, _, _, cap, _, _, _ in PARKING},
            "stalls": {k: {"queue": 0, "crowd": 0, "wait_min": 0.0, "closed": False}
                       for k, _, _, _, _, _, _ in STALLS},
            "events": [],
            "weather": {"temp_c": 27.0, "condition": "clear", "rain_prob": 0.05, "aqi": 82},
            "resources": {"electricity_kw": 200.0, "water_lpm": 140.0, "waste_kg_h": 30.0},
            "restricted_intrusions": 0,
            "cameras": {c[0]: {"status": "online", "ai_status": "active"} for c in CAMERAS},
            "population": 0,
            "vehicles_on_campus": 0,
            "food_court_seating_occ": 0.0,
        }
        self.active_effects = []
        self._prev_pop = 0
        self._pop_trend = 0.0

    # ------------------------------------------------------------- injection
    def inject(self, kind: str, **params):
        """Apply a demo/scenario effect. Effects carry expires_at in sim minutes."""
        eff = {"kind": kind, "started": self.sim_time, **params}
        dur = params.get("duration_min", 30)
        eff["expires"] = self.sim_time + timedelta(minutes=dur)
        if kind == "gate_closed":
            self.state["gates"][params["gate"]]["open"] = False
        if kind == "parking_closed":
            self.state["parking"][params["zone"]]["closed"] = True
        if kind == "stall_closed":
            self.state["stalls"][params["stall"]]["closed"] = True
        if kind == "weather":
            w = self.state["weather"]
            w["condition"] = params.get("condition", "heavy_rain")
            w["rain_prob"] = params.get("rain_prob", 0.9)
            if params.get("condition") == "clear":
                w["rain_prob"] = 0.05
        if kind == "camera_failure":
            self.state["cameras"][params["cam_id"]]["status"] = "offline"
        if kind == "event":
            self.add_event(**params)
        self.active_effects.append(eff)
        self.active_effects = [e for e in self.active_effects
                               if e["expires"] > self.sim_time or e["kind"] in
                               ("gate_closed", "parking_closed", "stall_closed", "event")]
        return eff

    def clear_effects(self):
        self.active_effects = []
        for g in self.state["gates"].values():
            g["open"] = True
        for p in self.state["parking"].values():
            p["closed"] = False
        for s in self.state["stalls"].values():
            s["closed"] = False
        for c in self.state["cameras"].values():
            c["status"] = "online"
        self.state["weather"] = {"temp_c": 27.0, "condition": "clear", "rain_prob": 0.05, "aqi": 82}

    def add_event(self, name="Campus Event", venue="auditorium", expected=800,
                  duration_min=180, **_):
        ev = {
            "id": len(self.state["events"]) + 1,
            "name": name,
            "venue_key": venue,
            "expected": int(expected),
            "current": 0,
            "start": self.sim_time,
            "end": self.sim_time + timedelta(minutes=duration_min),
            "peak_predicted": int(expected * 1.15),
        }
        self.state["events"].append(ev)
        return ev

    def _effect_mult(self, kind: str, default=1.0) -> float:
        m = default
        for e in self.active_effects:
            if e["kind"] == kind and e["expires"] > self.sim_time:
                m = e.get("multiplier", default)
        return m

    def _effect_active(self, kind: str, **match) -> dict | None:
        for e in self.active_effects:
            if e["kind"] == kind and e["expires"] > self.sim_time:
                if all(e.get(k) == v for k, v in match.items()):
                    return e
        return None

    # ------------------------------------------------------------ day curves
    def base_population_target(self, dt) -> float:
        h = hour_of(dt)
        weekday = dt.weekday() < 5
        day = max(0.0, sigmoid((h - 7.2) / 0.7) - sigmoid((h - 20.3) / 1.1))
        pop = 140 + 4100 * day * (1.0 if weekday else 0.32)
        return pop

    def vehicle_target(self, dt) -> float:
        h = hour_of(dt)
        weekday = dt.weekday() < 5
        day = max(0.0, sigmoid((h - 7.6) / 0.8) - sigmoid((h - 19.5) / 1.3))
        v = 60 + 610 * day * (1.0 if weekday else 0.3)
        for ev in self.state["events"]:
            if ev["start"] <= dt <= ev["end"] + timedelta(minutes=30):
                v += ev["expected"] / 8.0
        v *= self._effect_mult("vehicle_surge", 1.0)
        if self._effect_active("parking_shortage"):
            v *= 1.12
        return v

    # ------------------------------------------------------------------ tick
    def tick(self, minutes: int = TICK):
        for _ in range(minutes):
            self._tick_one()

    def _tick_one(self):
        st = self.state
        self.sim_time += timedelta(minutes=1)
        st["sim_time"] = self.sim_time
        dt = self.sim_time
        h = hour_of(dt)
        rng = self.rng
        rain = st["weather"]["rain_prob"]

        # ----- events lifecycle & attendance -----
        event_pull = 0
        for ev in st["events"][:]:
            if dt > ev["end"] + timedelta(minutes=60):
                st["events"].remove(ev)
                continue
            if dt < ev["start"]:
                continue
            frac_in = min(1.0, (dt - ev["start"]).total_seconds() / (45 * 60))
            if dt > ev["end"]:
                frac_in = max(0.0, 1 - (dt - ev["end"]).total_seconds() / (30 * 60))
            target = min(ev["expected"], st["zones"][ev["venue_key"]]["capacity"])
            ev["current"] = int(target * frac_in * self._effect_mult("event_crowd", 1.0))
            event_pull += ev["current"]

        # ----- campus population -----
        base = self.base_population_target(dt)
        surge = self._effect_active("crowd_surge")
        surge_add = 0
        if surge:
            surge_add = surge.get("total", 900) * min(1.0, (dt - surge["started"]).total_seconds()
                                                       / max(1, surge.get("ramp_min", 12)) / 60)
        pop_target = base + surge_add + event_pull * 0.35
        pop_target *= self._effect_mult("crowd_multiplier", 1.0)
        st["population"] = int(max(0, st["population"] + (pop_target - st["population"]) * 0.18
                                    + rng.gauss(0, 12)))
        self._pop_trend = st["population"] - self._prev_pop
        self._prev_pop = st["population"]
        pop = st["population"]

        # ----- zone distribution -----
        lunch = gauss(h, 13.0, 1.05)
        snack = gauss(h, 17.1, 0.9)
        rain_shift = min(1.0, rain * 1.2)
        shares = {
            "admin_block": 0.045, "library": 0.09 + 0.05 * rain_shift,
            "acad_a": 0.17, "acad_b": 0.15,
            "auditorium": 0.02, "plaza": 0.06 * (1 - 0.6 * rain_shift),
            "sports": (0.035 + 0.055 * gauss(h, 18.0, 1.6)) * (1 - 0.8 * rain_shift),
            "food_court": 0.05 + 0.17 * lunch + 0.08 * snack + 0.09 * rain_shift,
            "lake": 0.04 * (1 - 0.9 * rain_shift),
            "research": 0.012,
        }
        # events pull people into venue
        for ev in st["events"]:
            if ev["start"] <= dt <= ev["end"] and ev.get("current"):
                cap = st["zones"][ev["venue_key"]]["capacity"]
                shares[ev["venue_key"]] = max(shares.get(ev["venue_key"], 0.02),
                                              min(0.95, ev["current"] / max(pop, 1)))
        share_sum = sum(shares.values())
        spill = 0
        for key, share in shares.items():
            z = st["zones"][key]
            target = pop * share / share_sum
            if key == "restricted":
                target = min(target, 35)
            # venues may exceed capacity (that's the overcrowding signal); others soft-cap
            if z["kind"] not in ("venue",) and target > z["capacity"]:
                spill += target - z["capacity"]
                target = z["capacity"]
            z["crowd"] = int(max(0, z["crowd"] + (target - z["crowd"]) * 0.22 + rng.gauss(0, 4)))
        if spill:  # overflow gathers at the plaza
            st["zones"]["plaza"]["crowd"] = int(min(st["zones"]["plaza"]["capacity"],
                                                    st["zones"]["plaza"]["crowd"] + spill * 0.25))
        # gate queue crowds build when congested
        for gk, g in st["gates"].items():
            g["crowd"] = max(0, int(g.get("crowd", 0) * 0.8 + g["congestion"] * 120 * rng.uniform(0.7, 1.2)))

        # ----- gates & flows -----
        open_gates = [(k, st["gates"][k], share) for k, _, _, _, share in GATES if st["gates"][k]["open"]]
        closed_share = sum(share for k, _, _, _, share in GATES if not st["gates"][k]["open"])
        total_in = max(0.0, self._pop_trend) + 45 + pop * 0.006
        total_in *= self._effect_mult("vehicle_surge", 1.0) ** 0.3
        total_out = max(0.0, -self._pop_trend) + 40 + pop * 0.005
        share_norm = sum(s for _, _, s in open_gates) or 1
        for k, g, share in open_gates:
            extra = closed_share / len(open_gates) if open_gates else 0
            g["in_per_min"] = total_in * (share + extra) / share_norm
            g["out_per_min"] = total_out * (share + extra) / share_norm
            g["congestion"] = min(2.5, (g["in_per_min"] + g["out_per_min"]) / GATE_CAPACITY_PER_MIN)
        for k, g in st["gates"].items():
            if not g["open"]:
                g["in_per_min"] = g["out_per_min"] = 0.0
                g["congestion"] = 0.0

        # ----- roads -----
        flow_by_gate = {k: st["gates"][k]["in_per_min"] + st["gates"][k]["out_per_min"] for k, _, _, _, _ in GATES}
        n_closed = sum(1 for g in st["gates"].values() if not g["open"])
        redir = 1 + 0.30 * n_closed  # closed gates force recirculation on internal roads
        road_load = {
            "main_road": flow_by_gate["gate1"] * 0.45 + pop * 0.006,
            "north_ave": flow_by_gate["gate2"] * 0.55 + pop * 0.005,
            "ring_east": flow_by_gate["gate3"] * 0.55 + pop * 0.005 + (12 * n_closed),
            "central_spine": pop * 0.008 + st["zones"]["food_court"]["crowd"] * 0.02,
            "food_street": st["zones"]["food_court"]["crowd"] * 0.04,
        }
        for k, _, _, capv in ROADS:
            r = st["roads"][k]
            vol = road_load[k] * redir * (1 + 0.25 * rain) * rng.uniform(0.92, 1.08)
            r["volume"] = round(vol, 1)
            r["congestion"] = min(1.5, vol / capv)

        # ----- vehicles & parking -----
        v_target = self.vehicle_target(dt)
        st["vehicles_on_campus"] = int(max(0, st["vehicles_on_campus"]
                                           + (v_target - st["vehicles_on_campus"]) * 0.12 + rng.gauss(0, 3)))
        veh = st["vehicles_on_campus"]
        alloc = self._park_alloc(veh)
        for k, _, _, cap, _, _, pref in PARKING:
            pz = st["parking"][k]
            if pz["closed"]:
                pz["occupied"] = max(0, int(pz["occupied"] * 0.9))
                pz["overflow"] = 0
                continue
            want = alloc.get(k, 0)
            pz["occupied"] = int(max(0, pz["occupied"] + (want - pz["occupied"]) * 0.2
                                      + rng.gauss(0, 1.5)))
            pz["overflow"] = max(0, pz["occupied"] - cap)

        # ----- food stalls -----
        fc_arrivals = pop * (0.0016 + 0.0085 * lunch + 0.004 * snack)
        if self._effect_active("food_rush"):
            # force a lunch-like arrival wave, amplified by the rush multiplier
            fc_arrivals = max(fc_arrivals, pop * 0.008) * self._effect_mult("food_rush", 1.7)
        for ev in st["events"]:
            if ev["start"] <= dt <= ev["end"] and ev.get("current"):
                fc_arrivals += ev["current"] * 0.004
        open_stalls = [(k, pop_w) for k, _, pop_w, _, _, _, _ in STALLS if not st["stalls"][k]["closed"]]
        wsum = sum(w for _, w in open_stalls) or 1
        for k, _, pop_w, rate, servers, _, _ in STALLS:
            s = st["stalls"][k]
            if s["closed"]:
                s["queue"] = 0
                s["crowd"] = 0
                s["wait_min"] = 0
                continue
            arrivals = fc_arrivals * pop_w / wsum * rng.uniform(0.85, 1.15)
            capacity_serve = rate * servers
            new_q = max(0.0, s["queue"] + arrivals - min(capacity_serve, s["queue"] + arrivals))
            s["queue"] = round(s["queue"] * 0.25 + new_q * 0.75, 1)
            s["crowd"] = int(arrivals * 6 + s["queue"])
            s["wait_min"] = round(s["queue"] / max(0.5, capacity_serve), 1)
        st["food_court_seating_occ"] = min(1.0, st["zones"]["food_court"]["crowd"] /
                                           max(1, st["zones"]["food_court"]["capacity"]))

        # ----- weather drift -----
        w = st["weather"]
        if not self._effect_active("weather"):
            w["rain_prob"] = max(0.02, min(0.95, w["rain_prob"] + rng.gauss(0, 0.01)))
            w["temp_c"] = 24 + 7 * gauss(h, 14.5, 3.4) + rng.gauss(0, 0.15)
            if w["rain_prob"] > 0.6:
                w["condition"] = "rain"
            elif w["rain_prob"] > 0.85:
                w["condition"] = "heavy_rain"
            else:
                w["condition"] = "clear" if w["rain_prob"] < 0.3 else "cloudy"

        # ----- resources -----
        day = max(0.0, sigmoid((h - 7.2) / 0.8) - sigmoid((h - 20.5) / 1.2))
        event_add = sum(ev["current"] for ev in st["events"]) * 0.05
        res = st["resources"]
        res_mult = 1.35 if self._effect_active("resource_anomaly") else 1.0
        res["electricity_kw"] = round((185 + 150 * day + event_add) * res_mult + rng.gauss(0, 4), 1)
        res["water_lpm"] = round((120 + 90 * day + 60 * lunch) * res_mult + rng.gauss(0, 2), 1)
        res["waste_kg_h"] = round((25 + 40 * lunch + 18 * snack) * res_mult + rng.gauss(0, 1), 1)

        # ----- restricted zone intrusions (rare) -----
        if self._effect_active("restricted_intrusion") or rng.random() < 0.012:
            st["restricted_intrusions"] += 1
        else:
            st["restricted_intrusions"] = max(0, st["restricted_intrusions"] - 0)

        # ----- camera recovery -----
        for cam_id, c in st["cameras"].items():
            if c["status"] == "offline":
                eff = self._effect_active("camera_failure", cam_id=cam_id)
                if not eff:
                    c["status"] = "online"

    def _park_alloc(self, veh: float) -> dict[str, float]:
        """Capacity-aware proportional allocation; closed zones shed demand to open ones."""
        st = self.state
        open_z = [(k, pref, cap) for k, _, _, cap, _, _, pref in PARKING if not st["parking"][k]["closed"]]
        if not open_z:
            return {}
        alloc = {}
        leftover = veh
        for _ in range(3):  # iterate: capped zones shed leftover to others
            leftover = veh - sum(alloc.values())
            if leftover <= 1:
                break
            pool = [(k, p, c) for k, p, c in open_z if alloc.get(k, 0) < c]
            if not pool:
                break
            pool_pref = sum(p for _, p, _ in pool)
            for k, p, c in pool:
                share = leftover * (p / pool_pref)
                alloc[k] = min(c, alloc.get(k, 0) + max(0, share))
        return {k: round(v, 1) for k, v in alloc.items()}

    # ------------------------------------------------------------- snapshot
    def zone_level(self, key) -> tuple[float, str]:
        z = self.state["zones"][key]
        d = z["crowd"] / max(1, z["capacity"])
        lvl = "LOW" if d < 0.45 else "MEDIUM" if d < 0.7 else "HIGH" if d < 0.9 else "CRITICAL"
        return round(d, 3), lvl

    def predicted_parking_minutes_to_full(self, key) -> int | None:
        pz = self.state["parking"][key]
        if pz["closed"]:
            return 0
        occ, cap = pz["occupied"], pz["capacity"]
        if occ >= cap:
            return 0
        veh_t = self.vehicle_target(self.sim_time)
        for ev in self.state["events"]:
            if ev["start"] <= self.sim_time <= ev["end"] + timedelta(minutes=30):
                veh_t += ev["expected"] / 8.0
        target_occ = self._park_alloc(veh_t).get(key, 0)
        growth = (target_occ - occ) * 0.2  # per-minute approach rate (matches tick)
        if growth <= 0.5:
            return None
        return int((cap - occ) / growth)

    def stall_trend(self, key) -> str:
        # trend hint from queue vs service equilibrium
        s = self.state["stalls"][key]
        return "rising" if s["wait_min"] > 8 else ("steady" if s["wait_min"] > 3 else "falling")

    def clone(self, seed=None) -> "Engine":
        c = Engine.__new__(Engine)
        c.rng = random.Random(seed if seed is not None else self.rng.random())
        c.sim_time = self.sim_time
        c.state = copy.deepcopy(self.state)
        c.active_effects = copy.deepcopy(self.active_effects)
        c.anomaly_flags = copy.deepcopy(self.anomaly_flags)
        c._prev_pop = self._prev_pop
        c._pop_trend = self._pop_trend
        return c

    def run_headless(self, minutes: int, record_every: int = 2) -> list[dict]:
        """Fast-forward and record compact series (used by What-If & forecast overlay)."""
        series = []
        for i in range(minutes):
            self.tick(1)
            if i % record_every == 0 or i == minutes - 1:
                st = self.state
                series.append({
                    "t": self.sim_time.strftime("%H:%M"),
                    "population": st["population"],
                    "risk": None,  # filled by caller if needed
                    "parking_occ": round(sum(p["occupied"] for p in st["parking"].values()) /
                                         max(1, sum(p["capacity"] for p in st["parking"].values())) * 100, 1),
                    "crowd_top": {k: z["crowd"] for k, z in st["zones"].items()},
                    "max_gate_congestion": round(max(g["congestion"] for g in st["gates"].values()), 2),
                    "max_stall_wait": round(max(s["wait_min"] for s in st["stalls"].values()), 1),
                    "avg_road_congestion": round(sum(r["congestion"] for r in st["roads"].values()) /
                                                 len(st["roads"]), 2),
                })
        return series
