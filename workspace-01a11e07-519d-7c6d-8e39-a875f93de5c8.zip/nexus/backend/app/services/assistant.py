"""AI Decision Assistant: answers ONLY from the structured live snapshot.
LLM optional (env-configured); robust template-based fallback guarantees the demo."""
import json
import re

from ..config import settings
from . import scenarios
from .campus import zone_name


def _snapshot_context(snapshot: dict) -> dict:
    """Compact structured context passed to the LLM (no invented numbers possible)."""
    s = snapshot
    return {
        "sim_time": s["sim_clock"],
        "population": s["population"],
        "risk": {"score": s["risk"]["score"], "level": s["risk"]["level"],
                 "factors": [(f["label"], f["contribution"]) for f in s["risk"]["factors"][:4]]},
        "top_zones": sorted([(z["name"], z["crowd"], z["level"]) for z in s["zones"]],
                            key=lambda x: -x[1])[:5],
        "parking": [(p["name"], p["occ_pct"], p["minutes_to_full"]) for p in s["parking"]],
        "gates": [(g["name"], g["in_per_min"], g["out_per_min"], g["level"], g["open"]) for g in s["gates"]],
        "stalls": [(t["name"], t["queue"], t["wait_min"], t["level"]) for t in s["stalls"]],
        "best_stall": s["best_stall"],
        "events": [(ev["name"], ev["current"], ev["expected"], ev["venue_key"]) for ev in s["events"]],
        "anomalies": [(a["metric"], a["reason"]) for a in s["anomalies"][:4]],
        "recommendations": [r["title"] for r in s["recommendations"][:4]],
        "weather": s["weather"],
    }


async def _llm_answer(ctx: dict, question: str) -> str | None:
    if not settings.LLM_API_KEY:
        return None
    import httpx
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(
                f"{settings.LLM_BASE_URL.rstrip('/')}/chat/completions",
                headers={"Authorization": f"Bearer {settings.LLM_API_KEY}"},
                json={"model": settings.LLM_MODEL,
                      "messages": [
                          {"role": "system",
                           "content": "You are NEXUS, the AI assistant of a campus intelligence platform. "
                                      "Answer ONLY using the provided JSON snapshot. Never invent numbers. "
                                      "Be concise (<=120 words), operational, and cite concrete values."},
                          {"role": "user",
                           "content": f"SNAPSHOT:\n{json.dumps(ctx, indent=1)[:6000]}\n\nQUESTION: {question}"}],
                      "temperature": 0.2, "max_tokens": 400})
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
    except Exception:
        return None


def _detect_whatif(q: str) -> tuple[str, dict] | None:
    ql = q.lower()
    if ("gate" in ql and ("close" in ql or "closed" in ql or "shut" in ql or "block" in ql)):
        gate = "gate2" if "2" in ql or "north" in ql else "gate3" if "3" in ql or "east" in ql else "gate1"
        return "gate_closed", {"gate": gate}
    if "rain" in ql:
        return "heavy_rain", {}
    if "parking" in ql and ("close" in ql or "unavailable" in ql or "full" in ql):
        z = "park_b" if "b" in ql else "park_c" if "c" in ql else "park_a"
        return "parking_closed", {"zone": z}
    if ("vehicle" in ql or "car" in ql) and ("more" in ql or "extra" in ql or "30%" in ql or "increase" in ql):
        return "extra_vehicles", {"multiplier": 1.3}
    if "stall" in ql and ("close" in ql or "shut" in ql):
        return "stall_closed", {"stall": "snack_corner"}
    if "event" in ql and ("2000" in ql or "2,000" in ql or "more" in ql or "attract" in ql):
        return "event_crowd_increase", {"multiplier": 1.8}
    if "evacuat" in ql:
        return "evacuation", {"zone": "auditorium"}
    return None


async def answer(snapshot: dict, question: str, user: str) -> dict:
    """Returns {answer, data?, simulation?, source}."""
    q = question.lower().strip()
    ctx = _snapshot_context(snapshot)
    s = snapshot

    # --- tool call: what-if simulation requested in natural language ---
    wif = _detect_whatif(q)
    if wif and ("what if" in q or "what happens" in q or "simulate" in q or "if " in q or "?" in q):
        scenario, params = wif
        from .runtime import get_engine
        result = scenarios.run(get_engine(), scenario, params)
        sim_words = {
            "risk": f"Risk moves {result['risk_current']} → {result['risk_simulated']}.",
        }
        gates_txt = ", ".join(f"{zone_name(k)} congestion {v['now']}→{v['sim']}"
                              + ("" if v["open"] else " (CLOSED)")
                              for k, v in result["impacts"]["gates"].items())
        park_txt = ", ".join(f"{zone_name(k)} {v['now_occ_pct']}%→{v['sim_occ_pct']}%"
                             for k, v in result["impacts"]["parking"].items())
        stall_txt = ", ".join(f"{zone_name(k)} {v['now_wait']:.0f}→{v['sim_wait']:.0f} min"
                              for k, v in list(result["impacts"]["stalls"].items())[:4])
        rec_txt = "; ".join(r["title"] for r in result["recommendations"][:3])
        text = (f"I ran the '{result['scenario_label']}' simulation for 60 simulated minutes. "
                f"{sim_words['risk']} Gates: {gates_txt}. Parking: {park_txt}. "
                f"Stall waits: {stall_txt}. Recommended: {rec_txt}")
        return {"answer": text, "simulation": result, "source": "what-if-engine"}

    # --- template intents (guaranteed fallback) ---
    if any(w in q for w in ("how is the campus", "status", "overview", "right now", "summary")):
        r = s["risk"]
        top = s["zones"][0]
        top = max(s["zones"], key=lambda z: z["crowd"])
        ans = (f"Campus at {s['sim_clock']}: population {s['population']:,}, risk {r['score']}/100 "
               f"({r['level']}). Highest crowd: {top['name']} ({top['crowd']} people, {top['level']}). "
               f"Food court: shortest wait at {s['best_stall']['name']} (~{s['best_stall']['wait_min']:.0f} min). "
               f"{len(s['anomalies'])} active anomalies, {len(s['recommendations'])} open recommendations.")
        return {"answer": ans, "source": "template"}

    if "highest crowd" in q or "crowd concentration" in q or "most crowded" in q:
        top = sorted(s["zones"], key=lambda z: -z["crowd"])[:3]
        ans = "Highest crowd concentration: " + "; ".join(
            f"{z['name']} — {z['crowd']} people ({z['level']}, {int(z['density']*100)}% of capacity)"
            for z in top) + "."
        return {"answer": ans, "source": "template"}

    if "parking" in q and ("fill" in q or "first" in q or "full" in q):
        mtfs = sorted(((p["name"], p["minutes_to_full"]) for p in s["parking"] if p["minutes_to_full"] is not None),
                      key=lambda x: x[1])
        if mtfs:
            ans = (f"{mtfs[0][0]} will fill first — projected full in ~{mtfs[0][1]} minutes "
                   f"(currently {[p['occ_pct'] for p in s['parking'] if p['name']==mtfs[0][0]][0]}% occupied). ")
            ans += "Others: " + ", ".join(f"{n} in ~{m} min" for n, m in mtfs[1:3]) + "."
        else:
            occ = max(s["parking"], key=lambda p: p["occ_pct"])
            ans = (f"No zone is projected to fill within the horizon right now. Busiest is {occ['name']} "
                   f"at {occ['occ_pct']}% occupancy.")
        return {"answer": ans, "source": "template"}

    if "stall" in q and ("shortest" in q or "best" in q or "least" in q or "wait" in q):
        b, w = s["best_stall"], s["worst_stall"]
        ans = (f"Best stall right now: {b['name']} with ~{b['wait_min']:.0f} min wait. "
               f"Avoid {w['name']} (~{w['wait_min']:.0f} min wait).")
        return {"answer": ans, "source": "template"}

    if "unusual" in q or "anomal" in q or "abnormal" in q:
        if s["anomalies"]:
            ans = "Yes — active anomalies: " + " | ".join(
                f"{a['metric']}: observed {a['observed']:.0f} vs expected {a['expected_low']:.0f}–"
                f"{a['expected_high']:.0f} (confidence {int(a['confidence']*100)}%)"
                for a in s["anomalies"][:3]) + "."
        else:
            ans = "No unusual activity right now — all metrics are within their learned hour-of-day baselines."
        return {"answer": ans, "source": "template"}

    if "risk" in q and ("why" in q or "high" in q or "score" in q or "explain" in q):
        r = s["risk"]
        ans = (f"Risk is {r['score']}/100 ({r['level']}). Contributions: "
               + ", ".join(f"{f['label']} +{f['contribution']:.0f}" for f in r["factors"][:4]) + ". "
               + (r["factors"][0]["reasons"][0] if r["factors"] else ""))
        return {"answer": ans, "source": "template"}

    if "biggest" in q and "risk" in q:
        f0 = s["risk"]["factors"][0] if s["risk"]["factors"] else None
        ans = (f"Biggest operational risk today: {f0['label']} (contributes +{f0['contribution']:.0f} to the "
               f"score) — {f0['reasons'][0] if f0 else 'n/a'}" if f0 else
               "No significant risks right now.")
        return {"answer": ans, "source": "template"}

    if "event" in q and ("congestion" in q or "create" in q or "which" in q or "today" in q):
        evs = s["events"]
        if evs:
            ans = "Live/upcoming events: " + "; ".join(
                f"{ev['name']} at {ev['venue_key']} — {ev['current']}/{ev['expected']} attendees, "
                f"risk {ev['risk']}" for ev in evs) + "."
        else:
            ans = "No live events right now; congestion risk from events is low."
        return {"answer": ans, "source": "template"}

    if "recommend" in q or "action" in q or "should i" in q:
        recs = s["recommendations"][:3]
        ans = ("Top recommendations: " + "; ".join(f"({i+1}) {r['title']}" for i, r in enumerate(recs)) + ".") \
              if recs else "No interventions needed right now — campus is operating normally."
        return {"answer": ans, "source": "template"}

    if "weather" in q or "rain" in q:
        w = s["weather"]
        ans = (f"Weather: {w['condition']}, {w['temp_c']:.0f}°C, rain probability "
               f"{int(w['rain_prob']*100)}%, AQI {w['aqi']}.")
        return {"answer": ans, "source": "template"}

    # --- default: try LLM, else generic grounded answer ---
    llm = await _llm_answer(ctx, question)
    if llm:
        return {"answer": llm, "source": "llm"}
    r = s["risk"]
    ans = (f"Here's the current picture ({s['sim_clock']}): population {s['population']:,}, "
           f"risk {r['score']}/100 ({r['level']}), {len(s['anomalies'])} anomalies, "
           f"best stall {s['best_stall']['name'] if s['best_stall'] else 'n/a'}. "
           f"Ask me about crowds, parking, stalls, traffic, events, anomalies, risks — or ask a "
           f"'what if' question and I'll run a simulation.")
    return {"answer": ans, "source": "template"}
