"""Retention purge job: deletes time-series older than the configured retention window."""
from datetime import datetime, timedelta

from ..models import (CrowdRecord, VehicleRecord, TrafficRecord, StallQueueRecord,
                      EnvironmentalData, ResourceUsage, CampusMetric, Anomaly, PrivacySettings)


def run_purge(db) -> int:
    p = db.query(PrivacySettings).first()
    if not p or not p.auto_purge:
        return 0
    cutoff = datetime.utcnow() - timedelta(days=p.retention_days)
    total = 0
    for model in (CrowdRecord, VehicleRecord, TrafficRecord, StallQueueRecord,
                  EnvironmentalData, ResourceUsage, CampusMetric, Anomaly):
        col = model.ts
        total += db.query(model).filter(col < cutoff).delete()
    db.commit()
    return total
