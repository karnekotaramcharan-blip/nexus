"""AI Risk Engine: weighted, fully explained campus risk score (0-100)."""

DEFAULT_WEIGHTS = {
    "crowd": 0.28, "parking": 0.18, "traffic": 0.14, "events": 0.12,
    "food": 0.10, "weather": 0.08, "restricted": 0.06, "resources": 0.04,
}
WEIGHTS = dict(DEFAULT_WEIGHTS)

LEVELS = [(30, "NORMAL", "🟢"), (55, "MODERATE", "🟡"), (75, "ELEVATED", "🟠"), (101, "CRITICAL", "🔴")]


def level_of(score: float):
    for cap, name, icon in LEVELS:
        if score < cap:
            return name, icon
    return "CRITICAL", "🔴"


def compute(engine, active_anoms: list[dict]) -> dict:
    st = engine.state
    f = {}

    # crowd: max zone pressure + growth (normalized: <55% is routine campus operation)
    crowd_s, crowd_reasons = 0.0, []
    for key, z in st["zones"].items():
        d = z["crowd"] / max(1, z["capacity"])
        pressure = max(0.0, (d - 0.55) / 0.45)
        if pressure > crowd_s:
            crowd_s = pressure
            crowd_reasons = [f"{z['name']} at {d*100:.0f}% of capacity ({z['crowd']} people)"]
    if engine._pop_trend > 40:
        crowd_s = min(1.35, crowd_s + 0.12)
        crowd_reasons.append(f"Population growing fast (+{int(engine._pop_trend)}/min)")
    f["crowd"] = (min(1.0, crowd_s), crowd_reasons)

    # parking: max occupancy incl. overflow (normalized: <50% is routine)
    park_s, park_reasons = 0.0, []
    for key, pz in st["parking"].items():
        occ = pz["occupied"] / max(1, pz["capacity"])
        if pz["closed"]:
            park_reasons.append(f"{key.upper()} closed — demand redirected")
            occ = max(occ, 0.55)
        pressure = max(0.0, (occ - 0.50) / 0.50)
        if pressure > park_s:
            park_s = pressure
            park_reasons = [f"{key.replace('park_','Zone ').upper()} at {min(100,int(occ*100))}% occupancy"]
        mtf = engine.predicted_parking_minutes_to_full(key)
        if mtf is not None and mtf <= 20 and not pz["closed"] and occ >= 0.6:
            park_s = max(park_s, 0.9)
            park_reasons.append(f"{key.replace('park_','Zone ').upper()} projected full in ~{mtf} min")
    f["parking"] = (min(1.0, park_s), park_reasons)

    # traffic
    cong = [(k, r["congestion"]) for k, r in st["roads"].items()]
    worst = max(cong, key=lambda x: x[1])
    gate_worst = max(st["gates"].items(), key=lambda kv: kv[1]["congestion"])
    traf_s = min(1.0, worst[1] * 0.7 + gate_worst[1]["congestion"] * 0.35)
    traf_reasons = [f"{worst[0].replace('_',' ').title()} congestion {worst[1]:.2f}",
                    f"{gate_worst[0].upper()} flow {gate_worst[1]['in_per_min']:.0f} in/min"]
    if not gate_worst[1]["open"]:
        traf_reasons.append(f"{gate_worst[0].upper()} CLOSED — flow redistributed")
    f["traffic"] = (traf_s, traf_reasons)

    # events
    ev_s, ev_reasons = 0.0, []
    for ev in st["events"]:
        cap = st["zones"][ev["venue_key"]]["capacity"]
        ratio = ev["current"] / max(1, cap)
        if ratio > ev_s:
            ev_s = ratio
            ev_reasons = [f"{ev['name']}: {ev['current']}/{cap} at {ev['venue_key']}"]
        if ev["expected"] > cap:
            ev_s = min(1.2, ev_s + 0.15)
            ev_reasons.append(f"Expected attendance ({ev['expected']}) exceeds venue capacity ({cap})")
    f["events"] = (min(1.0, ev_s), ev_reasons or ["No major live events"])

    # food court
    waits = [(k, s["wait_min"], s["queue"]) for k, s in st["stalls"].items() if not s["closed"]]
    worst_stall = max(waits, key=lambda x: x[1]) if waits else ("-", 0, 0)
    fc_occ = st["food_court_seating_occ"]
    food_s = min(1.0, worst_stall[1] / 18.0 * 0.6 + fc_occ * 0.5)
    f["food"] = (food_s, [f"Longest queue: {worst_stall[0]} ~{worst_stall[1]:.0f} min",
                          f"Seating occupancy {fc_occ*100:.0f}%"] if worst_stall[1] > 4 else
                 ["Food court operating normally"])

    # weather
    w = st["weather"]
    wx_s = w["rain_prob"] * (0.9 if any(st["events"]) else 0.45)
    if w["temp_c"] > 36:
        wx_s += 0.2
    wx_reasons = [f"{w['condition'].replace('_',' ')} | rain probability {w['rain_prob']*100:.0f}%"]
    if w["rain_prob"] > 0.6 and any(st["events"]):
        wx_reasons.append("Rain during a live event raises disruption & shelter-rush risk")
    f["weather"] = (min(1.0, wx_s), wx_reasons)

    # restricted zone
    intr = st["restricted_intrusions"]
    f["restricted"] = (min(1.0, intr * 0.3),
                       [f"{intr} restricted-zone intrusion(s) detected"] if intr else
                       ["No restricted-zone activity"])

    # resources
    res_anom = [a for a in active_anoms if a["target"].startswith("resource:")]
    res_s = 0.7 if res_anom else 0.1
    f["resources"] = (res_s, [a["reason"][:120] for a in res_anom] or ["Consumption within normal range"])

    score = sum(WEIGHTS[k] * f[k][0] for k in WEIGHTS) * 100
    score = round(min(100, score), 1)
    lvl, icon = level_of(score)
    factors = []
    for k, (s, reasons) in f.items():
        contrib = round(WEIGHTS[k] * s * 100, 1)
        if contrib >= 1:
            factors.append({"key": k, "label": k.title(), "contribution": contrib,
                            "normalized": round(s, 2), "reasons": reasons[:3]})
    factors.sort(key=lambda x: -x["contribution"])
    return {"score": score, "level": lvl, "icon": icon, "factors": factors,
            "weights": WEIGHTS,
            "summary": f"Campus risk {score:.0f}/100 ({lvl}) driven mainly by "
                       + ", ".join(x["label"] + f" (+{x['contribution']:.0f})" for x in factors[:3])}
