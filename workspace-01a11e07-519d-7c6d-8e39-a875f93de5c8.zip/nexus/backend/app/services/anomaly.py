"""Explainable anomaly detection over the live engine state.

Method: robust z-score against hour-of-day/day-type baselines learned from history.
Every anomaly carries observed vs expected range, deviation and a plain-language reason.
"""
from datetime import datetime

from ..db import SessionLocal
from ..models import Anomaly
from . import baselines
from .campus import ZONES, STALLS, zone_name

ACTIVE: dict[str, dict] = {}   # target -> anomaly dict (live view)
COOLDOWN_MIN = 12


def _mk_reason(metric_label: str, observed: float, lo: float, hi: float, z: float) -> str:
    direction = "above" if z > 0 else "below"
    pct = 0
    mid = (lo + hi) / 2
    if mid > 0:
        pct = int(abs(observed - mid) / mid * 100)
    return (f"{metric_label} is {observed:.0f}, significantly {direction} the normal historical "
            f"range of {lo:.0f}–{hi:.0f} for this hour (~{pct}% {direction} typical). "
            f"Deviation {z:+.1f}σ from learned baseline.")


def check(engine) -> list[dict]:
    """Run anomaly checks against engine state. Returns newly-raised anomalies."""
    dt: datetime = engine.sim_time
    raised = []
    db = SessionLocal()
    try:
        checks = []
        for key, name, kind, cap, _, _ in ZONES:
            crowd = engine.state["zones"][key]["crowd"]
            checks.append((f"crowd:{key}", f"Crowd — {name}", float(crowd)))
        for key, name, popw, rate, servers, _, _ in STALLS:
            q = engine.state["stalls"][key]["queue"]
            checks.append((f"queue:{key}", f"Queue — {name}", float(q)))
        res = engine.state["resources"]
        checks.append(("resource:electricity", "Electricity consumption", res["electricity_kw"]))
        checks.append(("resource:water", "Water consumption", res["water_lpm"]))

        for target, label, observed in checks:
            z = baselines.zscore(target, dt, observed)
            if z is None:
                continue
            lo_hi = baselines.expected_range(target, dt)
            lo, hi = lo_hi
            is_anom = abs(z) >= 2.6 and (observed > hi or observed < lo * 0.4)
            prev = ACTIVE.get(target)
            if is_anom:
                if prev and (dt - prev["ts"]).total_seconds() < COOLDOWN_MIN * 60:
                    prev.update(observed=observed, z=z)
                    continue
                severity = "critical" if abs(z) >= 4.0 else "warning"
                confidence = round(min(0.98, 0.55 + abs(z) / 12), 2)
                anom = {
                    "target": target, "metric": label, "observed": observed,
                    "expected_low": lo, "expected_high": hi, "z": round(z, 2),
                    "confidence": confidence, "severity": severity, "ts": dt,
                    "reason": _mk_reason(label, observed, lo, hi, z),
                }
                ACTIVE[target] = anom
                raised.append(anom)
                db.add(Anomaly(target=target, metric=label, ts=dt, observed=observed,
                               expected_low=lo, expected_high=hi, deviation=round(z, 2),
                               confidence=confidence, severity=severity, reason=anom["reason"]))
            elif prev and abs(z) < 1.6:
                prev["resolved"] = True
        db.commit()
    finally:
        db.close()
    return raised


def active_anomalies() -> list[dict]:
    out = []
    for t, a in ACTIVE.items():
        if not a.get("resolved"):
            out.append({**a, "ts": a["ts"].isoformat()})
    return sorted(out, key=lambda x: -abs(x["z"]))
