"""Static campus topology: single source of truth shared by engine, seed, map and APIs."""

ZONES = [
    # key, name, kind, capacity, cx, cy
    ("admin_block", "Admin Block", "academic", 400, 120, 95),
    ("library", "Central Library", "academic", 700, 255, 225),
    ("acad_a", "Academic Block A", "academic", 1200, 235, 385),
    ("acad_b", "Academic Block B", "academic", 1200, 400, 470),
    ("auditorium", "Main Auditorium", "venue", 1500, 500, 265),
    ("plaza", "Central Plaza", "outdoor", 900, 470, 380),
    ("sports", "Sports Arena", "outdoor", 1200, 850, 175),
    ("food_court", "Food Court & Seating", "food", 800, 700, 430),
    ("lake", "Green & Lake Area", "outdoor", 600, 905, 470),
    ("research", "Research Labs (Restricted)", "restricted", 300, 900, 80),
]

GATES = [
    # key, name, cx, cy, share of campus flow
    ("gate1", "Gate 1 — Main Gate (West)", 18, 330, 0.50),
    ("gate2", "Gate 2 — North Gate", 520, 18, 0.30),
    ("gate3", "Gate 3 — East Gate", 985, 330, 0.20),
]

GATE_CAPACITY_PER_MIN = 220  # people throughput before congestion

ROADS = [
    # key, name, path (for map), capacity vehicles/min
    ("main_road", "Main Road", [(20, 330), (470, 330)], 78),
    ("north_ave", "North Avenue", [(520, 20), (520, 240)], 62),
    ("ring_east", "Ring Road East", [(980, 330), (640, 330)], 62),
    ("central_spine", "Central Spine", [(470, 330), (470, 520)], 58),
    ("food_street", "Food Street", [(470, 430), (640, 430)], 46),
]

PARKING = [
    # key, name, category, capacity, cx, cy, demand preference
    ("park_a", "Parking Zone A (Visitor/4W)", "four_wheeler", 150, 370, 90, 0.30),
    ("park_b", "Parking Zone B (Student/2W)", "two_wheeler", 220, 600, 120, 0.35),
    ("park_c", "Parking Zone C (Faculty)", "faculty", 120, 110, 470, 0.15),
    ("park_d", "Parking Zone D (Overflow)", "mixed", 180, 800, 560, 0.20),
]

STALLS = [
    # key, name, popularity, service_rate/min per server, servers, cx, cy
    ("main_canteen", "Main Canteen", 1.30, 4.2, 3, 652, 402),
    ("snack_corner", "Snack Corner", 1.20, 3.4, 2, 690, 396),
    ("juice_bar", "Juice Bar", 0.90, 5.5, 1, 728, 402),
    ("coffee_kiosk", "Coffee Kiosk", 1.05, 6.0, 1, 762, 412),
    ("south_indian", "South Indian", 1.25, 3.6, 2, 664, 442),
    ("chinese", "Chinese Wok", 0.95, 3.2, 2, 700, 450),
    ("bakery", "Bakery", 0.80, 5.0, 1, 736, 444),
    ("ice_cream", "Ice Cream Corner", 0.70, 5.0, 1, 766, 452),
]

CAMERAS = [
    ("CAM-001", "Main Gate Cam", "gate1"),
    ("CAM-002", "Auditorium Cam", "auditorium"),
    ("CAM-003", "Parking Cam", "park_a"),
    ("CAM-004", "Main Road Cam", "main_road"),
    ("CAM-005", "Sports Area Cam", "sports"),
    ("CAM-006", "Food Court Cam", "food_court"),
]

BUILDINGS = [
    # key, name, kind, x, y, w, h  (rects for the twin map)
    ("b_admin", "Admin Block", "building", 70, 55, 105, 80),
    ("b_library", "Central Library", "building", 200, 180, 115, 90),
    ("b_acad_a", "Academic Block A", "building", 175, 340, 125, 92),
    ("b_acad_b", "Academic Block B", "building", 340, 425, 125, 92),
    ("b_auditorium", "Main Auditorium", "building", 425, 215, 155, 100),
    ("b_foodcourt", "Food Court", "food", 635, 385, 150, 85),
    ("b_research", "Research Labs", "restricted", 850, 45, 105, 72),
    ("sports_field", "Sports Arena", "outdoor", 775, 120, 155, 115),
    ("lake_green", "Green & Lake", "outdoor", 855, 425, 105, 95),
    ("plaza_ground", "Central Plaza", "outdoor", 430, 340, 90, 80),
]

ZONE_KEYS = [z[0] for z in ZONES]
POPULABLE_ZONES = [z[0] for z in ZONES if z[2] != "restricted"]


def zone_name(key):
    for z in ZONES + GATES + PARKING + STALLS:
        if z[0] == key:
            return z[1]
    return key
