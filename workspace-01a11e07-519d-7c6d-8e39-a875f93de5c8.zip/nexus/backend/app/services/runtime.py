"""Live runtime: owns the global engine, ticks it, runs the AI layers,
persists history and broadcasts snapshots over WebSocket (demo mode)."""
import asyncio
import json
from datetime import datetime

from fastapi import WebSocket

from ..config import settings
from ..db import SessionLocal
from ..models import (CrowdRecord, VehicleRecord, TrafficRecord, StallQueueRecord,
                      EnvironmentalData, ResourceUsage, CampusMetric, Prediction, Camera)
from . import anomaly, baselines, predict, risk, alerts, reco
from .engine import Engine
from .campus import ZONES, STALLS, PARKING, GATES, ROADS, CAMERAS, zone_name

ENGINE: Engine | None = None
TRENDS: dict[str, list] = {"population": [], "risk": [], "parking": [],
                           "traffic": [], "food": []}
DIRECTOR_STATE = {"step": 0, "completed": [], "log": []}


def get_engine() -> Engine:
    global ENGINE
    if ENGINE is None:
        ENGINE = Engine(seed=42)
    return ENGINE


def reset_all(start_hour: int = 8, start_minute: int = 50):
    global ENGINE
    from .director import STEPS
    e = Engine(seed=42)
    e.sim_time = datetime.now().replace(hour=start_hour, minute=start_minute, second=0, microsecond=0)
    e.reset_state()
    # warm-start: run from 05:30 so state is consistent with time-of-day baselines
    warm = e.sim_time.replace(hour=5, minute=30)
    e.sim_time = warm
    e.state["sim_time"] = warm
    mins = (start_hour * 60 + start_minute) - (5 * 60 + 30)
    for _ in range(max(0, mins)):
        e.tick(1)
    ENGINE = e
    for k in TRENDS:
        TRENDS[k] = []
    DIRECTOR_STATE.update({"step": 0, "completed": [], "log": []})
    anomaly.ACTIVE.clear()
    alerts._last.clear()
    reco.OPEN.clear()
    alerts.NEW_ALERTS.clear()
    return e


# ------------------------------------------------------------------ snapshot
def build_snapshot() -> dict:
    e = get_engine()
    st = e.state
    anoms = anomaly.active_anomalies()
    r = risk.compute(e, anoms)
    zones = []
    for key, name, kind, cap, cx, cy in ZONES:
        z = st["zones"][key]
        d, lvl = e.zone_level(key)
        zones.append({"key": key, "name": name, "kind": kind, "crowd": z["crowd"],
                      "capacity": cap, "density": d, "level": lvl, "cx": cx, "cy": cy})
    gates = []
    for key, name, cx, cy, share in GATES:
        g = st["gates"][key]
        gates.append({"key": key, "name": name, "cx": cx, "cy": cy, "open": g["open"],
                      "in_per_min": round(g["in_per_min"]), "out_per_min": round(g["out_per_min"]),
                      "congestion": round(g["congestion"], 2),
                      "crowd": g.get("crowd", 0),
                      "level": "CRITICAL" if g["congestion"] > 1.1 else "HIGH" if g["congestion"] > 0.8
                      else "MODERATE" if g["congestion"] > 0.45 else "LIGHT"})
    parking = []
    for key, name, cat, cap, cx, cy, pref in PARKING:
        pz = st["parking"][key]
        mtf = e.predicted_parking_minutes_to_full(key)
        parking.append({"key": key, "name": name, "category": cat, "occupied": pz["occupied"],
                        "capacity": cap, "occ_pct": min(100, round(pz["occupied"] / max(1, cap) * 100)),
                        "closed": pz["closed"], "cx": cx, "cy": cy, "minutes_to_full": mtf})
    roads = []
    for key, name, path, capv in ROADS:
        rd = st["roads"][key]
        roads.append({"key": key, "name": name, "path": path, "volume": rd["volume"],
                      "congestion": round(rd["congestion"], 2),
                      "level": "HIGH" if rd["congestion"] > 0.85 else "MODERATE" if rd["congestion"] > 0.5 else "LIGHT"})
    stalls = []
    for key, name, popw, rate, servers, cx, cy in STALLS:
        s = st["stalls"][key]
        lvl = "LOW" if s["wait_min"] < 4 else "MEDIUM" if s["wait_min"] < 9 else "HIGH" if s["wait_min"] < 14 else "CRITICAL"
        qhist = predict.RECENT.get(f"queue:{key}", [])
        forecast = [predict.predict(f"queue:{key}", e.sim_time, float(s["queue"]), hz) for hz in (10, 20, 30)]
        stalls.append({"key": key, "name": name, "queue": int(s["queue"]), "crowd": s["crowd"],
                       "wait_min": s["wait_min"], "level": lvl, "trend": e.stall_trend(key),
                       "closed": s["closed"], "cx": cx, "cy": cy,
                       "forecast_wait": [round(f["predicted"] / max(2, rate * servers), 1) for f in forecast],
                       "forecast": forecast})
    # best stall now
    open_stalls = [s for s in stalls if not s["closed"]]
    best = min(open_stalls, key=lambda s: s["wait_min"]) if open_stalls else None
    worst = max(open_stalls, key=lambda s: s["wait_min"]) if open_stalls else None
    events = [{**ev, "start": ev["start"].isoformat(), "end": ev["end"].isoformat(),
               "occupancy": round(ev["current"] / max(1, st["zones"][ev["venue_key"]]["capacity"]) * 100),
               "risk": "HIGH" if ev["expected"] > st["zones"][ev["venue_key"]]["capacity"] else "MEDIUM" if ev["current"] / max(1, st["zones"][ev["venue_key"]]["capacity"]) > 0.7 else "LOW"}
              for ev in st["events"]]
    cameras = []
    db = SessionLocal()
    try:
        cam_rows = {c.cam_id: c for c in db.query(Camera).all()}
        for cam_id, c in st["cameras"].items():
            row = cam_rows.get(cam_id)
            cameras.append({"cam_id": cam_id, "name": row.name if row else cam_id,
                            "zone_key": row.zone_key if row else "", "status": c["status"],
                            "ai_status": c["ai_status"], "fps": row.fps if row else 24,
                            "last_update": row.last_update.isoformat() if row else None})
    finally:
        db.close()

    future = _future_overlay(e)
    snap = {
        "type": "snapshot",
        "sim_time": e.sim_time.isoformat(),
        "sim_clock": e.sim_time.strftime("%H:%M"),
        "population": st["population"],
        "vehicles_on_campus": st["vehicles_on_campus"],
        "weather": st["weather"],
        "resources": st["resources"],
        "restricted_intrusions": st["restricted_intrusions"],
        "zones": zones, "gates": gates, "parking": parking, "roads": roads,
        "stalls": stalls, "events": events, "cameras": cameras,
        "best_stall": {"key": best["key"], "name": best["name"], "wait_min": best["wait_min"]} if best else None,
        "worst_stall": {"key": worst["key"], "name": worst["name"], "wait_min": worst["wait_min"]} if worst else None,
        "risk": r,
        "anomalies": anoms[:6],
        "predictions": predict.top_predictions(e),
        "recommendations": sorted([o for o in reco.OPEN if o["status"] == "open"],
                                  key=lambda x: x["priority"])[:6],
        "future": future,
        "trends": {k: v[-60:] for k, v in TRENDS.items()},
        "director": DIRECTOR_STATE,
        "ai_engine": {"status": "online", "models": {"anomaly": "rolling-baseline z-score/IQR",
                                                      "forecast": predict.MODEL_NAME,
                                                      "risk": "weighted-factor engine"}},
        "demo_mode": True,
    }
    return snap


def _future_overlay(e: Engine) -> dict:
    """Predicted state at +10/+20/+30 min via headless clone (shared engine)."""
    out = {}
    clone = e.clone(seed=7)
    for hz in (10, 20, 30):
        clone.tick(hz if hz == 10 else 10)
        out[f"+{hz}"] = {
            "population": clone.state["population"],
            "zones": {k: z["crowd"] for k, z in clone.state["zones"].items()},
            "parking": {k: round(p["occupied"] / max(1, p["capacity"]) * 100)
                        for k, p in clone.state["parking"].items()},
            "stall_wait": {k: s["wait_min"] for k, s in clone.state["stalls"].items()},
        }
    return out


# ---------------------------------------------------------------- persistence
def persist(e: Engine):
    """Write time-series rows every 5 simulated minutes."""
    if e.sim_time.minute % 5 != 0:
        return
    st = e.state
    db = SessionLocal()
    try:
        for key, z in st["zones"].items():
            d = z["crowd"] / max(1, z["capacity"])
            db.add(CrowdRecord(zone_key=key, ts=e.sim_time, count=z["crowd"], density=round(d, 3)))
        for gk, g in st["gates"].items():
            db.add(VehicleRecord(gate_key=gk, ts=e.sim_time,
                                 cars_in=int(g["in_per_min"] * 0.3), cars_out=int(g["out_per_min"] * 0.3),
                                 bikes_in=int(g["in_per_min"] * 0.2), bikes_out=int(g["out_per_min"] * 0.2)))
        for rk, rd in st["roads"].items():
            db.add(TrafficRecord(road_key=rk, ts=e.sim_time, volume=int(rd["volume"]),
                                 congestion=round(rd["congestion"], 3)))
        for sk, s in st["stalls"].items():
            db.add(StallQueueRecord(stall_key=sk, ts=e.sim_time, queue=int(s["queue"]),
                                    wait_min=s["wait_min"]))
        w = st["weather"]
        db.add(EnvironmentalData(ts=e.sim_time, temp_c=round(w["temp_c"], 1), humidity=55,
                                 condition=w["condition"], rain_prob=round(w["rain_prob"], 2), aqi=w["aqi"]))
        res = st["resources"]
        db.add(ResourceUsage(ts=e.sim_time, metric="electricity", value=res["electricity_kw"], unit="kW"))
        db.add(ResourceUsage(ts=e.sim_time, metric="water", value=res["water_lpm"], unit="L/min"))
        db.add(ResourceUsage(ts=e.sim_time, metric="waste", value=res["waste_kg_h"], unit="kg/h"))
        park_occ = sum(p["occupied"] for p in st["parking"].values()) / max(
            1, sum(p["capacity"] for p in st["parking"].values()))
        db.add(CampusMetric(ts=e.sim_time, population=st["population"],
                            risk_score=risk.compute(e, anomaly.active_anomalies())["score"],
                            parking_occupancy=round(park_occ * 100, 1),
                            avg_congestion=round(sum(r["congestion"] for r in st["roads"].values()) / 5, 2),
                            food_court_load=round(st["food_court_seating_occ"] * 100, 1)))
        db.commit()
    finally:
        db.close()


# ------------------------------------------------------------------ WS hub
class Hub:
    def __init__(self):
        self.clients: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.clients.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.clients:
            self.clients.remove(ws)

    async def broadcast(self, msg: dict):
        if not self.clients:
            return
        data = json.dumps(msg)
        dead = []
        for ws in self.clients:
            try:
                await ws.send_text(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)


HUB = Hub()


# ------------------------------------------------------------------ main loop
async def live_loop():
    """The Demo Mode heartbeat."""
    from .director import auto_check
    tick_n = 0
    while True:
        e = get_engine()
        e.tick(settings.SIM_MINUTES_PER_TICK)
        tick_n += 1

        # feed predictors
        st = e.state
        predict.push("population", e.sim_time, st["population"])
        for key, z in st["zones"].items():
            predict.push(f"crowd:{key}", e.sim_time, z["crowd"])
        for key, pz in st["parking"].items():
            predict.push(f"parking:{key}", e.sim_time, pz["occupied"] / max(1, pz["capacity"]) * 100)
        for key, s in st["stalls"].items():
            predict.push(f"queue:{key}", e.sim_time, s["queue"])
        for key, rd in st["roads"].items():
            predict.push(f"traffic:{key}", e.sim_time, rd["congestion"])

        new_anoms = anomaly.check(e)
        anoms = anomaly.active_anomalies()
        r = risk.compute(e, anoms)
        new_alerts = alerts.evaluate(e, r, anoms, [])
        reco.generate_from_state(e, r, new_anoms)
        persist(e)
        auto_check(e, r, anoms)

        # trends
        park_occ = sum(p["occupied"] for p in st["parking"].values()) / max(
            1, sum(p["capacity"] for p in st["parking"].values())) * 100
        avg_cong = sum(rd["congestion"] for rd in st["roads"].values()) / max(1, len(st["roads"]))
        food_load = sum(s["queue"] for s in st["stalls"].values())
        for key, val in (("population", st["population"]), ("risk", r["score"]),
                         ("parking", round(park_occ, 1)), ("traffic", round(avg_cong, 2)),
                         ("food", food_load)):
            TRENDS[key].append({"t": e.sim_time.strftime("%H:%M"), "v": val})
            if len(TRENDS[key]) > 240:
                del TRENDS[key][:len(TRENDS[key]) - 240]

        snap = build_snapshot()
        await HUB.broadcast(snap)
        if new_alerts:
            await HUB.broadcast({"type": "alerts", "alerts": new_alerts})
            alerts.NEW_ALERTS.clear()
        if new_anoms:
            await HUB.broadcast({"type": "anomalies", "anomalies": [
                {**a, "ts": a["ts"].isoformat()} for a in new_anoms]})
        await asyncio.sleep(settings.SIM_TICK_SECONDS)
