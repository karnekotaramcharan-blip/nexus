"""What-If Simulator: clone the live engine, apply a scenario, fast-forward,
and compare against a baseline future. Same engine = consistent numbers."""
import hashlib
from datetime import datetime

from .engine import Engine
from .risk import compute as compute_risk
from .campus import ZONES, STALLS, PARKING, zone_name

HORIZON = 60  # simulated minutes

SCENARIOS = {
    "gate_closed": {"label": "Close a main gate", "params": {"gate": "gate1"}},
    "event_crowd_increase": {"label": "Event attracts more people", "params": {"multiplier": 1.8}},
    "parking_closed": {"label": "Parking zone unavailable", "params": {"zone": "park_a"}},
    "extra_vehicles": {"label": "More vehicles arriving", "params": {"multiplier": 1.3}},
    "heavy_rain": {"label": "Heavy rain", "params": {"rain_prob": 0.92}},
    "stall_closed": {"label": "Food stall shut down", "params": {"stall": "snack_corner"}},
    "food_court_closed": {"label": "Food court closed", "params": {}},
    "event_extended": {"label": "Event extended by 2 hours", "params": {"extra_min": 120}},
    "lunch_shifted": {"label": "Lunch break shifted/extended", "params": {"multiplier": 1.5}},
    "crowd_surge": {"label": "Sudden crowd surge", "params": {"total": 1200}},
    "evacuation": {"label": "Emergency evacuation", "params": {"zone": "auditorium"}},
}


def _seed_from(scenario: str, params: dict) -> int:
    s = scenario + str(sorted(params.items()))
    return int(hashlib.md5(s.encode()).hexdigest()[:7], 16) % (2 ** 31)


def run(engine: Engine, scenario: str, params: dict, horizon: int = HORIZON) -> dict:
    base = engine.clone(seed=_seed_from(scenario, params))
    sim = engine.clone(seed=_seed_from(scenario, params))

    risk_before = compute_risk(sim, [])["score"]
    msg = _apply(sim, scenario, params)

    base_series = base.run_headless(horizon)
    sim_series = sim.run_headless(horizon)
    for s in sim_series:
        pass

    risk_after = compute_risk(sim, [])["score"]
    impacts = _summarize(engine, sim, scenario, params)
    recs = _recommend(scenario, params, impacts, engine)
    evac = _evacuation_estimates(engine, params) if scenario == "evacuation" else None

    return {
        "scenario": scenario,
        "scenario_label": SCENARIOS.get(scenario, {}).get("label", scenario),
        "params": params,
        "message": msg,
        "horizon_min": horizon,
        "risk_current": round(risk_before, 1),
        "risk_simulated": round(risk_after, 1),
        "impacts": impacts,
        "recommendations": recs,
        "evacuation": evac,
        "baseline_series": base_series,
        "simulated_series": sim_series,
        "final_state": _compact_state(sim),
        "ran_at": datetime.utcnow().isoformat(),
    }


def _apply(sim: Engine, scenario: str, params: dict) -> str:
    st = sim.state
    if scenario == "gate_closed":
        gate = params.get("gate", "gate1")
        sim.inject("gate_closed", gate=gate, duration_min=10 ** 6)
        return f"{zone_name(gate)} closed; arrivals redistribute to open gates."
    if scenario == "event_crowd_increase":
        m = float(params.get("multiplier", 1.8))
        if not st["events"]:
            sim.add_event(name="TECHNOVA 2026", venue="auditorium", expected=1200, duration_min=300)
        for ev in st["events"]:
            ev["expected"] = int(ev["expected"] * m)
        sim.inject("event_crowd", multiplier=m, duration_min=10 ** 6)
        return f"Event attendance scaled ×{m}."
    if scenario == "parking_closed":
        z = params.get("zone", "park_a")
        sim.inject("parking_closed", zone=z, duration_min=10 ** 6)
        return f"{zone_name(z)} unavailable; vehicles redirected to remaining zones."
    if scenario == "extra_vehicles":
        m = float(params.get("multiplier", 1.3))
        sim.inject("vehicle_surge", multiplier=m, duration_min=10 ** 6)
        return f"Vehicle arrivals scaled ×{m}."
    if scenario == "heavy_rain":
        sim.inject("weather", condition="heavy_rain", rain_prob=float(params.get("rain_prob", 0.92)),
                   duration_min=10 ** 6)
        return "Heavy rain over campus; outdoor zones drain into covered areas."
    if scenario == "stall_closed":
        s = params.get("stall", "snack_corner")
        sim.inject("stall_closed", stall=s, duration_min=10 ** 6)
        return f"{zone_name(s)} shut down; its demand shifts to other stalls."
    if scenario == "food_court_closed":
        for k in st["stalls"]:
            sim.inject("stall_closed", stall=k, duration_min=10 ** 6)
        return "Entire food court closed; crowd disperses to gates and plaza."
    if scenario == "event_extended":
        extra = int(params.get("extra_min", 120))
        from datetime import timedelta
        for ev in st["events"]:
            ev["end"] = ev["end"] + timedelta(minutes=extra)
        if not st["events"]:
            sim.add_event(name="Extended Fest", venue="auditorium", expected=900,
                          duration_min=240 + extra)
        return f"Event extended by {extra} minutes."
    if scenario == "lunch_shifted":
        m = float(params.get("multiplier", 1.5))
        sim.inject("food_rush", multiplier=m, duration_min=90)
        return "Lunch rush amplified and shifted; food court load increases."
    if scenario == "crowd_surge":
        total = int(params.get("total", 1200))
        sim.inject("crowd_surge", total=total, ramp_min=10, duration_min=60)
        return f"Sudden influx of ~{total} people."
    if scenario == "evacuation":
        return "Emergency evacuation modeled (aggregate, anonymous)."
    return "Scenario applied."


def _compact_state(sim: Engine) -> dict:
    st = sim.state
    return {
        "zones": {k: z["crowd"] for k, z in st["zones"].items()},
        "parking": {k: {"occupied": p["occupied"], "capacity": p["capacity"], "closed": p["closed"]}
                    for k, p in st["parking"].items()},
        "gates": {k: {"congestion": round(g["congestion"], 2), "open": g["open"]}
                  for k, g in st["gates"].items()},
        "stalls": {k: {"queue": s["queue"], "wait_min": s["wait_min"], "closed": s["closed"]}
                   for k, s in st["stalls"].items()},
        "weather": st["weather"],
    }


def _summarize(engine: Engine, sim: Engine, scenario: str, params: dict) -> dict:
    st0, st1 = engine.state, sim.state
    crowd_delta = {k: st1["zones"][k]["crowd"] - st0["zones"][k]["crowd"] for k in st0["zones"]}
    top = sorted(crowd_delta.items(), key=lambda kv: -abs(kv[1]))[:3]
    parking = {k: {"now_occ_pct": round(st0["parking"][k]["occupied"] / max(1, st0["parking"][k]["capacity"]) * 100),
                   "sim_occ_pct": round(st1["parking"][k]["occupied"] / max(1, st1["parking"][k]["capacity"]) * 100),
                   "closed": st1["parking"][k]["closed"]} for k in st0["parking"]}
    gates = {k: {"now": round(st0["gates"][k]["congestion"], 2),
                 "sim": round(st1["gates"][k]["congestion"], 2),
                 "open": st1["gates"][k]["open"]} for k in st0["gates"]}
    stalls = {k: {"now_wait": st0["stalls"][k]["wait_min"],
                  "sim_wait": st1["stalls"][k]["wait_min"],
                  "closed": st1["stalls"][k]["closed"]} for k in st0["stalls"]}
    food_now = sum(s["queue"] for s in st0["stalls"].values())
    food_sim = sum(s["queue"] for s in st1["stalls"].values())
    return {
        "population": {"now": st0["population"], "simulated": st1["population"]},
        "top_crowd_shifts": [{"zone": k, "name": zone_name(k), "delta": d} for k, d in top],
        "parking": parking, "gates": gates, "stalls": stalls,
        "food_court_total_queue": {"now": food_now, "simulated": food_sim},
        "weather": {"now": st0["weather"]["condition"], "simulated": st1["weather"]["condition"]},
    }


def _recommend(scenario: str, params: dict, impacts: dict, engine: Engine) -> list[dict]:
    recs = []
    gates = impacts["gates"]
    open_sorted = sorted(((k, g) for k, g in gates.items() if g["open"]), key=lambda kv: kv[1]["sim"])
    if scenario == "gate_closed":
        if open_sorted:
            g1 = open_sorted[0]
            recs.append({"title": f"Redirect ~35% of incoming traffic to {zone_name(g1[0])}",
                         "why": f"It has the lowest simulated congestion ({g1[1]['sim']:.2f}) after closure.",
                         "risk_reduction": 14})
        if len(open_sorted) > 1:
            g2 = open_sorted[1]
            recs.append({"title": f"Open an extra lane at {zone_name(g2[0])}",
                         "why": f"Congestion there rises to {g2[1]['sim']:.2f}; extra throughput absorbs the diverted flow.",
                         "risk_reduction": 9})
    if scenario in ("event_crowd_increase", "crowd_surge"):
        recs.append({"title": "Pre-position crowd marshals and open secondary exits at the venue",
                     "why": "Simulated venue occupancy crosses safe egress thresholds.",
                     "risk_reduction": 12})
        recs.append({"title": "Stage 2 extra security teams near Food Street",
                     "why": "Post-event dispersal concentrates there in the simulation.",
                     "risk_reduction": 6})
    if scenario == "parking_closed":
        free = sorted(((k, p) for k, p in impacts["parking"].items() if not p["closed"]),
                      key=lambda kv: kv[1]["sim_occ_pct"])
        if free:
            recs.append({"title": f"Signpost all incoming vehicles to {zone_name(free[0][0])}",
                         "why": f"It retains the most simulated headroom ({100-free[0][1]['sim_occ_pct']:.0f}% free).",
                         "risk_reduction": 11})
    if scenario == "extra_vehicles":
        recs.append({"title": "Activate overflow parking (Zone D) and run a shuttle loop",
                     "why": "Simulated demand exceeds regular capacity within the horizon.",
                     "risk_reduction": 10})
    if scenario == "heavy_rain":
        recs.append({"title": "Move outdoor event segments indoors / under cover and pre-position umbrellas at gates",
                     "why": "Rain pushes crowds to covered areas; shelter rush raises density there.",
                     "risk_reduction": 8})
    if scenario in ("stall_closed", "food_court_closed", "lunch_shifted"):
        open_stalls = sorted(((k, s) for k, s in impacts["stalls"].items() if not s["closed"]),
                             key=lambda kv: kv[1]["sim_wait"])
        if open_stalls:
            recs.append({"title": f"Redirect guests to {zone_name(open_stalls[0][0])} and add staff there",
                         "why": f"It shows the lowest simulated wait ({open_stalls[0][1]['sim_wait']:.0f} min).",
                         "risk_reduction": 7})
    if scenario == "evacuation":
        recs.append({"title": "Open all gates and hold incoming traffic",
                     "why": "Evacuation flow must be unidirectional outward.", "risk_reduction": 18})
    recs.append({"title": "Keep monitoring the live risk score after applying this strategy",
                 "why": "NEXUS re-scores continuously; verify the simulated reduction materialises.",
                 "risk_reduction": 2})
    recs.sort(key=lambda r: -r["risk_reduction"])
    return recs


def _evacuation_estimates(engine: Engine, params: dict) -> dict:
    """Aggregate, anonymous evacuation model (P2)."""
    zone = params.get("zone", "auditorium")
    z = engine.state["zones"].get(zone)
    pop = z["crowd"] if z else 500
    gates = [g for g in engine.state["gates"].values() if g["open"]]
    n_gates = max(1, len(gates))
    flow_per_min = 180 * n_gates
    t = pop / flow_per_min
    bottlenecks = sorted(engine.state["roads"].items(), key=lambda kv: -kv[1]["congestion"])[:2]
    return {
        "zone": zone, "population": pop, "open_gates": n_gates,
        "est_evac_minutes": round(t + 2, 1),
        "bottlenecks": [b[0] for b in bottlenecks],
        "assembly": ["Sports Arena (north-east)", "Main Ground (west of Gate 1)"],
        "note": "Aggregate flow model only — no individual tracking.",
    }
