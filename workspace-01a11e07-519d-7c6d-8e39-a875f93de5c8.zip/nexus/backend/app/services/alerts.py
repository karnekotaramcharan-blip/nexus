"""Smart alert system: threshold + AI-prediction driven, with cooldown dedupe."""
from datetime import datetime, timedelta

from ..db import SessionLocal
from ..models import Alert
from .campus import zone_name

COOLDOWN_MIN = 12
_last: dict[str, datetime] = {}
NEW_ALERTS: list[dict] = []  # pushed to WS by runtime


def _cooled(key: str, now: datetime) -> bool:
    if key in _last and (now - _last[key]) < timedelta(minutes=COOLDOWN_MIN):
        return True
    _last[key] = now
    return False


def raise_alert(kind: str, severity: str, location: str, reason: str,
                prediction: str, action: str, now: datetime) -> dict | None:
    key = f"{kind}:{location}"
    if _cooled(key, now):
        return None
    db = SessionLocal()
    try:
        a = Alert(kind=kind, severity=severity, location=location, reason=reason,
                  prediction=prediction, action=action, ts=now)
        db.add(a)
        db.commit()
        db.refresh(a)
        d = {"id": a.id, "kind": kind, "severity": severity, "location": location,
             "reason": reason, "prediction": prediction, "action": action,
             "status": "new", "ts": now.isoformat()}
        NEW_ALERTS.append(d)
        return d
    finally:
        db.close()


def evaluate(engine, risk: dict, anomalies: list[dict], predictions: list[dict]) -> list[dict]:
    """Run all alert rules against current engine state."""
    st = engine.state
    now = engine.sim_time
    raised = []

    # crowd density
    for key, z in st["zones"].items():
        d = z["crowd"] / max(1, z["capacity"])
        if d >= 0.99:
            r = raise_alert("high_crowd_density", "critical", zone_name(key),
                            f"Density at {d*100:.0f}% of safe capacity ({z['crowd']}/{z['capacity']}).",
                            "Continued growth risks crush conditions within 10 minutes.",
                            "Meter entries, open all exits, deploy marshals.", now)
            if r: raised.append(r)
        elif d >= 0.92:
            r = raise_alert("high_crowd_density", "warning", zone_name(key),
                            f"Density reached {d*100:.0f}% of capacity.",
                            "May cross critical threshold if inflow continues.",
                            "Divert new arrivals to adjacent open areas.", now)
            if r: raised.append(r)

    # parking capacity predicted
    for key, pz in st["parking"].items():
        mtf = engine.predicted_parking_minutes_to_full(key)
        if pz["closed"]:
            continue
        occ_ratio = pz["occupied"] / max(1, pz["capacity"])
        if mtf is not None and mtf <= 18 and occ_ratio >= 0.55:
            r = raise_alert("parking_capacity_predicted", "warning", zone_name(key),
                            f"{pz['occupied']}/{pz['capacity']} occupied; fill rate accelerating.",
                            f"Projected to reach 100% within ~{mtf} minutes.",
                            "Redirect incoming vehicles to overflow zone and update signboards.", now)
            if r: raised.append(r)

    # traffic congestion predicted
    for key, rd in st["roads"].items():
        if rd["congestion"] >= 1.0:
            r = raise_alert("traffic_congestion_predicted", "warning", key.replace("_", " ").title(),
                            f"Volume {rd['volume']:.0f}/min exceeds road capacity.",
                            "Queue spillback to gates likely within 10 minutes.",
                            "Activate alternate route; meter gate release.", now)
            if r: raised.append(r)

    # food stall overcrowding
    for key, s in st["stalls"].items():
        if s["closed"]:
            continue
        if s["wait_min"] >= 14:
            r = raise_alert("food_stall_overcrowding", "warning", zone_name(key),
                            f"Queue {s['queue']} people, wait ~{s['wait_min']:.0f} min (3× normal for this hour).",
                            "Wait time keeps rising while arrival rate stays elevated.",
                            f"Redirect guests to the quietest stall; add one server at {zone_name(key)}.", now)
            if r: raised.append(r)

    # food court density critical
    fc = st["zones"]["food_court"]
    if fc["crowd"] / max(1, fc["capacity"]) >= 0.9:
        r = raise_alert("food_court_critical", "critical", "Food Court",
                        f"Food court density {fc['crowd']}/{fc['capacity']}.",
                        "Seating saturation; spill into walkways expected.",
                        "Open extra seating, pause new entries for 5 minutes.", now)
        if r: raised.append(r)

    # restricted zone
    if st["restricted_intrusions"] > 0 and st["restricted_intrusions"] % 2 == 1:
        r = raise_alert("restricted_zone_activity", "warning", "Research Labs (Restricted)",
                        f"{st['restricted_intrusions']} intrusion(s) detected via CAM-005 perimeter analytics.",
                        "Pattern suggests repeated attempts near the east fence.",
                        "Dispatch security for a sweep; verify badge logs.", now)
        if r: raised.append(r)

    # event overcrowding risk
    for ev in st["events"]:
        cap = st["zones"][ev["venue_key"]]["capacity"]
        if ev["expected"] > cap:
            r = raise_alert("event_overcrowding_risk", "warning", f"{ev['name']} — {ev['venue_key']}",
                            f"Expected attendance {ev['expected']} exceeds venue capacity {cap}.",
                            f"Predicted peak {ev['peak_predicted']} unless inflow is managed.",
                            "Enable entry metering; overflow to plaza with big-screen relay.", now)
            if r: raised.append(r)

    # cameras offline
    for cam_id, c in st["cameras"].items():
        if c["status"] == "offline":
            r = raise_alert("camera_offline", "warning", cam_id,
                            f"{cam_id} stopped reporting frames.",
                            "Coverage gap in its zone until restored.",
                            "Restart the camera or dispatch a technician.", now)
            if r: raised.append(r)

    # environmental risk
    w = st["weather"]
    if w["rain_prob"] >= 0.75 and any(st["events"]):
        r = raise_alert("environmental_risk", "warning", "Campus-wide",
                        f"Heavy rain probability {w['rain_prob']*100:.0f}% during live event(s).",
                        "Shelter rush will load food court and covered walkways.",
                        "Consider moving outdoor segments indoors.", now)
        if r: raised.append(r)

    # resource anomaly
    for a in anomalies:
        if a["target"].startswith("resource:") and a["z"] > 3:
            r = raise_alert("unusual_resource_consumption", "warning",
                            a["target"].split(":")[1].title(), a["reason"],
                            "Consumption likely to stay elevated while the cause persists.",
                            "Check for a scheduled large event or equipment fault.", now)
            if r: raised.append(r)

    # unusual campus activity (composite)
    if risk["score"] >= 75:
        r = raise_alert("unusual_campus_activity", "critical", "Campus-wide",
                        f"Composite risk reached {risk['score']:.0f}/100: "
                        + "; ".join(f["label"] for f in risk["factors"][:3]),
                        "Multiple systems simultaneously outside normal envelopes.",
                        "Activate the incident checklist; run a What-If on the leading cause.", now)
        if r: raised.append(r)

    return raised
