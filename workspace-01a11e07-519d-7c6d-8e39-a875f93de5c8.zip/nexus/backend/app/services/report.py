"""'Explain My Campus' — end-of-day AI intelligence report with template fallback."""
from datetime import datetime

from sqlalchemy import func

from ..config import settings
from ..db import SessionLocal
from ..models import CrowdRecord, Anomaly, Alert, CampusMetric, StallQueueRecord, Event
from .campus import zone_name

REPORTS: list[dict] = []


def _llm_available() -> bool:
    return bool(settings.LLM_API_KEY)


async def _llm_polish(text: str) -> str | None:
    if not _llm_available():
        return None
    import httpx
    try:
        async with httpx.AsyncClient(timeout=40) as client:
            r = await client.post(
                f"{settings.LLM_BASE_URL.rstrip('/')}/chat/completions",
                headers={"Authorization": f"Bearer {settings.LLM_API_KEY}"},
                json={"model": settings.LLM_MODEL,
                      "messages": [
                          {"role": "system", "content": "You are NEXUS, a campus intelligence AI. "
                           "Rewrite the given campus operations summary into a crisp executive narrative. "
                           "Never invent numbers; use only the facts provided."},
                          {"role": "user", "content": text}],
                      "temperature": 0.4, "max_tokens": 700})
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
    except Exception:
        return None


def generate(engine, author: str = "") -> dict:
    """Aggregate live + historical data into the daily report."""
    e = engine
    st = e.state
    day = e.sim_time.date()
    db = SessionLocal()
    try:
        pop_peak = db.query(func.max(CampusMetric.population)).filter(
            func.date(CampusMetric.ts) == day.isoformat()).scalar() or st["population"]
        risk_peak = db.query(func.max(CampusMetric.risk_score)).filter(
            func.date(CampusMetric.ts) == day.isoformat()).scalar() or 0
        park_peak = db.query(func.max(CampusMetric.parking_occupancy)).filter(
            func.date(CampusMetric.ts) == day.isoformat()).scalar() or 0

        busiest = max(st["zones"].items(), key=lambda kv: kv[1]["crowd"])
        busiest_stall = max(st["stalls"].items(), key=lambda kv: kv[1]["queue"])
        n_anoms = db.query(Anomaly).filter(func.date(Anomaly.ts) == day.isoformat()).count()
        crit_anoms = db.query(Anomaly).filter(func.date(Anomaly.ts) == day.isoformat(),
                                              Anomaly.severity == "critical").count()
        n_alerts = db.query(Alert).filter(func.date(Alert.ts) == day.isoformat()).count()
        events_today = db.query(Event).filter(func.date(Event.start_ts) == day.isoformat()).all()
        res_anoms = [a for a in db.query(Anomaly).filter(
            func.date(Anomaly.ts) == day.isoformat(),
            Anomaly.target.like("resource:%")).all()]
    finally:
        db.close()

    # park peak vs historical average (approx)
    park_hist_avg = 61.0
    park_delta = int(((park_peak or 0) - park_hist_avg) / max(1, park_hist_avg) * 100)

    w = st["weather"]
    facts = {
        "date": day.isoformat(),
        "generated_at": e.sim_time.strftime("%H:%M"),
        "population_now": st["population"],
        "population_peak": int(pop_peak),
        "busiest_zone": busiest[1]["name"],
        "busiest_zone_crowd": busiest[1]["crowd"],
        "park_peak": round(park_peak or 0),
        "park_delta": park_delta,
        "busiest_stall": busiest_stall[1] and zone_name(busiest_stall[0]),
        "busiest_stall_queue": busiest_stall[1]["queue"],
        "n_anomalies": n_anoms,
        "n_critical_anomalies": crit_anoms,
        "n_alerts": n_alerts,
        "events": [{"name": ev.name, "venue": ev.venue_key, "expected": ev.expected_attendance}
                   for ev in events_today] + ([{"name": x["name"], "venue": x["venue_key"],
                                                 "expected": x["expected"]} for x in st["events"]]),
        "weather": f"{w['condition']} ({w['temp_c']:.0f}°C, rain {int(w['rain_prob']*100)}%)",
        "resource_anomalies": [a.metric for a in res_anoms],
        "risk_peak": round(risk_peak or 0),
    }

    ev_txt = "; ".join(f"{x['name']} at {x['venue']} (expected {x['expected']})"
                       for x in facts["events"][:4]) or "No major events"
    summary = (
        f"Campus activity remained normal in the morning with a peak on-campus population of "
        f"{facts['population_peak']:,}. The busiest location was {facts['busiest_zone']} "
        f"({facts['busiest_zone_crowd']} people at report time). Parking demand peaked at "
        f"{facts['park_peak']}% occupancy — {facts['park_delta']:+d}% vs the historical average for this date. "
        f"The food court's busiest stall was {facts['busiest_stall']} with a peak queue of "
        f"{facts['busiest_stall_queue']} people. Major events: {ev_txt}. "
        f"{facts['n_anomalies']} anomalies were detected ({facts['n_critical_anomalies']} critical), "
        f"generating {facts['n_alerts']} operational alerts. Weather: {facts['weather']}. "
        + (f"Resource anomalies observed in: {', '.join(facts['resource_anomalies'])}. "
           if facts["resource_anomalies"] else "No abnormal resource consumption was detected. ")
        + ("No critical safety anomaly was detected." if facts["n_critical_anomalies"] == 0
           else f"Peak campus risk reached {facts['risk_peak']}/100 — review the flagged anomalies.")
    )

    sections = [
        {"title": "1. Headline", "body": summary},
        {"title": "2. Crowd & Mobility",
         "body": f"Peak population {facts['population_peak']:,}; busiest zone {facts['busiest_zone']}. "
                 f"Gate flows, road congestion and movement patterns were within planned corridors "
                 f"except where flagged by anomalies."},
        {"title": "3. Parking",
         "body": f"Peak occupancy {facts['park_peak']}% ({facts['park_delta']:+d}% vs historical). "
                 f"Minutes-to-full forecasting allowed proactive redirection recommendations."},
        {"title": "4. Food Court & Stalls",
         "body": f"Busiest stall: {facts['busiest_stall']} (queue {facts['busiest_stall_queue']}). "
                 f"Load-balancing redirects kept average waits manageable; rush-hour forecast matched "
                 f"the lunch peak from historical class-break patterns."},
        {"title": "5. Anomalies & Alerts",
         "body": f"{facts['n_anomalies']} anomalies and {facts['n_alerts']} alerts today. Every anomaly "
                 f"includes observed-vs-expected ranges and confidence; see the Analytics page for the "
                 f"full audit trail."},
        {"title": "6. Events",
         "body": ev_txt + ". Event impact on parking, traffic and food stalls was modelled in real time."},
        {"title": "7. Environment & Resources",
         "body": f"Weather: {facts['weather']}. " +
                 ("Abnormal consumption flagged in " + ", ".join(facts["resource_anomalies"]) + "."
                  if facts["resource_anomalies"] else "Electricity, water and waste stayed within baselines.")},
        {"title": "8. Tomorrow Outlook",
         "body": "Based on the calendar and learned baselines: expect similar arrival curves; keep "
                 "overflow parking ready if an event is scheduled, and pre-staff the two busiest stalls "
                 "for the 12:45–13:30 lunch peak."},
    ]

    rep = {
        "id": len(REPORTS) + 1,
        "date": facts["date"],
        "generated_at": datetime.utcnow().isoformat(),
        "author": author,
        "facts": facts,
        "summary": summary,
        "sections": sections,
        "llm_used": _llm_available(),
    }
    REPORTS.append(rep)
    return rep


async def generate_async(engine, author: str = "") -> dict:
    rep = generate(engine, author)
    polished = await _llm_polish(rep["summary"])
    if polished:
        rep["summary"] = polished
        rep["llm_used"] = True
    return rep


def list_reports() -> list[dict]:
    return list(reversed(REPORTS))
