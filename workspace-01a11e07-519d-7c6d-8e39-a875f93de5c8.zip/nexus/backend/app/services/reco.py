"""AI recommendation engine with feedback loop (accept/dismiss + before/after tracking)."""
from ..db import SessionLocal
from ..models import Recommendation

OPEN: list[dict] = []


def propose(title: str, detail: str, source: str, priority: int, reduction: float) -> dict | None:
    for o in OPEN:
        if o["title"] == title and o["status"] == "open":
            return None
    db = SessionLocal()
    try:
        r = Recommendation(title=title, detail=detail, source=source,
                           priority=priority, expected_risk_reduction=reduction)
        db.add(r)
        db.commit()
        db.refresh(r)
        d = {"id": r.id, "title": title, "detail": detail, "source": source,
             "priority": priority, "expected_risk_reduction": reduction,
             "status": "open", "ts": r.ts.isoformat()}
        OPEN.append(d)
        return d
    finally:
        db.close()


def generate_from_state(engine, risk: dict, anomalies: list[dict]) -> list[dict]:
    out = []
    st = engine.state
    # parking
    for key, pz in st["parking"].items():
        mtf = engine.predicted_parking_minutes_to_full(key)
        if mtf is not None and mtf <= 20 and not pz["closed"] and pz["occupied"] / max(1, pz["capacity"]) >= 0.55:
            r = propose(f"Redirect incoming vehicles toward overflow Parking Zone D",
                        f"{key.replace('park_', 'Zone ').upper()} projected full in ~{mtf} min. "
                        f"Diverting now keeps {100 - int(pz['occupied']/pz['capacity']*100)}% headroom usable.",
                        "parking-predictor", 1, 9.0)
            if r: out.append(r)
    # crowd
    for key, z in st["zones"].items():
        d = z["crowd"] / max(1, z["capacity"])
        if d >= 0.78:
            r = propose(f"Meter entries and open secondary exits at {z['name']}",
                        f"Density {d*100:.0f}%. Holding inflow at 60% restores safe density in ~8 minutes.",
                        "crowd-predictor", 1, 12.0)
            if r: out.append(r)
    # stalls
    waits = [(k, s) for k, s in st["stalls"].items() if not s["closed"]]
    if waits:
        worst = max(waits, key=lambda kv: kv[1]["wait_min"])
        best = min(waits, key=lambda kv: kv[1]["wait_min"])
        if worst[1]["wait_min"] >= 10:
            from .campus import zone_name
            r = propose(f"Redirect stall guests: {zone_name(worst[0])} → {zone_name(best[0])}",
                        f"{zone_name(worst[0])} wait ~{worst[1]['wait_min']:.0f} min vs "
                        f"{zone_name(best[0])} ~{best[1]['wait_min']:.0f} min. "
                        f"Announcement + signage shifts ~30% of new arrivals.",
                        "food-court-optimizer", 2, 6.0)
            if r: out.append(r)
    # weather + event
    if st["weather"]["rain_prob"] > 0.7 and any(st["events"]):
        r = propose("Move outdoor event segments under cover",
                    "Rain probability above 70% during a live event; covered areas will absorb shelter rush.",
                    "weather-advisor", 2, 8.0)
        if r: out.append(r)
    # anomalies
    for a in anomalies[:2]:
        r = propose(f"Investigate anomaly: {a['metric']}",
                    a["reason"], "anomaly-detector", 2, 4.0)
        if r: out.append(r)
    return out
