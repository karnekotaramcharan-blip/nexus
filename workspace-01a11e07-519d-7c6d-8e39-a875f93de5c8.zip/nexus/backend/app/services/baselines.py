"""Learn normal patterns per metric per hour-of-day / day-type from seeded history.

Explainable approach: rolling baseline mean ± spread per (metric, hour, weekday/weekend).
Anomaly detection = robust z-score / IQR-style range check against these baselines.
"""
import math
from collections import defaultdict
from datetime import datetime

from sqlalchemy import func

from ..db import SessionLocal
from ..models import CrowdRecord, StallQueueRecord, TrafficRecord, ResourceUsage

BASELINES: dict[str, dict] = {}


def _bucket_key(hour: int, weekday: bool) -> str:
    return f"{hour}:{'wd' if weekday else 'we'}"


def build_baselines():
    """Aggregate history into mean/std per (target, hour, day-type)."""
    global BASELINES
    db = SessionLocal()
    agg: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    try:
        rows = db.query(CrowdRecord.zone_key,
                        func.strftime('%H', CrowdRecord.ts).label("hh"),
                        func.strftime('%w', CrowdRecord.ts).label("dw"),
                        func.avg(CrowdRecord.count), func.avg(CrowdRecord.count * CrowdRecord.count)
                        ).group_by(CrowdRecord.zone_key, "hh", "dw").all()
        for zk, hh, dw, mean, mean2 in rows:
            var = max(0.0, (mean2 or 0) - (mean or 0) ** 2)
            std = math.sqrt(var)
            wk = _bucket_key(int(hh), int(dw) not in (0, 6))
            agg[f"crowd:{zk}"][wk] = [mean or 0, max(4.0, std)]

        rows = db.query(StallQueueRecord.stall_key,
                        func.strftime('%H', StallQueueRecord.ts).label("hh"),
                        func.strftime('%w', StallQueueRecord.ts).label("dw"),
                        func.avg(StallQueueRecord.queue), func.avg(StallQueueRecord.queue * StallQueueRecord.queue)
                        ).group_by(StallQueueRecord.stall_key, "hh", "dw").all()
        for sk, hh, dw, mean, mean2 in rows:
            var = max(0.0, (mean2 or 0) - (mean or 0) ** 2)
            wk = _bucket_key(int(hh), int(dw) not in (0, 6))
            agg[f"queue:{sk}"][wk] = [mean or 0, max(1.5, math.sqrt(var))]

        rows = db.query(ResourceUsage.metric,
                        func.strftime('%H', ResourceUsage.ts).label("hh"),
                        func.strftime('%w', ResourceUsage.ts).label("dw"),
                        func.avg(ResourceUsage.value), func.avg(ResourceUsage.value * ResourceUsage.value)
                        ).group_by(ResourceUsage.metric, "hh", "dw").all()
        for mk, hh, dw, mean, mean2 in rows:
            var = max(0.0, (mean2 or 0) - (mean or 0) ** 2)
            wk = _bucket_key(int(hh), int(dw) not in (0, 6))
            agg[f"resource:{mk}"][wk] = [mean or 0, max(2.0, math.sqrt(var))]
    finally:
        db.close()
    BASELINES = agg
    return len(agg)


def baseline_for(target: str, dt: datetime) -> tuple[float, float] | None:
    """Return (mean, std) for target at dt, or None."""
    buckets = BASELINES.get(target)
    if not buckets:
        return None
    wk = _bucket_key(dt.hour, dt.weekday() < 5)
    b = buckets.get(wk) or buckets.get(_bucket_key(dt.hour, not (dt.weekday() < 5)))
    return tuple(b) if b else None


def expected_range(target: str, dt: datetime, k: float = 1.6) -> tuple[float, float] | None:
    """IQR-style expected range ≈ mean ± 1.6σ (covers ~89% of normal)."""
    b = baseline_for(target, dt)
    if not b:
        return None
    mean, std = b
    return (max(0.0, mean - k * std), mean + k * std)


def zscore(target: str, dt: datetime, observed: float) -> float | None:
    b = baseline_for(target, dt)
    if not b:
        return None
    mean, std = b
    if std <= 0:
        return 0.0
    return (observed - mean) / std
