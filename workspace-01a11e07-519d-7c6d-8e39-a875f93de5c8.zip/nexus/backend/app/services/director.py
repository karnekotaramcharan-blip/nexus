"""DEMO DIRECTOR: one-click walkthrough of the 20-step hackathon demo sequence."""
from datetime import datetime

from .campus import zone_name
from .runtime import get_engine, DIRECTOR_STATE, build_snapshot

STEPS = [
    {"id": 1, "title": "Admin logs in", "page": "/login",
     "hint": "Log in with the demo Super Admin account.", "auto": False},
    {"id": 2, "title": "Live digital twin dashboard", "page": "/",
     "hint": "The dashboard streams the live digital twin over WebSocket.", "auto": True},
    {"id": 3, "title": "Normal campus conditions", "page": "/",
     "hint": "Everything green: low crowd, healthy parking, short stall queues.", "auto": True},
    {"id": 4, "title": "Start event simulation (TECHNOVA 2026)", "page": "/",
     "hint": "Inject a live tech fest into the Auditorium.", "auto": True},
    {"id": 5, "title": "Crowd begins increasing", "page": "/",
     "hint": "Watch the auditorium and plaza densities climb.", "auto": True},
    {"id": 6, "title": "AI detects abnormal crowd growth", "page": "/",
     "hint": "An anomaly fires against the hour-of-day baseline.", "auto": True},
    {"id": 7, "title": "NEXUS predicts overcrowding", "page": "/predictions",
     "hint": "Prediction cards show projected venue overcrowding with confidence bands.", "auto": True},
    {"id": 8, "title": "Parking demand rises", "page": "/",
     "hint": "Event traffic pushes parking occupancy up.", "auto": True},
    {"id": 9, "title": "AI predicts parking capacity reached", "page": "/predictions",
     "hint": "Minutes-to-full prediction triggers a parking alert.", "auto": True},
    {"id": 10, "title": "Traffic + food stall rush", "page": "/stalls",
     "hint": "Roads congest; stall queues spike; queue warning alert fires.", "auto": True},
    {"id": 11, "title": "Risk score with explanations", "page": "/",
     "hint": "Risk gauge climbs; factor breakdown explains every point.", "auto": True},
    {"id": 12, "title": "AI recommends actions", "page": "/",
     "hint": "Ranked recommendations incl. stall-crowd redirection.", "auto": True},
    {"id": 13, "title": "Open the What-If Simulator", "page": "/whatif",
     "hint": "Navigate to the What-If simulator.", "auto": True},
    {"id": 14, "title": "Ask: 'What if the main gate is closed?'", "page": "/whatif",
     "hint": "Type it in natural language or use the Gate Closure scenario.", "auto": True},
    {"id": 15, "title": "Run simulation", "page": "/whatif",
     "hint": "Run the gate-closure simulation for 60 simulated minutes.", "auto": True},
    {"id": 16, "title": "Traffic, crowd, parking & stall impact", "page": "/whatif",
     "hint": "Impact summary + CURRENT vs SIMULATED charts.", "auto": True},
    {"id": 17, "title": "AI recommends an alternative strategy", "page": "/whatif",
     "hint": "Run the recommended mitigation and compare strategies.", "auto": True},
    {"id": 18, "title": "REAL CAMPUS vs SIMULATED FUTURE", "page": "/whatif",
     "hint": "Side-by-side comparison view.", "auto": True},
    {"id": 19, "title": "Open 'Explain My Campus'", "page": "/report",
     "hint": "Navigate to the daily intelligence report.", "auto": True},
    {"id": 20, "title": "Generate the full AI report", "page": "/report",
     "hint": "One click generates and exports the end-of-day report.", "auto": True},
]


def _log(msg: str):
    DIRECTOR_STATE["log"].append({"t": datetime.utcnow().isoformat(), "msg": msg})
    DIRECTOR_STATE["log"] = DIRECTOR_STATE["log"][-80:]


def _complete(step_id: int, msg: str):
    if step_id not in DIRECTOR_STATE["completed"]:
        DIRECTOR_STATE["completed"].append(step_id)
        _log(msg)
    DIRECTOR_STATE["step"] = max(DIRECTOR_STATE["step"], step_id)


def run_step(step_id: int) -> dict:
    """Execute a director step: applies engine injections / gathers evidence."""
    e = get_engine()
    step = next((s for s in STEPS if s["id"] == step_id), None)
    if not step:
        return {"error": "unknown step"}
    payload = {"step": step, "evidence": {}}

    if step_id == 1:
        _complete(1, "Admin authenticated.")
    elif step_id == 2:
        _complete(2, "Live digital twin streaming via WebSocket.")
    elif step_id == 3:
        from .runtime import reset_all
        reset_all(start_hour=e.sim_time.hour, start_minute=e.sim_time.minute)
        e2 = get_engine()
        e2.tick(2)
        _complete(1, "Admin authenticated.")
        _complete(2, "Live digital twin streaming via WebSocket.")
        _complete(3, "Campus reset to calm baseline conditions.")
        payload["evidence"] = {"population": e2.state["population"]}
    elif step_id == 4:
        ev = e.inject("event", name="TECHNOVA 2026", venue="auditorium",
                      expected=1200, duration_min=300, expires_long=True)
        _complete(4, "TECHNOVA 2026 started at the Auditorium (expected 1,200).")
        payload["evidence"] = {"event": ev}
    elif step_id == 5:
        e.inject("crowd_surge", total=950, ramp_min=10, duration_min=45)
        e.tick(6)
        _complete(5, "Crowd surge injected; auditorium & plaza filling.")
        payload["evidence"] = {"auditorium": e.state["zones"]["auditorium"]["crowd"],
                               "population": e.state["population"]}
    elif step_id == 6:
        e.inject("crowd_surge", total=500, ramp_min=4, duration_min=25)
        e.tick(6)
        from . import anomaly as anom_svc
        raised = anom_svc.check(e)
        _complete(6, f"Anomaly detection ran; {len(anom_svc.active_anomalies())} active anomalies.")
        payload["evidence"] = {"active_anomalies": [a["metric"] for a in anom_svc.active_anomalies()]}
    elif step_id == 7:
        e.tick(4)
        snap = build_snapshot()
        _complete(7, "Overcrowding prediction generated with confidence bands.")
        payload["evidence"] = {"predictions": [p["label"] + ": " + p["predicted"] for p in snap["predictions"]]}
    elif step_id == 8:
        e.inject("vehicle_surge", multiplier=1.45, duration_min=60)
        e.tick(8)
        _complete(8, "Vehicle surge injected; parking occupancy climbing.")
        payload["evidence"] = {k: p["occupied"] for k, p in e.state["parking"].items()}
    elif step_id == 9:
        e.inject("parking_shortage", duration_min=40)
        e.tick(8)
        mtfs = {k: e.predicted_parking_minutes_to_full(k) for k in e.state["parking"]}
        _complete(9, "Parking capacity prediction: " + str(mtfs))
        payload["evidence"] = mtfs
    elif step_id == 10:
        e.inject("food_rush", multiplier=1.7, duration_min=40)
        e.tick(6)
        waits = {k: round(s["wait_min"], 1) for k, s in e.state["stalls"].items()}
        _complete(10, "Food court rush + traffic load injected.")
        payload["evidence"] = {"stall_waits": waits}
    elif step_id == 11:
        from . import risk as risk_svc, anomaly as anom_svc
        r = risk_svc.compute(e, anom_svc.active_anomalies())
        _complete(11, f"Risk score {r['score']}/100 ({r['level']}).")
        payload["evidence"] = r
    elif step_id == 12:
        from . import reco as reco_svc, risk as risk_svc, anomaly as anom_svc
        r = risk_svc.compute(e, anom_svc.active_anomalies())
        recs = reco_svc.generate_from_state(e, r, anom_svc.active_anomalies())
        _complete(12, f"{len(reco_svc.OPEN)} open recommendations.")
        payload["evidence"] = {"recommendations": [x["title"] for x in reco_svc.OPEN][:6]}
    elif step_id in (13, 14):
        _complete(step_id, step["title"])
        payload["evidence"] = {"navigate": step["page"],
                               "nl_query": "What happens if the main gate is closed?"}
    elif step_id in (15, 16):
        from . import scenarios
        result = scenarios.run(e, "gate_closed", {"gate": "gate1"})
        _complete(step_id, f"Simulation complete. Risk now→sim: "
                           f"{result['risk_current']}→{result['risk_simulated']}.")
        payload["evidence"] = {"simulation": {
            "risk_current": result["risk_current"], "risk_simulated": result["risk_simulated"],
            "impacts": result["impacts"], "message": result["message"]}}
    elif step_id in (17, 18):
        from . import scenarios
        alt = scenarios.run(e, "gate_closed", {"gate": "gate2"})
        _complete(step_id, "Alternative strategy simulated for comparison.")
        payload["evidence"] = {"alt_simulation": {
            "scenario": "Close Gate 2 instead",
            "risk_simulated": alt["risk_simulated"],
            "recommendations": alt["recommendations"][:2]}}
    elif step_id == 19:
        _complete(19, "Explain My Campus opened.")
        payload["evidence"] = {"navigate": "/report"}
    elif step_id == 20:
        from . import report as report_svc
        rep = report_svc.generate(get_engine(), author="Demo Director")
        _complete(20, "Full AI campus intelligence report generated.")
        payload["evidence"] = {"report_id": rep["id"], "summary": rep["summary"][:240]}

    return payload


def auto_check(e, risk_data, anomalies):
    """Auto-complete evidence-based steps as the live sim organically hits them."""
    st = e.state
    if any(ev["current"] > 100 for ev in st["events"]):
        if 5 not in DIRECTOR_STATE["completed"] and DIRECTOR_STATE["step"] >= 4:
            pass  # only complete via explicit step to keep the narrative tight
    return None


def state() -> dict:
    return {"steps": STEPS, **DIRECTOR_STATE}
