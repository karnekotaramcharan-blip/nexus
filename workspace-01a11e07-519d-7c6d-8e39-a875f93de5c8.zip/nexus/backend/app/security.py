from datetime import datetime, timedelta
from typing import Optional

import bcrypt
import jwt
from fastapi import Depends, HTTPException, Request, status

from .config import settings
from .db import SessionLocal

ROLES = ["SUPER_ADMIN", "CAMPUS_ADMIN", "SECURITY_ADMIN", "EVENT_ADMIN"]
ALL_ROLES = ROLES + ["PUBLIC"]


def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt(rounds=10)).decode()


def verify_password(pw: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode(), hashed.encode())
    except Exception:
        return False


def create_token(sub: str, role: str, kind: str = "access") -> str:
    now = datetime.utcnow()
    if kind == "access":
        exp = now + timedelta(minutes=settings.ACCESS_TOKEN_MINUTES)
    else:
        exp = now + timedelta(days=settings.REFRESH_TOKEN_DAYS)
    return jwt.encode({"sub": sub, "role": role, "kind": kind, "exp": exp, "iat": now},
                      settings.SECRET_KEY, algorithm=settings.JWT_ALG)


def decode_token(token: str, kind: str = "access") -> dict:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.JWT_ALG])
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    if payload.get("kind") != kind:
        raise HTTPException(status_code=401, detail="Wrong token type")
    return payload


def get_current_user(request: Request):
    """Resolve user from httpOnly cookie or Authorization bearer. Returns None if unauthenticated."""
    token = request.cookies.get("nexus_access")
    if not token:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]
    if not token:
        return None
    try:
        payload = decode_token(token, "access")
    except HTTPException:
        return None
    from .models import User
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.username == payload.get("sub")).first()
        if user and user.is_active:
            return user
        return None
    finally:
        db.close()


def require_auth(request: Request):
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    return user


def require_roles(*roles):
    def dep(request: Request):
        user = require_auth(request)
        if roles and user.role not in roles and user.role != "SUPER_ADMIN":
            raise HTTPException(status_code=403, detail=f"Requires role: {', '.join(roles)}")
        return user
    return dep


# --- simple in-memory rate limiter (per IP) ---
_buckets: dict[str, list[float]] = {}


def rate_limit(key: str, max_calls: int = 10, window: int = 60):
    import time
    now = time.time()
    arr = _buckets.setdefault(key, [])
    _buckets[key] = [t for t in arr if now - t < window]
    if len(_buckets[key]) >= max_calls:
        raise HTTPException(status_code=429, detail="Too many requests")
    _buckets[key].append(now)


def audit(actor: str, action: str, detail: str = ""):
    from .models import AuditLog
    db = SessionLocal()
    try:
        db.add(AuditLog(actor=actor, action=action, detail=detail[:2000]))
        db.commit()
    finally:
        db.close()
