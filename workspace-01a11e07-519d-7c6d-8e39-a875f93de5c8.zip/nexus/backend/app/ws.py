from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from .services.runtime import HUB, build_snapshot

router = APIRouter()


@router.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    await HUB.connect(ws)
    try:
        await ws.send_json(build_snapshot())
        while True:
            # keep-alive; client may send pings or demo commands
            msg = await ws.receive_text()
            if msg == "ping":
                await ws.send_json({"type": "pong"})
    except WebSocketDisconnect:
        HUB.disconnect(ws)
