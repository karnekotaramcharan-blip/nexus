from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    APP_NAME: str = "NEXUS"
    ENV: str = "demo"  # demo | production
    DATABASE_URL: str = "sqlite:///./nexus.db"
    REDIS_URL: str = ""  # optional; in-process pub/sub fallback
    SECRET_KEY: str = "nexus-hackathon-demo-secret-change-me"
    JWT_ALG: str = "HS256"
    ACCESS_TOKEN_MINUTES: int = 60
    REFRESH_TOKEN_DAYS: int = 7
    CORS_ORIGINS: str = "*"

    # First super admin (created by seed script; never hardcoded in code paths)
    FIRST_ADMIN_EMAIL: str = "admin@nexus.demo"
    FIRST_ADMIN_PASSWORD: str = "NexusAdmin@123"

    # LLM for assistant / reports (optional; template fallback otherwise)
    LLM_API_KEY: str = ""
    LLM_BASE_URL: str = "https://api.openai.com/v1"
    LLM_MODEL: str = "gpt-4o-mini"

    AI_SERVICE_URL: str = "http://127.0.0.1:8001"

    SIM_TICK_SECONDS: float = 2.0   # real seconds per engine tick
    SIM_MINUTES_PER_TICK: int = 1   # simulated minutes advanced per tick
    SEED_DAYS: int = 30

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
