from datetime import datetime
from sqlalchemy import (String, Integer, Float, Boolean, DateTime, ForeignKey, Text, JSON, Index)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base


def utcnow():
    return datetime.utcnow()


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class User(TimestampMixin, Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    full_name: Mapped[str] = mapped_column(String(120), default="")
    role: Mapped[str] = mapped_column(String(30), default="CAMPUS_ADMIN", index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_demo_account: Mapped[bool] = mapped_column(Boolean, default=False)


class Building(TimestampMixin, Base):
    __tablename__ = "buildings"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    kind: Mapped[str] = mapped_column(String(40), default="building")
    x: Mapped[float] = mapped_column(Float, default=0)
    y: Mapped[float] = mapped_column(Float, default=0)
    w: Mapped[float] = mapped_column(Float, default=0)
    h: Mapped[float] = mapped_column(Float, default=0)


class Zone(TimestampMixin, Base):
    __tablename__ = "zones"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    kind: Mapped[str] = mapped_column(String(40), default="zone")  # academic|venue|outdoor|food|restricted|gate|road
    capacity: Mapped[int] = mapped_column(Integer, default=1500)
    cx: Mapped[float] = mapped_column(Float, default=0)
    cy: Mapped[float] = mapped_column(Float, default=0)
    density_threshold_high: Mapped[float] = mapped_column(Float, default=0.65)
    density_threshold_critical: Mapped[float] = mapped_column(Float, default=0.85)


class Camera(TimestampMixin, Base):
    __tablename__ = "cameras"
    id: Mapped[int] = mapped_column(primary_key=True)
    cam_id: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    zone_key: Mapped[str] = mapped_column(String(40), default="")
    source_type: Mapped[str] = mapped_column(String(20), default="demo")  # demo|rtsp|upload
    # RTSP credentials are kept in env/server-side only; never serialized to the frontend.
    status: Mapped[str] = mapped_column(String(20), default="online")  # online|offline|degraded
    ai_status: Mapped[str] = mapped_column(String(20), default="active")  # active|paused
    fps: Mapped[int] = mapped_column(Integer, default=24)
    last_update: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class CameraEvent(TimestampMixin, Base):
    __tablename__ = "camera_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    camera_id: Mapped[int] = mapped_column(ForeignKey("cameras.id"), index=True)
    kind: Mapped[str] = mapped_column(String(40))  # detection_summary|offline|online|upload_result
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


class CrowdRecord(Base):
    __tablename__ = "crowd_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    zone_key: Mapped[str] = mapped_column(String(40), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    count: Mapped[int] = mapped_column(Integer, default=0)
    density: Mapped[float] = mapped_column(Float, default=0)
    __table_args__ = (Index("ix_crowd_zone_ts", "zone_key", "ts"),)


class VehicleRecord(Base):
    __tablename__ = "vehicle_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    gate_key: Mapped[str] = mapped_column(String(40), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    cars_in: Mapped[int] = mapped_column(Integer, default=0)
    cars_out: Mapped[int] = mapped_column(Integer, default=0)
    bikes_in: Mapped[int] = mapped_column(Integer, default=0)
    bikes_out: Mapped[int] = mapped_column(Integer, default=0)


class ParkingZone(TimestampMixin, Base):
    __tablename__ = "parking_zones"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    category: Mapped[str] = mapped_column(String(40), default="mixed")  # student|faculty|visitor|two_wheeler|four_wheeler
    capacity: Mapped[int] = mapped_column(Integer, default=150)
    cx: Mapped[float] = mapped_column(Float, default=0)
    cy: Mapped[float] = mapped_column(Float, default=0)


class ParkingSlot(Base):
    __tablename__ = "parking_slots"
    id: Mapped[int] = mapped_column(primary_key=True)
    zone_key: Mapped[str] = mapped_column(String(40), index=True)
    slot_no: Mapped[str] = mapped_column(String(12))
    slot_type: Mapped[str] = mapped_column(String(20), default="car")
    occupied: Mapped[bool] = mapped_column(Boolean, default=False)


class Event(TimestampMixin, Base):
    __tablename__ = "events"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    venue_key: Mapped[str] = mapped_column(String(40), default="auditorium")
    expected_attendance: Mapped[int] = mapped_column(Integer, default=500)
    start_ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    end_ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    status: Mapped[str] = mapped_column(String(20), default="scheduled")  # scheduled|live|ended
    description: Mapped[str] = mapped_column(Text, default="")


class Alert(TimestampMixin, Base):
    __tablename__ = "alerts"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(40), index=True)
    severity: Mapped[str] = mapped_column(String(12), default="warning")  # info|warning|critical
    location: Mapped[str] = mapped_column(String(120), default="")
    reason: Mapped[str] = mapped_column(Text, default="")
    prediction: Mapped[str] = mapped_column(Text, default="")
    action: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(16), default="new", index=True)  # new|acknowledged|resolved|dismissed
    assignee: Mapped[str] = mapped_column(String(80), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


class EnvironmentalData(Base):
    __tablename__ = "environmental_data"
    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    temp_c: Mapped[float] = mapped_column(Float, default=28)
    humidity: Mapped[float] = mapped_column(Float, default=55)
    condition: Mapped[str] = mapped_column(String(30), default="clear")
    rain_prob: Mapped[float] = mapped_column(Float, default=0.0)
    aqi: Mapped[int] = mapped_column(Integer, default=80)


class ResourceUsage(Base):
    __tablename__ = "resource_usage"
    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    metric: Mapped[str] = mapped_column(String(30), index=True)  # electricity|water|waste
    value: Mapped[float] = mapped_column(Float, default=0)
    unit: Mapped[str] = mapped_column(String(16), default="")


class TrafficRecord(Base):
    __tablename__ = "traffic_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    road_key: Mapped[str] = mapped_column(String(40), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    volume: Mapped[int] = mapped_column(Integer, default=0)
    congestion: Mapped[float] = mapped_column(Float, default=0)


class FoodStall(TimestampMixin, Base):
    __tablename__ = "food_stalls"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    popularity: Mapped[float] = mapped_column(Float, default=1.0)
    service_rate: Mapped[float] = mapped_column(Float, default=4.0)  # people served / min
    servers: Mapped[int] = mapped_column(Integer, default=2)
    cx: Mapped[float] = mapped_column(Float, default=0)
    cy: Mapped[float] = mapped_column(Float, default=0)


class StallQueueRecord(Base):
    __tablename__ = "stall_queue_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    stall_key: Mapped[str] = mapped_column(String(40), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    queue: Mapped[int] = mapped_column(Integer, default=0)
    wait_min: Mapped[float] = mapped_column(Float, default=0)
    __table_args__ = (Index("ix_stall_ts", "stall_key", "ts"),)


class Prediction(TimestampMixin, Base):
    __tablename__ = "predictions"
    id: Mapped[int] = mapped_column(primary_key=True)
    target: Mapped[str] = mapped_column(String(80), index=True)   # e.g. crowd:auditorium, parking:park_a
    kind: Mapped[str] = mapped_column(String(30), default="crowd")
    made_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    target_ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    horizon_min: Mapped[int] = mapped_column(Integer, default=30)
    current_value: Mapped[float] = mapped_column(Float, default=0)
    predicted_value: Mapped[float] = mapped_column(Float, default=0)
    band_low: Mapped[float] = mapped_column(Float, default=0)
    band_high: Mapped[float] = mapped_column(Float, default=0)
    confidence: Mapped[float] = mapped_column(Float, default=0.8)
    model: Mapped[str] = mapped_column(String(60), default="seasonal-baseline+linear-trend")
    actual_value: Mapped[float | None] = mapped_column(Float, nullable=True)
    error_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    summary: Mapped[str] = mapped_column(Text, default="")


class Simulation(TimestampMixin, Base):
    __tablename__ = "simulations"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    scenario: Mapped[str] = mapped_column(String(60))
    params: Mapped[dict] = mapped_column(JSON, default=dict)
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    risk_current: Mapped[float] = mapped_column(Float, default=0)
    risk_simulated: Mapped[float] = mapped_column(Float, default=0)
    author: Mapped[str] = mapped_column(String(80), default="")


class Recommendation(TimestampMixin, Base):
    __tablename__ = "recommendations"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    detail: Mapped[str] = mapped_column(Text, default="")
    source: Mapped[str] = mapped_column(String(60), default="risk-engine")
    priority: Mapped[int] = mapped_column(Integer, default=3)
    expected_risk_reduction: Mapped[float] = mapped_column(Float, default=5.0)
    status: Mapped[str] = mapped_column(String(20), default="open")  # open|accepted|dismissed|done
    feedback_by: Mapped[str] = mapped_column(String(80), default="")
    baseline_metric: Mapped[dict] = mapped_column(JSON, default=dict)
    outcome_metric: Mapped[dict] = mapped_column(JSON, default=dict)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


class CampusMetric(Base):
    __tablename__ = "campus_metrics"
    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    population: Mapped[int] = mapped_column(Integer, default=0)
    risk_score: Mapped[float] = mapped_column(Float, default=0)
    parking_occupancy: Mapped[float] = mapped_column(Float, default=0)
    avg_congestion: Mapped[float] = mapped_column(Float, default=0)
    food_court_load: Mapped[float] = mapped_column(Float, default=0)


class Anomaly(TimestampMixin, Base):
    __tablename__ = "anomalies"
    id: Mapped[int] = mapped_column(primary_key=True)
    target: Mapped[str] = mapped_column(String(80), index=True)
    metric: Mapped[str] = mapped_column(String(40), default="")
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    observed: Mapped[float] = mapped_column(Float, default=0)
    expected_low: Mapped[float] = mapped_column(Float, default=0)
    expected_high: Mapped[float] = mapped_column(Float, default=0)
    deviation: Mapped[float] = mapped_column(Float, default=0)
    confidence: Mapped[float] = mapped_column(Float, default=0.8)
    severity: Mapped[str] = mapped_column(String(12), default="warning")
    reason: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(16), default="active")  # active|resolved


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    actor: Mapped[str] = mapped_column(String(120), default="")
    action: Mapped[str] = mapped_column(String(60), index=True)
    detail: Mapped[str] = mapped_column(Text, default="")


class PrivacySettings(Base):
    __tablename__ = "privacy_settings"
    id: Mapped[int] = mapped_column(primary_key=True)
    retention_days: Mapped[int] = mapped_column(Integer, default=30)
    face_blur: Mapped[bool] = mapped_column(Boolean, default=True)
    plate_blur: Mapped[bool] = mapped_column(Boolean, default=True)
    plate_storage: Mapped[bool] = mapped_column(Boolean, default=False)
    individual_tracking: Mapped[bool] = mapped_column(Boolean, default=False)  # always false; enforced
    auto_purge: Mapped[bool] = mapped_column(Boolean, default=True)
    updated_by: Mapped[str] = mapped_column(String(120), default="")


class AppSettings(Base):
    __tablename__ = "app_settings"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    value: Mapped[dict] = mapped_column(JSON, default=dict)
