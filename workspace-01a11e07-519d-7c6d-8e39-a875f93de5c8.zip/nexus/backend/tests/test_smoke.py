"""Basic tests: engine consistency, what-if, security, privacy guarantees, API smoke."""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from datetime import datetime

from app.services.engine import Engine
from app.services import scenarios
from app.security import hash_password, verify_password, create_token, decode_token


def fresh_engine():
    e = Engine(seed=7)
    e.sim_time = datetime.now().replace(hour=8, minute=50, second=0, microsecond=0)
    e.reset_state()
    for _ in range(60):
        e.tick(1)
    return e


def test_engine_produces_consistent_state():
    e = fresh_engine()
    st = e.state
    assert st["population"] > 500
    assert all(z["crowd"] >= 0 for z in st["zones"].values())
    assert 0 <= st["weather"]["rain_prob"] <= 1
    # gate flow conservation: open gates carry flow
    open_flow = sum(g["in_per_min"] for g in st["gates"].values())
    assert open_flow > 0


def test_whatif_gate_closure_redirects_flow():
    e = fresh_engine()
    before = e.state["gates"]["gate2"]["congestion"]
    res = scenarios.run(e, "gate_closed", {"gate": "gate1"}, horizon=30)
    assert res["impacts"]["gates"]["gate1"]["open"] is False
    assert res["impacts"]["gates"]["gate2"]["sim"] > res["impacts"]["gates"]["gate2"]["now"] - 0.01
    assert res["simulated_series"] and res["baseline_series"]
    assert len(res["simulated_series"]) == len(res["baseline_series"])
    assert res["recommendations"]


def test_whatif_all_required_scenarios():
    e = fresh_engine()
    for sc, params in [("gate_closed", {"gate": "gate1"}),
                       ("event_crowd_increase", {"multiplier": 1.8}),
                       ("parking_closed", {"zone": "park_a"}),
                       ("extra_vehicles", {"multiplier": 1.3}),
                       ("heavy_rain", {}),
                       ("stall_closed", {"stall": "snack_corner"}),
                       ("evacuation", {"zone": "auditorium"})]:
        res = scenarios.run(e, sc, params, horizon=20)
        assert "risk_simulated" in res, sc
    # evacuation estimates present
    res = scenarios.run(e, "evacuation", {"zone": "auditorium"}, horizon=20)
    assert res["evacuation"]["est_evac_minutes"] > 0


def test_engine_clone_independence():
    e = fresh_engine()
    c = e.clone(seed=1)
    c.inject("gate_closed", gate="gate1", duration_min=10 ** 6)
    c.tick(5)
    assert e.state["gates"]["gate1"]["open"] is True
    assert c.state["gates"]["gate1"]["open"] is False


def test_password_hashing_and_jwt():
    h = hash_password("Secret@123")
    assert h != "Secret@123"
    assert verify_password("Secret@123", h)
    assert not verify_password("wrong", h)
    tok = create_token("admin", "SUPER_ADMIN", "access")
    payload = decode_token(tok, "access")
    assert payload["sub"] == "admin" and payload["role"] == "SUPER_ADMIN"


def test_no_individual_tracking_in_engine():
    """Privacy guarantee: engine tracks aggregates only — no per-person identities."""
    e = fresh_engine()
    blob = str(e.state)
    for forbidden in ("face_id", "face_encoding", "identity", "person_id", "track_id", "plate"):
        assert forbidden not in blob.lower()


def test_api_health_and_auth_flow():
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as client:
        r = client.get("/api/v1/health")
        assert r.status_code == 200 and r.json()["status"] == "ok"
        # public pulse needs no auth
        r = client.get("/api/v1/pulse")
        assert r.status_code == 200
        # protected route blocked without auth
        r = client.get("/api/v1/live/snapshot")
        assert r.status_code == 401
        # login + access
        r = client.post("/api/v1/auth/login", json={"username": "admin", "password": "NexusAdmin@123"})
        assert r.status_code == 200
        r = client.get("/api/v1/live/snapshot")
        assert r.status_code == 200
        snap = r.json()
        assert len(snap["zones"]) == 10 and len(snap["stalls"]) == 8
        assert 0 <= snap["risk"]["score"] <= 100
        # RBAC: demo event_admin cannot list users
        r = client.post("/api/v1/auth/login", json={"username": "event_admin", "password": "DemoEvents@123"})
        assert r.status_code == 200
        r = client.get("/api/v1/settings/users")
        assert r.status_code == 403


def test_prediction_output_shape():
    from app.services import predict
    e = fresh_engine()
    for key, z in e.state["zones"].items():
        predict.push(f"crowd:{key}", e.sim_time, z["crowd"])
    cards = predict.top_predictions(e)
    assert len(cards) == 4
    for c in cards:
        assert c["detail"]["confidence"] > 0.5
        assert c["action"]
