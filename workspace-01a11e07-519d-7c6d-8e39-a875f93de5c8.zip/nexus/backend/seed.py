"""Seed script: users, campus topology, ~30 days of realistic history, demo video.

Usage:  python seed.py [--days 30] [--fresh]
"""
import argparse
import math
import os
import random
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.config import settings
from app.db import Base, engine, SessionLocal
from app import models
from app.security import hash_password
from app.services import campus as topo


def make_users(db):
    users = [
        (settings.FIRST_ADMIN_EMAIL, "admin", settings.FIRST_ADMIN_PASSWORD, "Super Admin", "SUPER_ADMIN", False),
        ("campus.admin@nexus.demo", "campus_admin", "DemoCampus@123", "Casey Campus", "CAMPUS_ADMIN", True),
        ("security@nexus.demo", "security_admin", "DemoSecure@123", "Sam Security", "SECURITY_ADMIN", True),
        ("events@nexus.demo", "event_admin", "DemoEvents@123", "Eve Events", "EVENT_ADMIN", True),
    ]
    for email, uname, pw, full, role, demo in users:
        if not db.query(models.User).filter(models.User.username == uname).first():
            db.add(models.User(email=email, username=uname, password_hash=hash_password(pw),
                               full_name=full, role=role, is_demo_account=demo))
    db.commit()
    print("  users ✓ (demo accounts clearly labeled demo-only)")


def make_topology(db):
    if not db.query(models.Building).first():
        for key, name, kind, x, y, w, h in topo.BUILDINGS:
            db.add(models.Building(key=key, name=name, kind=kind, x=x, y=y, w=w, h=h))
    if not db.query(models.Zone).first():
        for key, name, kind, cap, cx, cy in topo.ZONES:
            db.add(models.Zone(key=key, name=name, kind=kind, capacity=cap, cx=cx, cy=cy))
    if not db.query(models.Camera).first():
        for cam_id, name, zone in topo.CAMERAS:
            db.add(models.Camera(cam_id=cam_id, name=name, zone_key=zone))
    if not db.query(models.ParkingZone).first():
        for key, name, cat, cap, cx, cy, pref in topo.PARKING:
            db.add(models.ParkingZone(key=key, name=name, category=cat, capacity=cap, cx=cx, cy=cy))
            for i in range(min(cap, 60)):  # representative slot rows
                db.add(models.ParkingSlot(zone_key=key, slot_no=f"{key[-1].upper()}-{i+1:03d}",
                                          slot_type="bike" if cat == "two_wheeler" else "car"))
    if not db.query(models.FoodStall).first():
        for key, name, pop, rate, servers, cx, cy in topo.STALLS:
            db.add(models.FoodStall(key=key, name=name, popularity=pop, service_rate=rate,
                                     servers=servers, cx=cx, cy=cy))
    if not db.query(models.PrivacySettings).first():
        db.add(models.PrivacySettings(retention_days=30, face_blur=True, plate_blur=True,
                                      plate_storage=False, individual_tracking=False))
    db.commit()
    print("  topology ✓ (buildings, zones, cameras, parking, stalls, privacy defaults)")


def run_history(db, days: int):
    """Fast-forward the shared engine over `days` days, persisting every 15 sim-minutes."""
    from app.services.engine import Engine
    print(f"  generating {days} days of history with the shared simulation engine…")
    start = (datetime.now() - timedelta(days=days)).replace(hour=0, minute=0, second=0, microsecond=0)
    eng = Engine(seed=1234, sim_time=start)
    eng.sim_time = start
    eng.reset_state()
    rng = random.Random(7)

    end = datetime.now().replace(minute=0, second=0, microsecond=0)
    batch = []
    n = 0
    t = start
    while t < end:
        # sprinkle historical events: Saturday fests + occasional weekday evening events
        if t.weekday() == 5 and t.hour == 16 and t.minute == 0:
            eng.add_event(name="Saturday Fest", venue="auditorium",
                          expected=rng.randint(700, 1300), duration_min=240)
        if t.weekday() == 2 and t.hour == 17 and t.minute == 0 and rng.random() < 0.6:
            eng.add_event(name="Guest Lecture Series", venue="auditorium",
                          expected=rng.randint(300, 600), duration_min=120)
        if t.weekday() == 4 and t.hour == 18 and t.minute == 0 and rng.random() < 0.5:
            eng.add_event(name="Sports Meet", venue="sports",
                          expected=rng.randint(400, 800), duration_min=180)
        eng.tick(5)
        t = eng.sim_time
        if t.minute % 15 == 0:
            st = eng.state
            for key, z in st["zones"].items():
                batch.append(models.CrowdRecord(zone_key=key, ts=t, count=z["crowd"],
                                                density=round(z["crowd"] / max(1, z["capacity"]), 3)))
            for gk, g in st["gates"].items():
                batch.append(models.VehicleRecord(gate_key=gk, ts=t,
                                                  cars_in=int(g["in_per_min"] * 0.3),
                                                  cars_out=int(g["out_per_min"] * 0.3),
                                                  bikes_in=int(g["in_per_min"] * 0.2),
                                                  bikes_out=int(g["out_per_min"] * 0.2)))
            for rk, rd in st["roads"].items():
                batch.append(models.TrafficRecord(road_key=rk, ts=t, volume=int(rd["volume"]),
                                                  congestion=round(rd["congestion"], 3)))
            for sk, s in st["stalls"].items():
                batch.append(models.StallQueueRecord(stall_key=sk, ts=t, queue=int(s["queue"]),
                                                     wait_min=s["wait_min"]))
            w = st["weather"]
            batch.append(models.EnvironmentalData(ts=t, temp_c=round(w["temp_c"], 1), humidity=55,
                                                  condition=w["condition"],
                                                  rain_prob=round(w["rain_prob"], 2), aqi=w["aqi"]))
            res = st["resources"]
            batch.append(models.ResourceUsage(ts=t, metric="electricity", value=res["electricity_kw"], unit="kW"))
            batch.append(models.ResourceUsage(ts=t, metric="water", value=res["water_lpm"], unit="L/min"))
            batch.append(models.ResourceUsage(ts=t, metric="waste", value=res["waste_kg_h"], unit="kg/h"))
            park_occ = sum(p["occupied"] for p in st["parking"].values()) / max(
                1, sum(p["capacity"] for p in st["parking"].values()))
            batch.append(models.CampusMetric(
                ts=t, population=st["population"], risk_score=0,
                parking_occupancy=round(park_occ * 100, 1),
                avg_congestion=round(sum(r["congestion"] for r in st["roads"].values()) / 5, 2),
                food_court_load=round(st["food_court_seating_occ"] * 100, 1)))
            n += len(batch)
            if len(batch) > 4000:
                db.bulk_save_objects(batch)
                db.commit()
                batch = []
            print(f"\r    …{t.strftime('%d %b %H:%M')} ({n:,} rows)", end="", flush=True)
    if batch:
        db.bulk_save_objects(batch)
        db.commit()
    print()
    # seed a couple of past events for the Events page history
    if not db.query(models.Event).first():
        s = datetime.now().replace(hour=16, minute=0, second=0, microsecond=0) - timedelta(days=2)
        db.add(models.Event(name="Saturday Fest", venue_key="auditorium", expected_attendance=1100,
                            start_ts=s, end_ts=s + timedelta(hours=4), status="ended",
                            description="Weekly cultural fest (historical)."))
        db.commit()
    print(f"  history ✓ ({n:,} time-series rows)")


def make_demo_video():
    """Generate a synthetic demo video (moving person/vehicle blocks) for the CV pipeline."""
    try:
        import cv2
        import numpy as np
    except ImportError:
        print("  demo video skipped (opencv missing)")
        return
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ai-service", "data")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "demo_campus.mp4")
    if os.path.exists(path):
        print("  demo video ✓ (exists)")
        return
    W, H, FPS, SECS = 640, 360, 24, 24
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    vw = cv2.VideoWriter(path, fourcc, FPS, (W, H))
    rng = random.Random(9)
    actors = []
    for i in range(14):  # persons
        actors.append({"kind": "person", "x": rng.randint(0, W), "y": rng.randint(60, H - 40),
                       "vx": rng.choice([-1.6, 1.6, -1.1, 1.1]), "vy": rng.uniform(-0.5, 0.5),
                       "w": 14, "h": 34})
    for i in range(5):  # vehicles
        actors.append({"kind": "vehicle", "x": rng.randint(0, W), "y": rng.choice([26, 42]),
                       "vx": rng.choice([-2.8, 2.8]), "vy": 0, "w": 64, "h": 28})
    for f in range(FPS * SECS):
        frame = np.full((H, W, 3), (52, 40, 30), dtype=np.uint8)
        cv2.rectangle(frame, (0, 20), (W, 60), (70, 70, 70), -1)      # road
        cv2.rectangle(frame, (20, H - 120), (220, H - 20), (60, 60, 45), -1)  # queue region
        cv2.putText(frame, "QUEUE REGION", (30, H - 128), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
        cv2.line(frame, (320, 0), (320, H), (0, 255, 255), 1)          # counting line
        for a in actors:
            a["x"] += a["vx"]
            a["y"] += a["vy"] + rng.uniform(-0.3, 0.3)
            if a["x"] > W + 30:
                a["x"] = -30
            if a["x"] < -30:
                a["x"] = W + 30
            a["y"] = max(10, min(H - 40, a["y"]))
            color = (90, 200, 255) if a["kind"] == "person" else (120, 120, 220)
            cv2.rectangle(frame, (int(a["x"]), int(a["y"])),
                          (int(a["x"] + a["w"]), int(a["y"] + a["h"])), color, -1)
        vw.write(frame)
    vw.release()
    print(f"  demo video ✓ ({path})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=settings.SEED_DAYS)
    ap.add_argument("--fresh", action="store_true")
    args = ap.parse_args()

    if args.fresh and os.path.exists("nexus.db"):
        os.remove("nexus.db")
        print("  removed old nexus.db")

    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        make_users(db)
        make_topology(db)
        already = db.query(models.CrowdRecord).count() > 1000
        if not already:
            run_history(db, args.days)
        else:
            print(f"  history already seeded ({already:,} crowd rows) — skipping")
        if not db.query(models.AppSettings).filter(models.AppSettings.key == "risk_weights").first():
            from app.services.risk import DEFAULT_WEIGHTS
            db.add(models.AppSettings(key="risk_weights", value=DEFAULT_WEIGHTS))
            db.commit()
    finally:
        db.close()
    make_demo_video()

    # build baselines after seeding
    from app.services.baselines import build_baselines
    n = build_baselines()
    print(f"  baselines ✓ ({n} metric targets with hour×daytype buckets learned)")
    print("SEED COMPLETE ✅")


if __name__ == "__main__":
    main()
